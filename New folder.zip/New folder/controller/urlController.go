package controller

import (
	"path/filepath"

	"github.com/scanner/constant"
	"github.com/scanner/internals/downloader"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	"github.com/sirupsen/logrus"
)

// ProcessGitRepo handles the Git repository processing and clones it.
func ProcessGitRepo(url string, scanRequest models.ScanRequest, repoDetails models.RepoDetails, mode models.Mode) error {
	// Get the logger instance
	log := logger.GetLogger()

	// Define the local cache directory
	cacheDir, _ := utils.CreateTempDirectory()

	// Determine the directory name to store the repo
	dirName := utils.GetDirectoryNameFromURL(url, scanRequest)
	dirPath := filepath.Join(cacheDir, dirName)

	//Second API call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.ReadingRepo,
		"progress":    constant.ProgressValueTwo,
	}).Info("====SendLogMessage ====API: Reading repo.==== payload===")
		log.Println("2nd API Request Intiated====", constant.APIEnable)
		utils.SendLogMessage(scanRequest, constant.ReadingRepo, constant.ProgressValueTwo)
		log.Println("2nd API Request completed====", constant.ReadingRepo)
	
	// Clone the repository into the cache directory
	err := downloader.CloneRepo(url, dirPath, repoDetails, scanRequest, mode)
	if err != nil {
		// Log the error if cloning fails
		log.WithFields(logrus.Fields{
			"url":   url,
			"dir":   dirPath,
			"error": err.Error(),
		}).Error("Failed to clone Git repository")
		return err
	}

	return nil
}

// ProcessFile handles the file system processing (downloading the file).
func ProcessFile(path string, scanRequest models.ScanRequest, mode models.Mode) error {
	// Get the logger instance
	log := logger.GetLogger()

	//Second API call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMessage":  constant.ReadingFile,
		"progress":    constant.ProgressValueTwo,
	}).Info("====SendLogMessage ====API: Reading file.==== payload===")
		utils.SendLogMessage(scanRequest, constant.ReadingFile, constant.ProgressValueTwo)
	
	// Download the file into the cache directory
	err := downloader.ExtractArchive(path, scanRequest, mode)
	if err != nil {
		// Log the error if downloading fails
		log.WithFields(logrus.Fields{
			"path":  path,
			"error": err.Error(),
		}).Error("Failed to Extract Archive file")
		return err
	}

	// Log the success
	log.WithFields(logrus.Fields{
		"path": path,
	}).Info("Successfully Extracted Archive file")

	return nil
}
