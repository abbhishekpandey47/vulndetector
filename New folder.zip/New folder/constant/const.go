package constant

const (
	//Base Path
	BasePath = "/modernize-data"
	//Log msg
	LogMessage          = "Scan is initiated"
	LogMessageCompleted = "Scan is Completed"

	//Progress value
	ProgressValueZero        = 0
	ProgressValueTwo         = 2
	ProgressValueFour        = 4
	ProgressValueSix         = 6
	ProgressValueEight       = 8
	ProgressValueTen         = 10
	ProgressValueTwelve      = 12
	ProgressValueFifteen     = 15
	ProgressValueTwenty      = 20
	ProgressValueTwentyFive  = 25
	ProgressValueThirty      = 30
	ProgressValueForty       = 40
	ProgressValueFifty       = 50
	ProgressValueFiftyfive   = 55
	ProgressValueSixtyfive   = 65
	ProgressValueSeventyFive = 75
	ProgressValueEighty      = 80
	ProgressValueNinety      = 90
	ProgressValueNinetyFive  = 95
	ProgressValueCompleted   = 100

	//status Msg
	ScanStatusStarted    = "Started"
	ScanStatusInProgress = "Inprogress"
	ScanStatusCompleted  = "Completed"

	//Log msg Status
	ScannerTypeTechStack                     = "techStack"
	ScannerTypeRepoTreeStructure             = "Repo Tree Structure"
	ScannerTypeOpensourceSafetyVulnerability = "Opensource Safety Vulnerability"
	ScannerTypeCloudAdaptability             = "Cloud Adaptability"
	ScannerTypeCodeHealth                    = "codeQuality"
	ScannerTypeCompressed                    = "Final Result zip"

	//Ingestion phase log msg
	//Repo
	ConnectingRepo        = "Connecting to repo"
	ReadingRepo           = "Reading repo"
	RepoReadingInProgress = "Repo reading Inprogress"
	RepoReadingCompleted  = "Repo reading is successfully completed"

	//Tech stack identification phase log msg
	TechStackIdentificationInitiating = "Tech stack identification Initiating on the repo"
	TechStackIdentificationInProgress = "Tech stack identification InProgress"
	TechStackIdentificationCompleted  = "Tech stack identification successfully completed"

	//Trivy log msg
	OSScanInitiating = " Opensource Safety Vulnerability Scan Initiating on the repo"
	OSScanInProgress = " Opensource Safety Vulnerability Scan InProgress"
	OSScanCompleted  = " Opensource Safety Vulnerability Scan successfully completed"

	//CSA log msg
	CSAScanInitiating = " Cloud Adaptability Scan Initiating on the repo"
	CSAScanInProgress = " Cloud Adaptability Scan InProgress"
	CSAScanCompleted  = " Cloud Adaptability Scan successfully completed"

	//Static code analyzer  log msg
	CodeHealthInitiating = "Code Health Scan Initiating on the repo"
	CodeHealthInProgress = "Code Health Scan InProgress"
	CodeHealthCompleted  = "Code Health Scan successfully completed"
	//File
	ConnectingFile        = "Connecting to file"
	ReadingFile           = "Extracting file"
	FileReadingInProgress = "File Extracting Inprogress"
	FileReadingCompleted  = "File Extracting is successfully completed"

	//Log file path constant
	Log         = "log"
	LogFileName = "compass.log"

	//Msg API URL
	//DEV URL
	DevMsgAPI = "https://dev.cmodernize.com/modernize-sr-producer/producer/writeMessage"
	//APIURL = "http://10.200.0.49:84/modernize-sr-producer/producer/writeMessage"
	//QA URL
	QaMsgAPI = "https://qe.cmodernize.com/modernize-sr-producer/producer/writeMessage"

// QaMsgAPI = "https://private.cmodernize.com/modernize-sr-producer/producer/writeMessage"
)

// Global variables
var (
	APIEnable bool
	APIURL    string
	ErrorMSG  = map[string]string{}
	Mode      = "REMOTE" // Change to "REMOTE" to switch modes
	//Mode = "LOCAL" // Change to "LOCAL" to switch modes
)
