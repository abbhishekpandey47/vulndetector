package langpkg

import (
	"context"
	"sort"

	"github.com/aquasecurity/trivy/pkg/log"
	"github.com/aquasecurity/trivy/pkg/set"

	// "github.com/scanner/internals/db"
	"github.com/scanner/internals/db"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/vuln_detector/library"
	"golang.org/x/xerrors"

	"github.com/scanner/internals/db/langTypes"
	vulnClient "github.com/scanner/pkg/vuln_client"
)

var (
	PkgTargets = map[langTypes.LangType]string{
		langTypes.PythonPkg:   "Python",
		langTypes.CondaPkg:    "Conda",
		langTypes.GemSpec:     "Ruby",
		langTypes.NodePkg:     "Node.js",
		langTypes.Jar:         "Java",
		langTypes.K8sUpstream: "Kubernetes",
	}
)

// type Scanner interface {
// 	Scan(ctx context.Context, target types.ScanTarget, options types.ScanOptions) (types.Results, error)
// }

type scanner struct{}

// func NewScanner() Scanner {
// 	return &scanner{}
// }

// Scan(ctx context.Context, target ScanTarget) (types.Results, error) {
func Scan(ctx context.Context, fileType langTypes.LangType, blobInfo types.BlobInfo) (result types.Results, err error) {

	log := logger.GetLogger()

	apps := blobInfo.Applications
	// log.Info("Number of language-specific files : num : ", len(apps))
	if len(apps) == 0 {
		return nil, nil
	}

	var results types.Results
	printedTypes := set.New[langTypes.LangType]()
	for _, app := range apps {
		if len(app.Packages) == 0 {
			continue
		}

		// ctx = log.WithContextPrefix(ctx, string(app.Type))
		result := types.Result{
			Target: targetName(app.Type, app.FilePath),
			Class:  types.ClassLangPkg,
			Type:   app.Type,
		}

		sort.Sort(app.Packages)
		result.Packages = app.Packages

		var err error
		result.Vulnerabilities, err = scanVulnerabilities(ctx, fileType, app, printedTypes)
		if err != nil {
			log.Error("Unable to fetch scan results : ", err)
			return nil, err
		}

		// log.Infof("scan.go - Scan - scanVulnerabilities - result.Packages , result.Vulnerabilities ", len(result.Packages), len(result.Vulnerabilities))
		if len(result.Packages) == 0 && len(result.Vulnerabilities) == 0 {
			continue
		}
		results = append(results, result)
	}

	//dbase := db.NewDB()
	// dbconn := db.Connection()
	//log.Info(dbase)

	vuclient := vulnClient.NewClient(db.Config{})

	for i := range results {
		// Fill vulnerability details
		vuclient.FillInfo(results[i].Vulnerabilities)
	}

	sort.Slice(results, func(i, j int) bool {
		return results[i].Target < results[j].Target
	})
	return results, nil
}

func scanVulnerabilities(ctx context.Context, fileType langTypes.LangType, app types.Application, printedTypes set.Set[langTypes.LangType]) (
	[]types.DetectedVulnerability, error) {

	// Prevent the same log messages from being displayed many times for the same type.
	if !printedTypes.Contains(app.Type) {
		log.Info("Detecting vulnerabilities...")
		printedTypes.Append(app.Type)
	}

	log.Info("Scanning packages for vulnerabilities", log.FilePath(app.FilePath))
	log.Info("Calling library.Detect, Passing arguments : app.Type", app.Type)
	vulns, err := library.Detect(ctx, fileType, app.Packages)
	log.Info("scan.go - scanVulnerabilities - library.Detect returned, vulns len", len(vulns))
	if err != nil {
		return nil, xerrors.Errorf("failed vulnerability detection of libraries: %w", err)
	}
	return vulns, err
}

func targetName(appType langTypes.LangType, filePath string) string {
	if t, ok := PkgTargets[appType]; ok && filePath == "" {
		// When the file path is empty, we will overwrite it with the pre-defined value.
		return t
	}
	return filePath
}

// ScanTarget holds the attributes for scanning.
type ScanTarget struct {
	Name              string // container image name, file path, etc
	OS                types.OS
	Repository        *types.Repository
	Packages          types.Packages
	Applications      []types.Application
	Misconfigurations []types.Misconfiguration
	Secrets           []types.Secret
	Licenses          []types.LicenseFile

	// CustomResources hold analysis results from custom analyzers.
	// It is for extensibility and not used in OSS.
	CustomResources []types.CustomResource
}

// ScanOptions holds the attributes for scanning vulnerabilities
type ScanOptions struct {
	PkgTypes            []string
	PkgRelationships    []types.Relationship
	Scanners            Scanners
	ImageConfigScanners Scanners // Scanners for container image configuration
	ScanRemovedPackages bool
	LicenseCategories   map[types.LicenseCategory][]string
	FilePatterns        []string
	IncludeDevDeps      bool
	Distro              types.OS // Forced OS
}

// PkgType represents package type
type PkgType = string

// Scanner represents the type of security scanning
type Scanner string

// Scanners is a slice of scanners
type Scanners []Scanner
