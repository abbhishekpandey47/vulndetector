package logger

import (
	"fmt"
	"io"
	"os"
	"time"

	"github.com/natefinch/lumberjack"
	"github.com/sirupsen/logrus"
)

// Log instance to be used globally
var Log *logrus.Logger

// Init initializes the logger to both the console and a file with log rotation.
func Init(logFilePath string) error {
	Log = logrus.New()

	// Set default log level and output (stdout)
	Log.SetLevel(logrus.InfoLevel)
	Log.SetOutput(os.Stdout)

	// Set log format
	Log.SetFormatter(&logrus.TextFormatter{
		FullTimestamp: true,
	})

	// If a log file path is provided, also log to file with log rotation
	if logFilePath != "" {
		// Log rotation configuration using lumberjack
		fileLogger := &lumberjack.Logger{
			Filename:   logFilePath, // Log file name
			MaxSize:    10,          // Max size in MB before rotation
			MaxBackups: 3,           // Keep 3 backups
			MaxAge:     10,          // Keep logs for 10 days
			Compress:   true,        // Compress old log files
		}

		// Use MultiWriter to log to both stdout and the file
		Log.SetOutput(io.MultiWriter(os.Stdout, fileLogger))
	}

	return nil
}

// SetLogLevel sets the log level dynamically
func SetLogLevel(level string) {
	switch level {
	case "debug":
		Log.SetLevel(logrus.DebugLevel)
	case "info":
		Log.SetLevel(logrus.InfoLevel)
	case "warn":
		Log.SetLevel(logrus.WarnLevel)
	case "error":
		Log.SetLevel(logrus.ErrorLevel)
	default:
		Log.SetLevel(logrus.InfoLevel)
	}
}

// GetLogger returns the logger instance
func GetLogger() *logrus.Logger {
	return Log
}

// CustomFormatter is a custom logrus formatter to include system time
type CustomFormatter struct {
	logrus.Formatter
}

// Format adds the system time to the log entry.
func (f *CustomFormatter) Format(entry *logrus.Entry) ([]byte, error) {
	currentTime := time.Now().Format(time.RFC3339) // Use RFC3339 format for time
	logMessage := fmt.Sprintf("%s %s\n", currentTime, entry.Message)
	return []byte(logMessage), nil
}
