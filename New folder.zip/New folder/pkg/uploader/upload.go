package uploader

import (
	"fmt"

	"github.com/scanner/constant"
	"github.com/scanner/controller"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	"github.com/sirupsen/logrus"
)

// UploadRequest handles the user request to upload a Git repository or file.
func UploadRequest(request models.RequestType, repoDetails models.RepoDetails, scanRequest models.ScanRequest, SourceCodeDetails models.SourceCodeDetails, mode models.Mode) error {
	// Get the logger instance
	log := logger.GetLogger()

	// Validate input arguments
	if scanRequest.TenantID == "" || scanRequest.RunID == "" {
		log.WithFields(logrus.Fields{
			"tenantID": scanRequest.TenantID,
			"runID":    scanRequest.RunID,
		}).Error("TenantID and RunID must be provided")
		return fmt.Errorf("TenantID and RunID must be provided")
	}

	// Log the start of the upload request handling
	log.WithFields(logrus.Fields{
		"tenantID":    scanRequest.TenantID,
		"runID":       scanRequest.RunID,
		"requestType": request.RequestType,
	}).Info("Handling upload request")

	// Check the requestType and proceed accordingly
	if request.RequestType == "repo" {
		//first API Call
		scanRequest.LaunchedOn = utils.GetCurrentTime()
		log.WithFields(logrus.Fields{
			"scanRequest": scanRequest,
			"logMassage":  constant.ConnectingRepo,
			"progress":    constant.ProgressValueZero,
		}).Info("====SendLogMessage ====API: Connecting to repo.==== payload===")
		
			log.Println("1st API Request Intiated====", constant.APIEnable)
			utils.SendLogMessage(scanRequest, constant.ConnectingRepo, constant.ProgressValueZero)
			log.Println("1st API Request completed====", constant.ConnectingRepo)

		

		// If it's a Git repository, use gitURL
		if repoDetails.RootURL == "" {
			log.Error("Invalid input: gitURL is empty for requestType 'repo'")
			return fmt.Errorf("invalid input: gitURL is required for requestType 'repo'")
		}
		log.WithFields(logrus.Fields{
			"gitURL": repoDetails.RootURL,
		}).Info("Detected Git repository. Proceeding to clone...")
		return controller.ProcessGitRepo(repoDetails.RootURL, scanRequest, repoDetails, mode)
	} else if request.RequestType == "file" {
		//First API Call
		scanRequest.LaunchedOn = utils.GetCurrentTime()
		log.WithFields(logrus.Fields{
			"scanRequest": scanRequest,
			"logMassage":  constant.ConnectingFile,
			"progress":    constant.ProgressValueZero,
		}).Info("====SendLogMessage ====API: Connecting to file.==== payload===")
			utils.SendLogMessage(scanRequest, constant.ConnectingFile, constant.ProgressValueZero)
		// If it's a file system, use fs
		if SourceCodeDetails.Path == "" {
			log.Error("Invalid input: File Path is empty for requestType 'File'")
			return fmt.Errorf("invalid input: file is required for requestType 'file'")
		}
		log.WithFields(logrus.Fields{
			"path": SourceCodeDetails.Path,
		}).Info("Detected file system. Proceeding to extracts...")
		return controller.ProcessFile(SourceCodeDetails.Path, scanRequest, mode)
	} else {
		// If the requestType is neither 'repo' nor 'fs'
		log.Error("Invalid request type: must be either 'repo' or 'file'")
		return fmt.Errorf("invalid request type: must be either 'repo' or 'file'")
	}
}
