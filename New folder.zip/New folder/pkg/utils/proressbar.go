package utils

import (
	"time"

	"github.com/schollz/progressbar/v3"
)

type ProgressBar struct {
	bar     *progressbar.ProgressBar
	started time.Time
	total   int
}

// New creates and returns a new ProgressBar
func New(total int, description string) *ProgressBar {
	bar := progressbar.NewOptions(total,
		progressbar.OptionSetDescription(description),
		progressbar.OptionSetTheme(progressbar.Theme{
			Saucer:        "=",
			SaucerPadding: " ",
			BarStart:      "[",
			BarEnd:        "]",
		}),
		progressbar.OptionShowCount(),
		progressbar.OptionShowIts(),
		progressbar.OptionSetPredictTime(true),
		progressbar.OptionClearOnFinish(),
	)

	return &ProgressBar{
		bar:     bar,
		started: time.Now(),
		total:   total,
	}
}

// Add increments the progress bar by 1
func (p *ProgressBar) Add() {
	p.bar.Add(1)
}

// Finish prints the final elapsed time
func (p *ProgressBar) Finish() time.Duration {
	elapsed := time.Since(p.started)
	p.bar.Finish()
	return elapsed
}
