package utils

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/scanner/models"
)

func WriteFullScanPayloadToFile(scanRequest models.ScanRequest, requestType models.RequestType, envType models.EnvType, mode models.Mode, repoDetails models.RepoDetails, sourceCodeDetails models.SourceCodeDetails) error {
	payload := models.FullScanPayload{
		RequestType: models.RequestType{RequestType: requestType.RequestType},
		EnvType:     models.EnvType{EnvType: envType.EnvType},
		Mode:        models.Mode{Mode: mode.Mode},
		ScanRequest: models.ScanRequest{
		RunID:        scanRequest.RunID,
				ScanResultID: scanRequest.ScanResultID,
				ScanID:       scanRequest.ScanID,
				ComponentID:  scanRequest.ComponentID,
				AppID:        scanRequest.AppID,
				TenantID:     scanRequest.TenantID,
				ScanProfile:  scanRequest.ScanProfile,
				LaunchedOn:   scanRequest.LaunchedOn,
		},
		RepoDetails: models.RepoDetails{
			LogicalRepoName:    repoDetails.LogicalRepoName,
			RootURL:            repoDetails.RootURL,
			RepoType:           repoDetails.RepoType,
			AuthType:           repoDetails.AuthType,
			Username:           repoDetails.Username,
			Password:           repoDetails.Password,
			PasswordSecretKey:  repoDetails.PasswordSecretKey,
			AuthToken:          repoDetails.ActualRepoName,
			AuthTokenSecretKey: repoDetails.AuthTokenSecretKey,
			ActualRepoName:     repoDetails.ActualRepoName,
			SSHKeyPath:         repoDetails.SSHKeyPath,
		},
		SourceCodeDetails: models.SourceCodeDetails{
			Path: sourceCodeDetails.Path,
		},
	}

	tempPath, _ := CreateTempDirectory()
	resultFile := "metadata.json"
	fileName := filepath.Join(tempPath, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, resultFile)

	filePath := fileName
	// Ensure the directory exists

	dir := filepath.Dir(filePath)
	if err := os.MkdirAll(dir, os.ModePerm); err != nil {
		return fmt.Errorf("failed to create directory: %w", err)
	}

	// Marshal the payload to JSON
	data, err := json.MarshalIndent(payload, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal payload: %w", err)
	}

	// Write the data to file
	err = os.WriteFile(filePath, data, 0644)
	if err != nil {
		return fmt.Errorf("failed to write to file: %w", err)
	}

	fmt.Printf("Payload successfully written to: %s\n", filePath)
	return nil
}
