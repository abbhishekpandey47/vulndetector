package utils

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/sirupsen/logrus"
)

func GeneratTechStackResult(languageVersionStringArray []string, framework []string, numberOfLine int, scanRequest models.ScanRequest, totalFileCount int, totalFileCountByExtension []models.ExtensionCount) {
	log := logger.GetLogger()
	scanRequest.LaunchedOn = GetCurrentTime()
	techStack := models.TechStack{
		ScanRequest: models.ScanRequest{
			RunID:        scanRequest.RunID,
			ScanResultID: scanRequest.ScanResultID,
			ScanID:       scanRequest.ScanID,
			ComponentID:  scanRequest.ComponentID,
			AppID:        scanRequest.AppID,
			TenantID:     scanRequest.TenantID,
			ScanProfile:  scanRequest.ScanProfile,
			LaunchedOn:   scanRequest.LaunchedOn,
		},
		ScanType: constant.ScannerTypeTechStack,
		TechStack: models.Tech_stack{
			Language:  languageVersionStringArray,
			Framework: framework,
		},
		Loc:                  numberOfLine,
		TotalFileCount:       totalFileCount,
		FileCountByExtension: totalFileCountByExtension,
	}

	// Marshal the struct to JSON
	resultJSON, err := json.MarshalIndent(techStack, "", "  ")
	if err != nil {
		log.Error("Error marshalling struct:", err)
		return
	}
	// Define the full file path where you want to store the result
	//fileName := scanRequest.RunID + "_tech_stack.json"
	//filePath, _ := CreateTempDirectory()
	//fileTimeStamp := GetfileNameCurrentTime()
	techStackResultPath, _ := GetCodeAnalyzerScanResultsPath(scanRequest, "tech-stack")
	techStackResultFileName := filepath.Join(techStackResultPath,"tech-stack.json")

	//filePath = filepath.Join(filePath, scanRequest.TenantID, scanRequest.RunID, "results", "tech_stack", fileName)

	// Ensure the directories exist, create them if they don't
	dir := filepath.Dir(techStackResultFileName)
	err = os.MkdirAll(dir, os.ModePerm) // os.ModePerm gives full permissions
	if err != nil {
		log.Error("Error creating directories:", err)
		return
	}
	//fileName := filepath.Join(filePath, "tech_stack.json")
	// Create and open the file where the result will be saved
	file, err := os.Create(techStackResultFileName)
	if err != nil {
		ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to creating techstack result file: %v", err))
		ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to creating techstack result file: %v", err), constant.ProgressValueThirty)
		log.Error("Error creating file:", err)
		return
	}
	defer file.Close() // Ensure file is closed when we're done

	// Write the JSON to the file
	_, err = file.Write(resultJSON)
	if err != nil {
		fmt.Println("Error writing to file:", err)
		return
	}
	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"fileName":    techStackResultFileName,
		"scannerType": constant.ScannerTypeTechStack,
	}).Info("====InsertResultFileToKafka ====Tech Stack Result File Genreted successfully. ==== API Request Payload == ")
	SendApiRequest(scanRequest, techStackResultFileName, constant.ScannerTypeTechStack)

	// Print a success message
	fmt.Println("TechStack successfully written to ", techStackResultFileName)

}
