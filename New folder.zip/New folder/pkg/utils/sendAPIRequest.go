package utils

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
)

// Function to send the API request
func SendApiRequest(scanRequest models.ScanRequest, fileName, scannerType string) {
	// Construct the request body based on your JSON format
	reqBody := models.RequestBody{
		Action:   "insertResultFileToKafka",
		TenantId: scanRequest.TenantID,
		ActionPayload: models.ActionPayload{
			ScanRequest: models.ScanRequest{
				RunID:        scanRequest.RunID,
				ScanResultID: scanRequest.ScanResultID, // Can be updated if needed
				ScanID:       scanRequest.ScanID,       // Can be updated if needed
				ComponentID:  scanRequest.ComponentID,  // Can be updated if needed
				AppID:        scanRequest.AppID,        // Can be updated if needed
				TenantID:     scanRequest.TenantID,
				ScanProfile:  scanRequest.ScanProfile, // Can be updated if needed
				LaunchedOn:   scanRequest.LaunchedOn,  // Can be updated if needed
			},
			ScanType: scannerType,
			FilePath: fileName,
		},
	}

	// Marshal the request body into JSON format
	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		log.Fatalf("Error marshaling JSON: %v", err)
	}

	// Define the URL for the API endpoint
	// End point worked in container
	//url := "http://10.200.0.49:84/modernize-sr-producer/producer/writeMessage"
	// url := "http://98.83.65.250:84/producer/writeMessage"
	if constant.APIEnable {
		url := constant.APIURL
		// Create a POST request with the JSON payload
		req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
		if err != nil {
			log.Fatalf("Error creating request: %v", err)
		}
		// Set the necessary headers for the request
		req.Header.Set("Content-Type", "application/json")
		// Create a new HTTP client and send the request
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			log.Fatalf("Error sending request: %v", err)
		}
		defer resp.Body.Close()

		// Handle the response (for example, print the response status)
		if resp.StatusCode == http.StatusOK {
			fmt.Println("Request to insert result file into Kafka was successful!")
		} else {
			fmt.Printf("Error: received status code %d\n", resp.StatusCode)
		}
	} else {
		writeToFile(scanRequest, jsonData)
	}
}

func SendLogMessage(scanRequest models.ScanRequest, logMessage string, progress int) {
	// Create the log message struct
	logMessageStruct := models.LogMessage{
		Action:   "insertLog",
		TenantID: scanRequest.TenantID,
		ActionPayload: models.LogActionPayload{
			ScanRequest: models.ScanRequest{
				RunID:        scanRequest.RunID,
				ScanResultID: scanRequest.ScanResultID,
				ScanID:       scanRequest.ScanID,
				ComponentID:  scanRequest.ComponentID,
				AppID:        scanRequest.AppID,
				TenantID:     scanRequest.TenantID,
				ScanProfile:  scanRequest.ScanProfile,
				LaunchedOn:   scanRequest.LaunchedOn,
			},
			LogMessage:     logMessage,
			ProgressValues: progress,
		},
	}

	// Marshal the log message struct into JSON
	payload, err := json.MarshalIndent(logMessageStruct, "", "  ")
	if err != nil {
		log.Printf("Error marshaling log message: %v", err)
		return
	}

	if constant.APIEnable {
		// API URL
		apiURL := constant.APIURL
		log.Println("API URL ===", apiURL)

		req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(payload))
		if err != nil {
			log.Printf("Error creating HTTP request: %v", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			log.Printf("Error sending log message to API: %v", err)
			return
		}
		defer resp.Body.Close()

		log.Println("API Request Status Code ===", resp.StatusCode)
		if resp.StatusCode == http.StatusOK {
			fmt.Println("Log message successfully sent to API.")
		} else {
			fmt.Printf("Error: received status code %d\n", resp.StatusCode)
		}
	} else {
		writeToFile(scanRequest, payload)
	}
}

func SendStatus(scanRequest models.ScanRequest, value string) {
	// Create the log message struct
	changeStatusStruct := models.ChangeStatus{
		Action:   "changeStatus",
		TenantID: scanRequest.TenantID,
		ActionPayload: models.StatusActionPayload{
			ScanRequest: models.ScanRequest{
				RunID:        scanRequest.RunID,
				ScanResultID: scanRequest.ScanResultID, // Can be updated if needed
				ScanID:       scanRequest.ScanID,       // Can be updated if needed
				ComponentID:  scanRequest.ComponentID,  // Can be updated if needed
				AppID:        scanRequest.AppID,        // Can be updated if needed
				TenantID:     scanRequest.TenantID,
				ScanProfile:  scanRequest.ScanProfile, // Can be updated if needed
				LaunchedOn:   scanRequest.LaunchedOn,  // Can be updated if needed
			},
			Value: value,
		},
	}

	// Define the API endpoint for sending the log message (adjust as needed)
	//apiURL := "http://10.200.0.49:84/modernize-sr-producer/producer/writeMessage"
	// Replace with your actual API URL
	apiURL := constant.APIURL
	// Marshal the log message struct into JSON
	payload, err := json.Marshal(changeStatusStruct)
	if err != nil {
		log.Printf("Error marshaling log message: %v", err)
	}

	if constant.APIEnable {
		// Create a new POST request with the marshaled log message as the body
		req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(payload))
		if err != nil {
			log.Printf("Error creating HTTP request: %v", err)
		}

		// Set the required headers
		req.Header.Set("Content-Type", "application/json")

		// Create a new HTTP client with a timeout to prevent hanging
		// client := &http.Client{
		// 	Timeout: 10 * time.Second, // Set a timeout (adjust as needed)
		// }

		// Send the request to the API
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			log.Printf("Error sending Status to API: %v", err)
		}
		defer resp.Body.Close()

		// Handle the response (for example, print the response status)
		if resp.StatusCode == http.StatusOK {
			fmt.Println("Status successfully sent to API.")
		} else {
			fmt.Printf("Error: received status code %d\n", resp.StatusCode)
		}
	} else {
		writeToFile(scanRequest, payload)
	}
}

func ReportErrorToAPI(scanRequest models.ScanRequest, value string) {
	log := logger.GetLogger()
	if value == " " {
		return
	}

	// Create the log message struct
	ErrorMSGPayload := models.ChangeStatus{
		Action:   "changeStatus",
		TenantID: scanRequest.TenantID,
		ActionPayload: models.StatusActionPayload{
			ScanRequest: models.ScanRequest{
				RunID:        scanRequest.RunID,
				ScanResultID: scanRequest.ScanResultID, // Can be updated if needed
				ScanID:       scanRequest.ScanID,       // Can be updated if needed
				ComponentID:  scanRequest.ComponentID,  // Can be updated if needed
				AppID:        scanRequest.AppID,        // Can be updated if needed
				TenantID:     scanRequest.TenantID,
				ScanProfile:  scanRequest.ScanProfile, // Can be updated if needed
				LaunchedOn:   scanRequest.LaunchedOn,  // Can be updated if needed
			},
			Value: value,
		},
	}

	log.Info("===Error API Payload===", scanRequest, " ==Error msg== ", value)

	jsonData, err := json.Marshal(ErrorMSGPayload)
	if err != nil {
		log.Error("Failed to marshal error payload: ", err)
		return
	}

	if constant.APIEnable {
		// Replace with your actual API URL
		apiURL := constant.APIURL

		// Create a new POST request with the marshaled log message as the body
		req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(jsonData))
		if err != nil {
			log.Error("Error creating HTTP request: ", err)
		}

		// Set the required headers
		req.Header.Set("Content-Type", "application/json")

		// Send the request to the API
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			log.Error("Failed to send error report to API: ", err)
		}
		defer resp.Body.Close()

		// Handle the response (for example, print the response status)
		if resp.StatusCode == http.StatusOK {
			log.Info("Error successfully sent to API.")
		} else {
			log.Error("Error: received status code: ", resp.StatusCode)
		}
	} else {
		writeToFile(scanRequest, jsonData)
	}
}


func ReportErrorToSendLogAPI(scanRequest models.ScanRequest, logMessage string, progress int) {
	log := logger.GetLogger()
	if logMessage == " " {
		return
	}
// Create the log message struct
	logMessageStruct := models.LogMessage{
		Action:   "insertLog",
		TenantID: scanRequest.TenantID,
		ActionPayload: models.LogActionPayload{
			ScanRequest: models.ScanRequest{
				RunID:        scanRequest.RunID,
				ScanResultID: scanRequest.ScanResultID,
				ScanID:       scanRequest.ScanID,
				ComponentID:  scanRequest.ComponentID,
				AppID:        scanRequest.AppID,
				TenantID:     scanRequest.TenantID,
				ScanProfile:  scanRequest.ScanProfile,
				LaunchedOn:   scanRequest.LaunchedOn,
			},
			LogMessage:     logMessage,
			ProgressValues: progress,
		},
	}

	// Marshal the log message struct into JSON
	payload, err := json.MarshalIndent(logMessageStruct, "", "  ")
	if err != nil {
		log.Printf("Error marshaling log message: %v", err)
		return
	}

	if constant.APIEnable {
		// API URL
		apiURL := constant.APIURL
		log.Println("API URL ===", apiURL)

		req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(payload))
		if err != nil {
			log.Printf("Error creating HTTP request: %v", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			log.Printf("Error sending log message to API: %v", err)
			return
		}
		defer resp.Body.Close()

		log.Println("API Request Status Code ===", resp.StatusCode)
		if resp.StatusCode == http.StatusOK {
			fmt.Println("Log Error message successfully sent to API.")
		} else {
			fmt.Printf("Error: received status code %d\n", resp.StatusCode)
		}
	} else {
		writeToFile(scanRequest, payload)
	}
}

var timeStamp = GetfileNameCurrentTime()

func getFileName(scanRequest models.ScanRequest) string {
	tempPath, _ := CreateTempDirectory()
	resultFile := "offline-messages.json"
	fileName := filepath.Join(tempPath, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, resultFile)
	return fileName
}

func writeToFile(scanRequest models.ScanRequest, payload []byte) {
	fileName := getFileName(scanRequest)

	// Ensure the directory exists
	dir := filepath.Dir(fileName)
	err := os.MkdirAll(dir, os.ModePerm)
	if err != nil {
		log.Printf("Error creating directories: %v", err)
		return
	}

	var existingLogs []interface{}

	// Check if file exists
	if _, err := os.Stat(fileName); err == nil {
		// File exists - read and unmarshal
		data, err := os.ReadFile(fileName)
		if err != nil {
			log.Printf("Error reading existing file: %v", err)
			return
		}
		err = json.Unmarshal(data, &existingLogs)
		if err != nil {
			log.Printf("Error unmarshaling existing JSON: %v", err)
			return
		}
	} else if !os.IsNotExist(err) {
		// Unexpected error checking file
		log.Printf("Error checking file existence: %v", err)
		return
	}

	// Unmarshal new payload to a generic interface{} and append
	var newLog interface{}
	if err := json.Unmarshal(payload, &newLog); err != nil {
		log.Printf("Error unmarshaling new payload: %v", err)
		return
	}
	existingLogs = append(existingLogs, newLog)

	// Marshal back to JSON
	updatedData, err := json.MarshalIndent(existingLogs, "", "  ")
	if err != nil {
		log.Printf("Error marshaling combined log data: %v", err)
		return
	}

	// Write to file
	err = os.WriteFile(fileName, updatedData, 0644)
	if err != nil {
		log.Printf("Error writing to file: %v", err)
	} else {
		fmt.Printf("Log message appended to file: %s\n", fileName)
	}
}
