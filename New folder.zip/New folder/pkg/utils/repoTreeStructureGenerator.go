package utils

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/sirupsen/logrus"
)

// buildTree recursively builds the tree structure from a given path
func buildTree(path string) (models.Node, error) {
	info, err := os.Stat(path)
	if err != nil {
		return models.Node{}, err
	}

	node := models.Node{
		Name: info.Name(),
		Type: "file",
	}

	if info.IsDir() {
		node.Type = "folder"
		entries, err := os.ReadDir(path)
		if err != nil {
			return node, err
		}

		for _, entry := range entries {
			childPath := filepath.Join(path, entry.Name())
			childNode, err := buildTree(childPath)
			if err != nil {
				return node, err
			}
			node.Children = append(node.Children, childNode)
		}
	}

	return node, nil
}

var fileTimeStamp = GetfileNameCurrentTime()

func GenerateRepoTreeStructure(repoPath string, scanRequest models.ScanRequest, csaResultFilePath, codeHealthResultFilePath string, language []string) {
	log := logger.GetLogger()
	folderName, _ := GetCodeAnalyzerScanResultsPath(scanRequest, "code-tree-structure")

	repoTreeStructureResultFileName := "code-tree-structure.json"
	resultPath := filepath.Join(folderName, repoTreeStructureResultFileName)

	log.Info("repo tree structure result Path ", resultPath)
	rootPath := repoPath
	outputFile := resultPath

	tree, err := buildTree(rootPath)
	if err != nil {
		ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to create code-tree-structure scan result file: %v", err))
		ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to create code-tree-structure scan result file: %v", err), constant.ProgressValueNinetyFive)
		log.Error("Error building tree:", err)
		return
	}

	// Create the final result struct
	scanRequest.LaunchedOn = GetCurrentTime()
	result := models.Result{
		ScanRequest: scanRequest,
		ScanType:    constant.ScannerTypeRepoTreeStructure,
		TechStack:   language[0],
		Result:      tree,
	}
	// Convert tree to JSON
	jsonBytes, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to marshalling JSON for code-tree-structure scan result file: %v", err))
		ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to marshalling JSON for code-tree-structure scan result file: %v", err), constant.ProgressValueNinetyFive)
		log.Error("Error marshalling JSON:", err)
		return
	}

	// Write to JSON file
	err = os.WriteFile(outputFile, jsonBytes, 0777)
	if err != nil {
		ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to writing code-tree-structure scan result file: %v", err))
		ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to writing code-tree-structure scan result file: %v", err), constant.ProgressValueNinetyFive)
		log.Error("Error writing JSON file:", err)
		return
	}

	//  Call enrichment function here
	EnrichTreeWithCSAResults(&tree, csaResultFilePath, codeHealthResultFilePath, outputFile)
	log.Info("Tree structure written to", outputFile)

	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"fileName":    outputFile,
		"scannerType": constant.ScannerTypeRepoTreeStructure,
	}).Info("====InsertResultFileToKafka ====Repo Tree Structure File Genreted successfully. ==== API Request Payload == ")
	SendApiRequest(scanRequest, outputFile, constant.ScannerTypeRepoTreeStructure)

}

func EnrichTreeWithCSAResults(tree *models.Node, cloudAdaptabilityFilePath, pmdResultsFilePath, repoTreeFilePath string) {
	log := logger.GetLogger()
	outputPath := repoTreeFilePath

	// --- Load CSA JSON ---
	cloudAdaptabilityBytes, err := os.ReadFile(cloudAdaptabilityFilePath)
	if err != nil {
		log.Fatal("Failed to read Cloud_adaptability file:", err)
	}

	var cloudAdaptabilityRoot map[string]interface{}
	if err := json.Unmarshal(cloudAdaptabilityBytes, &cloudAdaptabilityRoot); err != nil {
		log.Fatal("Failed to parse Cloud_adaptability JSON:", err)
	}

	scanResults, ok := cloudAdaptabilityRoot["scan_results"].(map[string]interface{})
	if !ok {
		log.Error("Cloud_adaptability JSON missing 'scan_results'")
	}

	resultsRaw, ok := scanResults["Results"].([]interface{})
	if !ok {
		log.Error("Cloud_adaptability JSON missing or malformed 'Results'")
	}

	var cloudAdaptabilityData []map[string]interface{}
	for _, entry := range resultsRaw {
		if entryMap, ok := entry.(map[string]interface{}); ok {
			cloudAdaptabilityData = append(cloudAdaptabilityData, entryMap)
		}
	}

	cloudAdaptabilityByFilename := make(map[string][]map[string]interface{})
	for _, entry := range cloudAdaptabilityData {
		if filename, ok := entry["filename"].(string); ok {
			cloudAdaptabilityByFilename[filename] = append(cloudAdaptabilityByFilename[filename], entry)
		}
	}

	// --- Load PMD JSON ---
	pmdBytes, err := os.ReadFile(pmdResultsFilePath)
	if err != nil {
		log.Fatal("Failed to read PMD results file:", err)
	}

	var pmdRoot map[string]interface{}
	if err := json.Unmarshal(pmdBytes, &pmdRoot); err != nil {
		log.Fatal("Failed to parse PMD JSON:", err)
	}

	pmdScanResults, ok := pmdRoot["scan_results"].(map[string]interface{})
	if !ok {
		log.Error("PMD JSON missing 'scan_results'")
	}

	pmdResultsRaw, ok := pmdScanResults["Results"].([]interface{})
	if !ok {
		log.Error("PMD JSON malformed 'Results'")
	}

	pmdViolationsByFilename := make(map[string][]interface{})
	for _, resultEntry := range pmdResultsRaw {
		entryMap, ok := resultEntry.(map[string]interface{})
		if !ok {
			continue
		}

		files, ok := entryMap["files"].([]interface{})
		if !ok {
			continue
		}

		for _, file := range files {
			fileMap, ok := file.(map[string]interface{})
			if !ok {
				continue
			}

			filename, ok := fileMap["filename"].(string)
			if !ok {
				continue
			}

			if violations, ok := fileMap["violations"].([]interface{}); ok {
				pmdViolationsByFilename[filename] = append(pmdViolationsByFilename[filename], violations...)
			}
		}
	}

	// --- Load Repo Tree JSON ---
	repoTreeBytes, err := os.ReadFile(repoTreeFilePath)
	if err != nil {
		log.Error("Failed to read repo tree file:", err)
	}

	var repoTree models.RepoTreeFile
	if err := json.Unmarshal(repoTreeBytes, &repoTree); err != nil {
		log.Error("Failed to parse repo tree JSON:", err)
	}

	// --- Enrich Node tree with CSA and PMD results ---
	var enrich func(n *models.Node)
	enrich = func(n *models.Node) {
		if matches, found := cloudAdaptabilityByFilename[n.Name]; found {
			n.CloudSuitabilityResult = matches
		}
		if n.Type == "file" {
			for filePath, violations := range pmdViolationsByFilename {
				if strings.HasSuffix(filePath, n.Name) {
					n.CodeHealthViolations = violations
					break
				}
			}
		}
		for i := range n.Children {
			enrich(&n.Children[i])
		}
	}
	enrich(&repoTree.Result)

	// --- Save updated tree ---
	updatedBytes, err := json.MarshalIndent(repoTree, "", "  ")
	if err != nil {
		log.Error("Failed to marshal updated tree:", err)
	}

	if err := os.WriteFile(outputPath, updatedBytes, 0777); err != nil {
		log.Error("Failed to write updated JSON file:", err)
	}

	log.Info("Updated repo tree saved to: \n", outputPath)
}
