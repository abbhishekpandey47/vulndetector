package utils

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/sirupsen/logrus"
)

func GetCodeAnalyzerScanResultsPath(scanRequest models.ScanRequest, resultName string) (string, error) {
	// Get the logger instance
	log := logger.GetLogger()

	// Get the temp directory (hidden directory)
	tempDir, err := CreateTempDirectory()
	if err != nil {
		log.WithFields(logrus.Fields{
			"tenantID": scanRequest.TenantID,
			"runID":    scanRequest.RunID,
			"error":    err.Error(),
		}).Error("Failed to create temp directory")
		return "", err
	}

	// Construct the full path for code_analyser results in the format: /tmp/modernize/<tenantID>/<runID>/results/vuln_scan/
	codeAnalyserScanPath := filepath.Join(tempDir, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, resultName)

	// Create the code_analyser directory (if it doesn't exist)
	err = os.MkdirAll(codeAnalyserScanPath, 0777) // 0700 means only the owner can access it
	if err != nil {
		log.WithFields(logrus.Fields{
			"vulnScanPath": codeAnalyserScanPath,
			"error":        err.Error(),
		}).Error("Failed to create Result directory")
		return "", fmt.Errorf("failed to create code_analyser directory: %w", err)
	}

	log.WithFields(logrus.Fields{
		"ScanResultPath": codeAnalyserScanPath,
	}).Info("Successfully created results directory")
	return codeAnalyserScanPath, nil
}

func GetCodeAnalyzerVulnDBPath(dbName string) (string, error) {
	// Get the logger instance
	log := logger.GetLogger()

	// Get the temp directory (hidden directory)
	tempDir, err := CreateTempDirectory()
	if err != nil {
		log.WithFields(logrus.Fields{
			"error": err.Error(),
		}).Error("Failed to create temp directory")
		return "", err
	}

	// Construct the full path for code_analyser db in the format: /tmp/modernize/<tenantID>/<runID>/results/vuln_scan/
	codeAnalyserScanDBPath := filepath.Join(tempDir, "DB", dbName)

	// Create the code_analyser directory (if it doesn't exist)
	err = os.MkdirAll(codeAnalyserScanDBPath, 0777) 
	if err != nil {
		log.WithFields(logrus.Fields{
			"vulnDBPath": codeAnalyserScanDBPath,
			"error":      err.Error(),
		})
		return "", fmt.Errorf("failed to create code_analyser db directory: %w", err)
	}

	log.WithFields(logrus.Fields{
		"vulnDBPath": codeAnalyserScanDBPath,
	}).Info("Successfully created db directory")
	return codeAnalyserScanDBPath, nil
}

func GetCurrentTime() string {
	systemTime := time.Now().UTC()
	formattedTime := systemTime.Format("2006-01-02T15:04:05.") + fmt.Sprintf("%06d", systemTime.Nanosecond()/1000)
	return formattedTime
}

func GetfileNameCurrentTime() string {
	systemTime := time.Now().UTC()
	formattedTime := systemTime.Format("2006-01-02T15-04-05-") + fmt.Sprintf("%06d", systemTime.Nanosecond()/1000)
	return formattedTime
}
