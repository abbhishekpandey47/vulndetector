package utils

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"runtime"
	"strings"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/sirupsen/logrus"
)

// IsGitRepository checks if the URL is a Git repository (ends with .git).
func IsGitRepository(url string) bool {
	return strings.HasSuffix(url, ".git")
}

// GetDirectoryNameFromURL generates a directory name based on the URL, without `.git` for repositories.
func GetDirectoryNameFromURL(url string, scanRequest models.ScanRequest) string {
	// Get the logger instance
	log := logger.GetLogger()

	// If it's a Git repository, remove the ".git" suffix
	if IsGitRepository(url) {
		url = strings.TrimSuffix(url, ".git")
	}

	repoName := url[strings.LastIndex(url, "/")+1:]

	// Construct the directory name in the format: tenantID/scanID/repoName
	dirName := fmt.Sprintf("%s/%s/%s/%s/%s/%s/%s", scanRequest.TenantID, scanRequest.AppID, "sourceCode", scanRequest.ComponentID, scanRequest.ScanID, scanRequest.RunID, repoName)

	log.WithFields(logrus.Fields{
		"url":     url,
		"dirName": dirName,
	}).Debug("Generated directory name from URL")
	return dirName
}

// GetFileNameFromURL extracts the file name from the URL.
func GetFileNameFromURL(url string) string {
	// Get the logger instance
	log := logger.GetLogger()

	// If the URL ends with a '/', strip it off
	if strings.HasSuffix(url, "/") {
		url = url[:len(url)-1]
	}

	// Extract the file name by taking the part after the last '/'
	fileName := url[strings.LastIndex(url, "/")+1:]
	log.WithFields(logrus.Fields{
		"url":      url,
		"fileName": fileName,
	}).Debug("Extracted file name from URL")
	return fileName
}

func CreateTempDirectory() (string, error) {
	// Define the base directory as /modernize-data
	baseDir := constant.BasePath

	// Define the hidden directory path (e.g., /modernize-data/US)
	//hiddenDir := baseDir

	// Create the directory (if it doesn't exist)
	err := os.MkdirAll(baseDir, 0777)
	if err != nil {
		log.Println("Failed to create directory in /modernize-data")
		return "", fmt.Errorf("failed to create directory in /modernize-data: %w", err)
	}

	// For Windows, set the "hidden" and "system" attributes using the attrib command
	if runtime.GOOS == "windows" {
		err := exec.Command("attrib", "+h", "+s", baseDir).Run()
		if err != nil {
			log.Println("Failed to set hidden and system attributes on Windows")
			return "", fmt.Errorf("failed to set hidden and system attributes on Windows: %w", err)
		}
	}

	log.Println("Successfully created directory:", baseDir)
	return baseDir, nil
}
