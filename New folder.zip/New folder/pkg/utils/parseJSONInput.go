package utils

import (
	"encoding/json"
	"log"

	"github.com/scanner/models"
)

// ParseJSONInput parses the JSON strings for requestType, repoDetails, and scanRequest
// and returns the unmarshalled structs and any error encountered.
func ParseJSONInput(requestTypeStr, repoDetailsStr, scanRequestStr, sourceCodePathStr, envTypeStr, modeStr string) (models.RequestType, models.RepoDetails, models.ScanRequest, models.SourceCodeDetails, models.EnvType, models.Mode, error) {
	// Create instances of the respective structs to hold the unmarshalled data
	var requestType models.RequestType
	var repoDetails models.RepoDetails
	var scanRequest models.ScanRequest
	var fileSystemDetails models.SourceCodeDetails
	var envType models.EnvType
	var mode models.Mode

	// Unmarshal requestType JSON string
	if requestTypeStr != "" {
		err := json.Unmarshal([]byte(requestTypeStr), &requestType)
		if err != nil {
			log.Printf("Error unmarshalling requestType JSON: %v", err)
			return models.RequestType{}, models.RepoDetails{}, models.ScanRequest{}, models.SourceCodeDetails{}, models.EnvType{}, models.Mode{}, err
		}
	}

	// Unmarshal repoDetails JSON string
	if repoDetailsStr != "" {
		err := json.Unmarshal([]byte(repoDetailsStr), &repoDetails)
		if err != nil {
			log.Printf("Error unmarshalling repoDetails JSON: %v", err)
			return models.RequestType{}, models.RepoDetails{}, models.ScanRequest{}, models.SourceCodeDetails{}, models.EnvType{}, models.Mode{}, err
		}
	}

	// Unmarshal scanRequest JSON string
	if scanRequestStr != "" {
		err := json.Unmarshal([]byte(scanRequestStr), &scanRequest)
		if err != nil {
			log.Printf("Error unmarshalling scanRequest JSON: %v", err)
			return models.RequestType{}, models.RepoDetails{}, models.ScanRequest{}, models.SourceCodeDetails{}, models.EnvType{}, models.Mode{}, err
		}
	}
	if sourceCodePathStr != "" {
		err := json.Unmarshal([]byte(sourceCodePathStr), &fileSystemDetails)
		if err != nil {
			log.Printf("Error unmarshalling requestType JSON: %v", err)
			return models.RequestType{}, models.RepoDetails{}, models.ScanRequest{}, models.SourceCodeDetails{}, models.EnvType{}, models.Mode{}, err
		}
	}

	// Unmarshal envType JSON string
	if envTypeStr != "" {
		err := json.Unmarshal([]byte(envTypeStr), &envType)
		if err != nil {
			log.Printf("Error unmarshalling envType JSON: %v", err)
			return models.RequestType{}, models.RepoDetails{}, models.ScanRequest{}, models.SourceCodeDetails{}, models.EnvType{}, models.Mode{}, err
		}
	}

	// Unmarshal mode JSON string
	if modeStr != "" {
		err := json.Unmarshal([]byte(modeStr), &mode)
		if err != nil {
			log.Printf("Error unmarshalling mode JSON: %v", err)
			return models.RequestType{}, models.RepoDetails{}, models.ScanRequest{}, models.SourceCodeDetails{}, models.EnvType{}, models.Mode{}, err
		}
	}
	// Return the unmarshalled structs and no error
	return requestType, repoDetails, scanRequest, fileSystemDetails, envType, mode, nil
}
