package utils

import (
	"bytes"
	"fmt"
	"os/exec"
)

// GetContainerIP executes the `hostname -i` command to get the container's IP address.
func GetContainerIP() (string, error) {
	cmd := exec.Command("hostname", "-i")
	var out bytes.Buffer
	cmd.Stdout = &out
	err := cmd.Run()
	if err != nil {
		return "", fmt.Errorf("error running hostname command: %v", err)
	}

	ipAddress := out.String()
	if ipAddress == "" {
		return "", fmt.Errorf("no IP address found")
	}

	return ipAddress, nil
}
