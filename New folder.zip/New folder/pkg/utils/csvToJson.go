package utils

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"os"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/sirupsen/logrus"
)

// Struct for the final output
type ScanResultWrapper struct {
	ScanRequest models.ScanRequest `json:"scan_request"`
	ScanType    string             `json:"scan_type"`
	TechStack   string             `json:"tech_stack"`
	ScanResults struct {
		Results []map[string]string `json:"Results"`
	} `json:"scan_results"`
}

// Function to convert CSV file to JSON
func ConvertCSVToJSON(csvFilePath, outputDir string, scanRequest models.ScanRequest, language []string) (string, error) {
	log := logger.GetLogger()
	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.CSAScanInProgress,
		"progress":    constant.ProgressValueSixtyfive,
		"statusMsg":   constant.ScanStatusInProgress,
	}).Info("====SendLogMessage ====API:  Cloud Adaptability Scan InProgress.==== payload===")

	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusInProgress,
	}).Info("====Change Status ====Cloud Adaptability Scan request InProgress==== API Request Payload == ")
	log.Println("14th API Request Intiated====", constant.APIEnable)
	SendLogMessage(scanRequest, constant.CSAScanInProgress, constant.ProgressValueSixtyfive)
	SendStatus(scanRequest, constant.ScanStatusInProgress)
	log.Println("14th API Request completed====", constant.CSAScanInProgress)

	// Open the CSV file
	log.Info("csv file path : ", csvFilePath)
	file, err := os.Open(csvFilePath)
	if err != nil {
		return "", fmt.Errorf("error opening CSV file: %v", err)
	}
	defer file.Close()

	// Read the CSV file
	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return "", fmt.Errorf("error reading CSV file: %v", err)
	}

	// Convert CSV records to JSON format
	var result []map[string]string
	headers := records[0] // The first row is the header

	for _, row := range records[1:] {
		recordMap := make(map[string]string)
		for i, header := range headers {
			recordMap[header] = row[i]
		}
		result = append(result, recordMap)
	}

	// Wrap the result with ScanRequest
	scanRequest.LaunchedOn = GetCurrentTime()
	wrappedResult := ScanResultWrapper{
		ScanRequest: scanRequest,
		ScanType:    constant.ScannerTypeCloudAdaptability,
		TechStack:   language[0],
		ScanResults: struct {
			Results []map[string]string `json:"Results"`
		}{
			Results: result,
		},
	}

	// Convert the wrapped result to JSON
	jsonData, err := json.MarshalIndent(wrappedResult, "", "  ")
	if err != nil {
		ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to create cloud-adaptability scan result file: %v", err))
		ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to create cloud-adaptability scan result file: %v", err), constant.ProgressValueSixtyfive)
		return "", fmt.Errorf("error converting to JSON: %v", err)
	}

	// Write the JSON data to a file
	//fileTimestamp := GetfileNameCurrentTime()
	jsonFileName := "cloud-adaptability.json"
	jsonFilePath := fmt.Sprintf("%s/%s", outputDir, jsonFileName)
	err = os.WriteFile(jsonFilePath, jsonData, 0777)
	if err != nil {
		ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to write cloud-adaptability scan result in file: %v", err))
		ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to write cloud-adaptability scan result in file: %v", err), constant.ProgressValueSeventyFive)
		return "", fmt.Errorf("error writing JSON file: %v", err)
	}
	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"fileName":    jsonFilePath,
		"scannerType": constant.ScannerTypeCloudAdaptability,
	}).Info("====InsertResultFileToKafka ==== Cloud Adaptability Result File Generated successfully. ==== API Request Payload == ")

	SendApiRequest(scanRequest, jsonFilePath, constant.ScannerTypeCloudAdaptability)

	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.CSAScanCompleted,
		"progress":    constant.ProgressValueSeventyFive,
		"statusMsg":   constant.ScanStatusInProgress,
	}).Info("====SendLogMessage ====API:  Cloud Adaptability Scan Completed.==== payload===")
	scanRequest.LaunchedOn = GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusInProgress,
	}).Info("====Change Status ====Cloud Adaptability Scan request Completed==== API Request Payload == ")
	log.Println("15th API Request Intiated====", constant.APIEnable)
	SendLogMessage(scanRequest, constant.CSAScanCompleted, constant.ProgressValueSeventyFive)
	SendStatus(scanRequest, constant.ScanStatusInProgress)
	log.Println("15th API Request completed====", constant.CSAScanCompleted)

	log.Printf("CSA scan results converted to JSON and saved to %s", jsonFilePath)
	return jsonFilePath, nil
}
