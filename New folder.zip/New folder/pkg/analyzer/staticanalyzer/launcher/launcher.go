package launcher

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	csharp "github.com/scanner/pkg/analyzer/staticanalyzer/languages/dotnet"
	"github.com/scanner/pkg/analyzer/staticanalyzer/languages/java"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	"github.com/sirupsen/logrus"
)

type CodeHealthResultWrapper struct {
	ScanRequest models.ScanRequest `json:"scan_request"`
	ScanType    string             `json:"scan_type"`
	TechStack   string             `json:"tech_stack"`
	Issues      []interface{}      `json:"issues"`
}

func StaicCheckProcess(path string, scanRequest models.ScanRequest, language []string) (string, error) {
	log := logger.GetLogger()
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.CodeHealthInitiating,
		"progress":    constant.ProgressValueEighty,
	}).Info("====SendLogMessage ====API:  Intiating Code Health Scan.==== payload===")
	log.Println("16th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.CodeHealthInitiating, constant.ProgressValueEighty)
	log.Println("16th API Request completed====", constant.CodeHealthInitiating)

	fmt.Println("StaicCheckProcess File Path: ", path)

	analyzer := core.NewAnalyzer()
	analyzer.RegisterLanguage(&java.JavaLanguage{})

	// Register languages and process files based on their extensions
	extensions := map[string]core.Language{
		".java": &java.JavaLanguage{},
		".cs":   &csharp.CSharpLanguage{},
	}
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.CodeHealthInProgress,
		"progress":    constant.ProgressValueNinety,
	}).Info("====SendLogMessage ====API: Code Health Scan InProgress.==== payload===")
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusInProgress,
	}).Info("====Change Status ====Code Health Scan request InProgress==== API Request Payload == ")
	log.Println("17th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.CodeHealthInProgress, constant.ProgressValueNinety)
	utils.SendStatus(scanRequest, constant.ScanStatusInProgress)
	log.Println("17th API Request completed====", constant.CodeHealthInProgress)
	var (
		resultFilePathFull string
		err                error
	)
	for ext, lang := range extensions {
		analyzer.RegisterLanguage(lang)

		switch ext {
		case ".java", ".cs":
			resultFilePathFull, err = processFilesByExtension(path, ext, analyzer, scanRequest, language)
			if err != nil {
				utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to genrete code health scan results to result file %v", err))
				utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to genrete code health scan results to result file %v", err), constant.ProgressValueNinety)
				return "", err
			}
		default:
			fmt.Printf("No processing logic defined for extension: %s\n", ext)
		}
	}
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.CodeHealthCompleted,
		"progress":    constant.ProgressValueNinetyFive,
	}).Info("====SendLogMessage ====API: Code Health Scan Completed.==== payload===")
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusInProgress,
	}).Info("====Change Status ====Code Health Scan request Completed==== API Request Payload == ")

	log.Println("18th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.CodeHealthCompleted, constant.ProgressValueNinetyFive)
	utils.SendStatus(scanRequest, constant.ScanStatusInProgress)
	log.Println("18th API Request completed====", constant.CodeHealthCompleted)

	fmt.Println("Static analysis completed successfully")
	return resultFilePathFull, nil
}

func processFilesByExtension(path, extension string, analyzer *core.Analyzer, scanRequest models.ScanRequest, language []string) (string, error) {
	log := logger.GetLogger()
	files, err := getFilesInDirectory(path, extension)
	if err != nil {
		return "", err
	}
	fullPath, err := generateCodeHealthResultPath(scanRequest)
	if err != nil {
		log.Error("Path generation failed:", err)
		return "", err
	}
	pb := utils.New(len(files), "Processing files for Static Analysis")

	// Initialize appropriate stats type based on extension
	var projectStats interface{}
	var javaStats core.Stats
	var dotNetStats core.DotNetStats

	if extension == ".java" {
		projectStats = &javaStats
	} else if extension == ".cs" {
		projectStats = &dotNetStats
	}

	fileResults := []core.FileResult{}

	for _, p := range files {
		pb.Add()
		issues, metrics, tree, sourceCode, err := analyzer.ProcessFile(p)
		if err != nil {
			log.Fatal(err)
		}

		if len(issues) > 0 {
			fileResults = append(fileResults, core.FileResult{
				Filename:              p,
				PublicConstantCount:   metrics.PublicConstantCount,
				PrivateConstantCount:  metrics.PrivateConstantCount,
				PublicMethodCount:     metrics.PublicMethodCount,
				PrivateMethodCount:    metrics.PrivateMethodCount,
				UtilityMethodCount:    metrics.UtilityMethodCount,
				InstanceVariableCount: metrics.InstanceVariableCount,
				InnerClassCount:       metrics.InnerClassCount,
				Violations:            issues,
			})
		}

		// Handle stats accumulation based on file type
		if extension == ".java" {
			// Accumulate metrics from file into Java projectStats
			AccumulateMetricsIntoStats(&javaStats, metrics)
			fileStats := java.CollectFileStats(tree, sourceCode)
			AccumulateStats(&javaStats, fileStats)
		} else if extension == ".cs" {
			// Accumulate metrics from file into CSharp projectStats
			csharpLang := &csharp.CSharpLanguage{}
			fileStats := csharpLang.CollectDotNetStats(tree, sourceCode)
			AccumulateDotNetStats(&dotNetStats, fileStats)
		}
	}

	// Calculate general after accumulation based on stats type
	if extension == ".java" {
		javaStats.General = javaStats.ClassCount +
			javaStats.AbstractClassCount +
			javaStats.GenericClassCount +
			javaStats.EJBInterfaceCount +
			javaStats.InterfaceCount +
			javaStats.InterfaceMethodCount +
			javaStats.FinalClassCount +
			javaStats.PackageProtectedClassCount +
			javaStats.PublicConstantCount +
			javaStats.PrivateConstantCount +
			javaStats.PublicMethodCount +
			javaStats.PrivateMethodCount +
			javaStats.UtilityMethodCount +
			javaStats.GenericMethodCount +
			javaStats.InstanceVariableCount +
			javaStats.AnnotationCount +
			javaStats.EnumCount +
			javaStats.ConstructorCount +
			javaStats.RecordCount +
			javaStats.ConstantCount +
			javaStats.StaticInitializerCount +
			javaStats.EJBClassCount +
			javaStats.LocalVariableCount +
			javaStats.GenericNaming
		projectStats = javaStats
	} else if extension == ".cs" {
		dotNetStats.General = dotNetStats.AssemblyCount + dotNetStats.ClassCount + dotNetStats.EnumCount +
			dotNetStats.EventCount + dotNetStats.FieldCount + dotNetStats.FileCount +
			dotNetStats.InterfaceCount + dotNetStats.MethodCount + dotNetStats.NamespaceCount +
			dotNetStats.ObjectCount + dotNetStats.ParameterCount + dotNetStats.PropertyCount +
			dotNetStats.ResourceCount + dotNetStats.StringLiteralCount + dotNetStats.StructCount +
			dotNetStats.VariableCount
		projectStats = dotNetStats
	}

	if len(fileResults) > 0 {
		result := core.ResultSet{
			FormatVersion: 0,
			Timestamp:     time.Now().UTC().Format(time.RFC3339),
			Files:         fileResults,
			Stats:         projectStats,
		}

		wrapper := core.ScanResultsWrapper{
			ScanRequest: scanRequest,
			TechStack:   language[0],
			ScanType:    constant.ScannerTypeCodeHealth,
		}
		wrapper.ScanResults.Results = append(wrapper.ScanResults.Results, result)

		jsonOutput, _ := json.MarshalIndent(wrapper, "", "  ")
		err = os.WriteFile(fullPath, jsonOutput, 0777)
		if err != nil {
			utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to writing code health scan results to result file %v", err))
			utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to writing code health scan results to result file %v", err), constant.ProgressValueNinety)
			fmt.Println("Error writing file:", err)
			return "", err
		}
		scanRequest.LaunchedOn = utils.GetCurrentTime()
		log.WithFields(logrus.Fields{
			"scanRequest": scanRequest,
			"fileName":    fullPath,
			"scannerType": constant.ScannerTypeCodeHealth,
		}).Info("====InsertResultFileToKafka ==== Code Health Result File Generated successfully. ==== API Request Payload == ")

		utils.SendApiRequest(scanRequest, fullPath, constant.ScannerTypeCodeHealth)

	} else {
		fmt.Printf("No issues found for %s files. Skipping file creation.\n", extension)
	}

	elapsed := pb.Finish()
	fmt.Printf("Done in %v\n", elapsed.Round(time.Second))
	fmt.Printf("JSON written for %s files successfully\n", extension)

	return fullPath, nil
}

var FileTime = utils.GetfileNameCurrentTime()

func generateCodeHealthResultPath(scanRequest models.ScanRequest) (string, error) {
	basePath, err := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "code-health")
	if err != nil {
		return "", err
	}
	fileName := "code-health.json"
	return filepath.Join(basePath, fileName), nil
}

// AccumulateStats accumulates file-level stats into project-level stats
func AccumulateStats(stats *core.Stats, fileStats core.Stats) {
	stats.ClassCount += fileStats.ClassCount
	stats.AbstractClassCount += fileStats.AbstractClassCount
	stats.GenericClassCount += fileStats.GenericClassCount
	stats.EJBInterfaceCount += fileStats.EJBInterfaceCount
	stats.InterfaceCount += fileStats.InterfaceCount
	stats.InterfaceMethodCount += fileStats.InterfaceMethodCount
	stats.FinalClassCount += fileStats.FinalClassCount
	stats.PackageProtectedClassCount += fileStats.PackageProtectedClassCount
	stats.UtilityMethodCount += fileStats.UtilityMethodCount
	stats.GenericMethodCount += fileStats.GenericMethodCount
	stats.InstanceVariableCount += fileStats.InstanceVariableCount
	stats.AnnotationCount += fileStats.AnnotationCount
	stats.EnumCount += fileStats.EnumCount
	stats.ConstructorCount += fileStats.ConstructorCount
	stats.RecordCount += fileStats.RecordCount
	stats.ConstantCount += fileStats.ConstantCount
	stats.StaticInitializerCount += fileStats.StaticInitializerCount
	stats.EJBClassCount += fileStats.EJBClassCount
	stats.LocalVariableCount += fileStats.LocalVariableCount
	stats.GenericNaming += fileStats.GenericNaming
}

// Accumulate only the fields present in FileMetrics into the overall Stats
func AccumulateMetricsIntoStats(stats *core.Stats, metrics core.FileMetrics) {
	// Only accumulate fields that are unique to FileMetrics and not handled by CollectFileStats
	stats.PublicConstantCount += metrics.PublicConstantCount
	stats.PrivateConstantCount += metrics.PrivateConstantCount
	stats.PublicMethodCount += metrics.PublicMethodCount
	stats.PrivateMethodCount += metrics.PrivateMethodCount
}

// AccumulateDotNetStats accumulates file-level DotNet stats into project-level DotNet stats
func AccumulateDotNetStats(stats *core.DotNetStats, fileStats core.DotNetStats) {
	stats.AssemblyCount += fileStats.AssemblyCount
	stats.ClassCount += fileStats.ClassCount
	stats.EnumCount += fileStats.EnumCount
	stats.EventCount += fileStats.EventCount
	stats.FieldCount += fileStats.FieldCount
	stats.FileCount += fileStats.FileCount
	stats.InterfaceCount += fileStats.InterfaceCount
	stats.MethodCount += fileStats.MethodCount
	stats.NamespaceCount += fileStats.NamespaceCount
	stats.ObjectCount += fileStats.ObjectCount
	stats.ParameterCount += fileStats.ParameterCount
	stats.PropertyCount += fileStats.PropertyCount
	stats.ResourceCount += fileStats.ResourceCount
	stats.StringLiteralCount += fileStats.StringLiteralCount
	stats.StructCount += fileStats.StructCount
	stats.VariableCount += fileStats.VariableCount
}

// Helper function to retrieve files with a specific extension in a directory
func getFilesInDirectory(path, extension string) ([]string, error) {
	var files []string

	err := filepath.Walk(path, func(filePath string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if strings.HasSuffix(info.Name(), extension) {
			files = append(files, filePath)
		}
		return nil
	})

	if err != nil {
		return nil, err
	}

	return files, nil
}
