package performance

import (
	"fmt"
	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type AvoidFileStreamRule struct{}

func (r *AvoidFileStreamRule) Rule() string           { return "AvoidFileStream" }
func (r *AvoidFileStreamRule) RuleSet() string        { return "Performance" }
func (r *AvoidFileStreamRule) Classification() string { return "Performance" }
func (r *AvoidFileStreamRule) Priority() int          { return 3 }

func (r *AvoidFileStreamRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for object creation expressions
	query := `
	(object_creation_expression
		type: (type_identifier) @class_name
	) @creation
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var className string
		var creationNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "class_name":
				className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "creation":
				creationNode = capture.Node
			}
		}

		if creationNode != nil && isProblematicFileClass(className) {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Use Files.new* methods from java.nio instead of %s to avoid garbage collection pauses. For example, use Files.newInputStream(Paths.get(fileName)) instead of new %s(fileName)", className, className),
				Priority:       r.Priority(),
				BeginLine:      int(creationNode.StartPoint().Row + 1),
				BeginColumn:    int(creationNode.StartPoint().Column + 1),
				EndLine:        int(creationNode.EndPoint().Row + 1),
				EndColumn:      int(creationNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

func isProblematicFileClass(className string) bool {
	problematicClasses := []string{"FileInputStream", "FileOutputStream", "FileReader", "FileWriter"}
	for _, class := range problematicClasses {
		if strings.Contains(className, class) {
			return true
		}
	}
	return false
}

func (r *AvoidFileStreamRule) GetDescription() string {
	return `The FileInputStream and FileOutputStream classes contain a finalizer method which causes garbage
collection pauses. Similarly, FileReader and FileWriter constructors instantiate FileInputStream and
FileOutputStream, causing the same issues.

Recommended alternatives:
* Use Files.newInputStream(Paths.get(fileName)) instead of new FileInputStream(fileName)
* Use Files.newOutputStream(Paths.get(fileName)) instead of new FileOutputStream(fileName)
* Use Files.newBufferedReader(Paths.get(fileName)) instead of new FileReader(fileName)
* Use Files.newBufferedWriter(Paths.get(fileName)) instead of new FileWriter(fileName)

Note: java.nio API throws NoSuchFileException instead of FileNotFoundException. Both are subclasses
of IOException, so catching IOException will handle both cases.`
}
