package performance

import (
	"context"
	"testing"

	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestAvoidFileStreamRule(t *testing.T) {
	rule := &AvoidFileStreamRule{}

	// Test basic rule properties
	assert.Equal(t, "AvoidFileStream", rule.Rule())
	assert.Equal(t, "Performance", rule.RuleSet())
	assert.Equal(t, "Performance", rule.Classification())
	assert.Equal(t, 3, rule.Priority())

	tests := []struct {
		name           string
		javaCode       string
		expectedIssues int
		expectedClass  string
	}{
		{
			name: "FileInputStream usage",
			javaCode: `
public class Test {
    public void readFile() {
        FileInputStream fis = new FileInputStream("test.txt");
    }
}`,
			expectedIssues: 1,
			expectedClass:  "FileInputStream",
		},
		{
			name: "FileOutputStream usage",
			javaCode: `
public class Test {
    public void writeFile() {
        FileOutputStream fos = new FileOutputStream("test.txt");
    }
}`,
			expectedIssues: 1,
			expectedClass:  "FileOutputStream",
		},
		{
			name: "FileReader usage",
			javaCode: `
public class Test {
    public void readFile() {
        FileReader fr = new FileReader("test.txt");
    }
}`,
			expectedIssues: 1,
			expectedClass:  "FileReader",
		},
		{
			name: "FileWriter usage",
			javaCode: `
public class Test {
    public void writeFile() {
        FileWriter fw = new FileWriter("test.txt");
    }
}`,
			expectedIssues: 1,
			expectedClass:  "FileWriter",
		},
		{
			name: "Multiple file stream usages",
			javaCode: `
public class Test {
    public void useStreams() {
        FileInputStream fis = new FileInputStream("input.txt");
        FileOutputStream fos = new FileOutputStream("output.txt");
        FileReader fr = new FileReader("read.txt");
        FileWriter fw = new FileWriter("write.txt");
    }
}`,
			expectedIssues: 4,
		},
		{
			name: "No file stream usage",
			javaCode: `
public class Test {
    public void useNioFiles() {
        Path path = Paths.get("test.txt");
        InputStream is = Files.newInputStream(path);
        OutputStream os = Files.newOutputStream(path);
    }
}`,
			expectedIssues: 0,
		},
		{
			name: "Other class instantiation",
			javaCode: `
public class Test {
    public void createObjects() {
        String str = new String("test");
        ArrayList<String> list = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();
    }
}`,
			expectedIssues: 0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Parse the Java code
			parser := sitter.NewParser()
			parser.SetLanguage(java.GetLanguage())

			tree, err := parser.ParseCtx(context.Background(), nil, []byte(tt.javaCode))
			require.NoError(t, err, "Failed to parse Java code")
			require.NotNil(t, tree, "Parse tree should not be nil")

			// Analyze with the rule
			issues := rule.Analyze(tree, []byte(tt.javaCode), nil)

			// Verify number of issues
			assert.Equal(t, tt.expectedIssues, len(issues), "Expected %d issues, got %d", tt.expectedIssues, len(issues))

			// Verify issue details
			if tt.expectedIssues > 0 {
				for _, issue := range issues {
					assert.Equal(t, "AvoidFileStream", issue.Rule)
					assert.Equal(t, "Performance", issue.RuleSet)
					assert.Equal(t, "Performance", issue.Classification)
					assert.Equal(t, 3, issue.Priority)
					assert.Contains(t, issue.Description, "Files.new* methods from java.nio")
					assert.Greater(t, issue.BeginLine, 0)
					assert.Greater(t, issue.BeginColumn, 0)
					assert.Greater(t, issue.EndLine, 0)
					assert.Greater(t, issue.EndColumn, 0)

					if tt.expectedClass != "" {
						assert.Contains(t, issue.Description, tt.expectedClass)
					}
				}
			}
		})
	}
}

func TestAvoidFileStreamRule_GetDescription(t *testing.T) {
	rule := &AvoidFileStreamRule{}
	description := rule.GetDescription()

	assert.Contains(t, description, "FileInputStream")
	assert.Contains(t, description, "FileOutputStream")
	assert.Contains(t, description, "FileReader")
	assert.Contains(t, description, "FileWriter")
	assert.Contains(t, description, "Files.newInputStream")
	assert.Contains(t, description, "Files.newOutputStream")
	assert.Contains(t, description, "Files.newBufferedReader")
	assert.Contains(t, description, "Files.newBufferedWriter")
	// Fix: Check for "garbage" and "collection" separately since there may be newlines
	assert.Contains(t, description, "garbage")
	assert.Contains(t, description, "collection")
}

func TestIsProblematicFileClass(t *testing.T) {
	tests := []struct {
		className string
		expected  bool
	}{
		{"FileInputStream", true},
		{"FileOutputStream", true},
		{"FileReader", true},
		{"FileWriter", true},
		{"BufferedInputStream", false},
		{"BufferedOutputStream", false},
		{"String", false},
		{"ArrayList", false},
		{"", false},
	}

	for _, tt := range tests {
		t.Run(tt.className, func(t *testing.T) {
			result := isProblematicFileClass(tt.className)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestAvoidFileStreamRule_ErrorHandling(t *testing.T) {
	rule := &AvoidFileStreamRule{}

	// Test with empty but valid tree
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	emptyCode := ""
	tree, err := parser.ParseCtx(context.Background(), nil, []byte(emptyCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(emptyCode), nil)
	assert.Equal(t, 0, len(issues), "Should handle empty input gracefully")

	// Test with malformed Java code that still parses
	malformedCode := "public class Test { }"
	tree2, err := parser.ParseCtx(context.Background(), nil, []byte(malformedCode))
	require.NoError(t, err)

	if tree2 != nil {
		// Even with simple code, the rule should not crash
		issues := rule.Analyze(tree2, []byte(malformedCode), nil)
		assert.NotNil(t, issues, "Issues slice should not be nil")
		assert.Equal(t, 0, len(issues), "Should find no issues in simple code")
	}
}
