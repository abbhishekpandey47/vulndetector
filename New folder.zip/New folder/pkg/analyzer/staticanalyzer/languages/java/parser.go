package java

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	"github.com/scanner/pkg/analyzer/staticanalyzer/languages/java/errorprone"
	"github.com/scanner/pkg/analyzer/staticanalyzer/languages/java/multithreading"
	"github.com/scanner/pkg/analyzer/staticanalyzer/languages/java/performance"
	"github.com/scanner/pkg/analyzer/staticanalyzer/languages/java/security"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type JavaLanguage struct{}

func (j *JavaLanguage) Name() string                  { return "java" }
func (j *JavaLanguage) SupportedExtensions() []string { return []string{".java"} }

func (j *JavaLanguage) Parse(filePath string) (interface{}, error) {
	code, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())
	tree, err := parser.ParseCtx(context.Background(), nil, code)
	if err != nil {
		return nil, err
	}

	if tree.RootNode().HasError() {
		return nil, fmt.Errorf("syntax error in Java file")
	}

	return tree, nil
}

func (j *JavaLanguage) CollectMetrics(tree *sitter.Tree, src []byte) staticanalyzer.FileMetrics {
	metrics := staticanalyzer.FileMetrics{}
	root := tree.RootNode()

	var walk func(*sitter.Node)
	walk = func(node *sitter.Node) {
		if node == nil {
			return
		}

		switch node.Type() {
		case "class_declaration":
			// Check if this is an inner class (nested within another class)
			parent := node.Parent()
			for parent != nil {
				if parent.Type() == "class_declaration" {
					metrics.InnerClassCount++
					break
				}
				parent = parent.Parent()
			}
		case "method_declaration":
			isPublic := false
			isPrivate := false
			isStatic := false
			var methodName string

			for i := 0; i < int(node.ChildCount()); i++ {
				child := node.Child(i)
				if child.Type() == "modifiers" {
					for k := 0; k < int(child.ChildCount()); k++ {
						modifier := child.Child(k)
						switch string(modifier.Content(src)) {
						case "public":
							isPublic = true
						case "private":
							isPrivate = true
						case "static":
							isStatic = true
						}
					}
				}
				if child.Type() == "identifier" {
					methodName = string(child.Content(src))
				}
			}

			// Check if it's a constructor
			isConstructor := false
			if parent := node.Parent(); parent != nil && parent.Type() == "class_body" {
				if classDecl := parent.Parent(); classDecl != nil && classDecl.Type() == "class_declaration" {
					if classNameNode := classDecl.ChildByFieldName("name"); classNameNode != nil {
						if methodName == string(classNameNode.Content(src)) {
							isConstructor = true
						}
					}
				}
			}

			if !isConstructor {
				if isPublic && isStatic {
					metrics.UtilityMethodCount++
				} else if isPublic && !isStatic {
					metrics.PublicMethodCount++
				} else if isPrivate {
					metrics.PrivateMethodCount++
				}
			}

		case "field_declaration":
			isPublic := false
			isPrivate := false
			isStatic := false
			isFinal := false

			for i := 0; i < int(node.ChildCount()); i++ {
				child := node.Child(i)
				if child.Type() == "modifiers" {
					for k := 0; k < int(child.ChildCount()); k++ {
						modifier := child.Child(k)
						switch string(modifier.Content(src)) {
						case "public":
							isPublic = true
						case "private":
							isPrivate = true
						case "static":
							isStatic = true
						case "final":
							isFinal = true
						}
					}
				}
			}

			// Use a query to robustly count all declarators in this field declaration.
			// This correctly handles multi-variable declarations like "int a, b, c;".
			count := 0
			q, err := sitter.NewQuery([]byte("(variable_declarator) @vd"), java.GetLanguage())
			if err == nil {
				qc := sitter.NewQueryCursor()
				qc.Exec(q, node)
				for {
					_, ok := qc.NextMatch()
					if !ok {
						break
					}
					count++
				}
			}

			if isStatic && isFinal {
				if isPublic {
					metrics.PublicConstantCount += count
				} else if isPrivate {
					metrics.PrivateConstantCount += count
				}
			} else if !isStatic {
				metrics.InstanceVariableCount += count
			}
		case "record_declaration":
			// Record components are effectively instance variables.
			// (record_declaration parameters: (formal_parameters ...))
			params := node.ChildByFieldName("parameters")
			if params != nil {
				// Each formal_parameter is a component
				q, err := sitter.NewQuery([]byte("(formal_parameter) @param"), java.GetLanguage())
				if err == nil {
					qc := sitter.NewQueryCursor()
					qc.Exec(q, params)
					for {
						_, ok := qc.NextMatch()
						if !ok {
							break
						}
						metrics.InstanceVariableCount++
					}
				}
			}
		}

		for i := 0; i < int(node.ChildCount()); i++ {
			walk(node.Child(i))
		}
	}

	walk(root)
	return metrics
}

func CollectFileStats(tree *sitter.Tree, src []byte) staticanalyzer.Stats {
	root := tree.RootNode()
	stats := staticanalyzer.Stats{}
	qc := sitter.NewQueryCursor()

	queries := map[string]string{
		"class_count":              `(class_declaration) @class`,
		"abstract_class_count":     `(class_declaration) @class`,
		"generic_class_count":      `(class_declaration (type_parameters) @class)`,
		"interface_count":          `(interface_declaration) @interface`,
		"interface_method_count":   `(interface_body (method_declaration) @method)`,
		"annotation_method_count":  `(annotation_type_element_declaration) @method`,
		"final_class_count":        `(class_declaration) @class`,
		"generic_method_count":     `(method_declaration (type_parameters)) @method`,
		"annotation_count":         `(annotation_type_declaration) @annotation`,
		"enum_count":               `(enum_declaration) @enum`,
		"constructor_count":        `(constructor_declaration) @constructor`,
		"record_count":             `(record_declaration) @record`,
		"static_initializer_count": `(static_initializer) @init`,
		"local_variable_count":     `(local_variable_declaration) @var`,
		"instance_variable_count":  `(field_declaration) @field`,
		"package_protected_class":  `(class_declaration) @class`,
		"utility_method_count":     `(method_declaration) @method`,
		"constant_count":           `(field_declaration) @field`,
		"ejb_class_count":          `(class_declaration) @class`,
		"ejb_interface_count":      `(interface_declaration) @interface`,
	}

	for key, queryStr := range queries {
		q, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
		if err != nil {
			continue // Or handle error
		}
		qc.Exec(q, root)
		for {
			m, ok := qc.NextMatch()
			if !ok {
				break
			}
			for _, c := range m.Captures {
				captureName := q.CaptureNameForId(c.Index)
				switch key {
				case "class_count":
					if captureName == "class" {
						stats.ClassCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "abstract_class_count":
					if captureName == "class" {
						isAbstract := false

						for i := 0; i < int(c.Node.ChildCount()); i++ {
							child := c.Node.Child(i)
							if child.Type() == "modifiers" {
								for k := 0; k < int(child.ChildCount()); k++ {
									modifier := child.Child(k)
									modStr := string(modifier.Content(src))
									if modStr == "abstract" {
										isAbstract = true
										break
									}
								}
							}
						}

						if isAbstract {
							stats.AbstractClassCount++
						}
					}
				case "generic_class_count":
					if captureName == "class" {
						stats.GenericClassCount++
					}
				case "interface_count":
					if captureName == "interface" {
						stats.InterfaceCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "interface_method_count":
					if captureName == "method" {
						stats.InterfaceMethodCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "annotation_method_count":
					if captureName == "method" {
						stats.InterfaceMethodCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "final_class_count":
					if captureName == "class" {
						isFinal := false

						for i := 0; i < int(c.Node.ChildCount()); i++ {
							child := c.Node.Child(i)
							if child.Type() == "modifiers" {
								for k := 0; k < int(child.ChildCount()); k++ {
									modifier := child.Child(k)
									modStr := string(modifier.Content(src))
									if modStr == "final" {
										isFinal = true
										break
									}
								}
							}
						}

						if isFinal {
							stats.FinalClassCount++
						}
					}
				case "generic_method_count":
					if captureName == "method" {
						stats.GenericMethodCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "annotation_count":
					if captureName == "annotation" {
						stats.AnnotationCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "enum_count":
					if captureName == "enum" {
						stats.EnumCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "constructor_count":
					if captureName == "constructor" {
						stats.ConstructorCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "record_count":
					if captureName == "record" {
						stats.RecordCount++
						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "static_initializer_count":
					if captureName == "init" {
						stats.StaticInitializerCount++
					}
				case "local_variable_count":
					if captureName == "var" {
						for i := 0; i < int(c.Node.ChildCount()); i++ {
							if c.Node.Child(i).Type() == "variable_declarator" {
								stats.LocalVariableCount++
							}
						}
					}
				case "instance_variable_count":
					if captureName == "field" {
						mods := c.Node.ChildByFieldName("modifiers")
						isStatic := false
						if mods != nil {
							for i := 0; i < int(mods.ChildCount()); i++ {
								child := mods.Child(i)
								if child.Type() == "modifier" && string(child.Content(src)) == "static" {
									isStatic = true
									break
								}
							}
						}
						if !isStatic {
							for i := 0; i < int(c.Node.ChildCount()); i++ {
								if c.Node.Child(i).Type() == "variable_declarator" {
									stats.InstanceVariableCount++
								}
							}
						}
					}
				case "utility_method_count":
					if captureName == "method" {
						isPublic := false
						isStatic := false

						for i := 0; i < int(c.Node.ChildCount()); i++ {
							child := c.Node.Child(i)
							if child.Type() == "modifiers" {
								for k := 0; k < int(child.ChildCount()); k++ {
									modifier := child.Child(k)
									modStr := string(modifier.Content(src))
									if modStr == "public" {
										isPublic = true
									} else if modStr == "static" {
										isStatic = true
									}
								}
							}
						}

						if isPublic && isStatic {
							stats.UtilityMethodCount++
						}

						if hasGenericName(c.Node, src) {
							stats.GenericNaming++
						}
					}
				case "constant_count":
					if captureName == "field" {
						isStatic := false
						isFinal := false

						for i := 0; i < int(c.Node.ChildCount()); i++ {
							child := c.Node.Child(i)
							if child.Type() == "modifiers" {
								for k := 0; k < int(child.ChildCount()); k++ {
									modifier := child.Child(k)
									modStr := string(modifier.Content(src))
									if modStr == "static" {
										isStatic = true
									} else if modStr == "final" {
										isFinal = true
									}
								}
							}
						}

						if isStatic && isFinal {
							// Count variable declarators in this field
							count := 0
							for i := 0; i < int(c.Node.ChildCount()); i++ {
								if c.Node.Child(i).Type() == "variable_declarator" {
									count++
								}
							}
							stats.ConstantCount += count
						}
					}
				case "ejb_class_count":
					if captureName == "class" {
						isEJBClass := false

						// Check for EJB annotations
						for i := 0; i < int(c.Node.ChildCount()); i++ {
							child := c.Node.Child(i)
							if child.Type() == "modifiers" {
								for k := 0; k < int(child.ChildCount()); k++ {
									modifier := child.Child(k)
									if modifier.Type() == "marker_annotation" {
										// Get annotation name
										for j := 0; j < int(modifier.ChildCount()); j++ {
											annChild := modifier.Child(j)
											if annChild.Type() == "identifier" {
												annName := string(annChild.Content(src))
												if annName == "Stateless" || annName == "Stateful" || annName == "MessageDriven" {
													isEJBClass = true
													break
												}
											}
										}
									}
								}
							}

							// Check for EJB interface implementations (implements javax.ejb.*)
							if child.Type() == "super_interfaces" {
								implementsContent := string(child.Content(src))
								if strings.Contains(implementsContent, "javax.ejb.") {
									isEJBClass = true
								}
							}
						}

						if isEJBClass {
							stats.EJBClassCount++
						}
					}
				case "ejb_interface_count":
					if captureName == "interface" {
						isEJBInterface := false

						// Check for EJB annotations
						for i := 0; i < int(c.Node.ChildCount()); i++ {
							child := c.Node.Child(i)
							if child.Type() == "modifiers" {
								for k := 0; k < int(child.ChildCount()); k++ {
									modifier := child.Child(k)
									if modifier.Type() == "marker_annotation" {
										// Get annotation name
										for j := 0; j < int(modifier.ChildCount()); j++ {
											annChild := modifier.Child(j)
											if annChild.Type() == "identifier" {
												annName := string(annChild.Content(src))
												if annName == "Local" || annName == "Remote" || annName == "WebService" {
													isEJBInterface = true
													break
												}
											}
										}
									}
								}
							}

							// Check for EJB interface inheritance (extends javax.ejb.*)
							if child.Type() == "extends_interfaces" {
								extendsContent := string(child.Content(src))
								if strings.Contains(extendsContent, "javax.ejb.") {
									isEJBInterface = true
								}
							}
						}

						if isEJBInterface {
							stats.EJBInterfaceCount++
						}
					}
				case "package_protected_class":
					if captureName == "class" {
						mods := c.Node.ChildByFieldName("modifiers")
						isPublic := false
						isProtected := false
						isPrivate := false
						if mods != nil {
							for i := 0; i < int(mods.ChildCount()); i++ {
								child := mods.Child(i)
								if child.Type() == "modifier" {
									modStr := string(child.Content(src))
									if modStr == "public" {
										isPublic = true
									} else if modStr == "protected" {
										isProtected = true
									} else if modStr == "private" {
										isPrivate = true
									}
								}
							}
						}
						if !isPublic && !isProtected && !isPrivate {
							stats.PackageProtectedClassCount++
						}
					}
				}
			}
		}
	}

	return stats
}

func nodeIsConstructor(nameNode *sitter.Node, src []byte) bool {
	if nameNode == nil {
		return false
	}
	methodName := string(nameNode.Content(src))
	// Travel up the tree to find the enclosing class
	for n := nameNode; n != nil; n = n.Parent() {
		if n.Type() == "class_declaration" {
			classNameNode := n.ChildByFieldName("name")
			if classNameNode != nil {
				className := string(classNameNode.Content(src))
				if methodName == className {
					return true
				}
			}
			break // only check innermost class
		}
	}
	return false
}

func (g *JavaLanguage) GetRules() []staticanalyzer.Rule {
	return []staticanalyzer.Rule{
		&UnusedImportsRule{},
		&DuplicateFunctionName{},
		&DuplicateCodeBlockRule{},
		&HardCodedCredentialsRule{},
		&MagicNumberRule{},
		&performance.AvoidFileStreamRule{},
		&multithreading.AvoidUsingVolatileRule{},
		&multithreading.AvoidSynchronizedAtMethodLevelRule{},
		&multithreading.AvoidSynchronizedStatementRule{},
		&multithreading.AvoidThreadGroupRule{},
		&multithreading.DoNotUseThreadsRule{},
		&multithreading.DontCallThreadRunRule{},
		&multithreading.DoubleCheckedLockingRule{},
		&multithreading.NonThreadSafeSingletonRule{},
		&multithreading.UnsynchronizedStaticFormatterRule{},
		&multithreading.UseConcurrentHashMapRule{},
		&multithreading.UseNotifyAllInsteadOfNotifyRule{},
		&errorprone.AssignmentInOperandRule{},
		&errorprone.AssignmentToNonFinalStaticRule{},
		&errorprone.AvoidAccessibilityAlterationRule{},
		&errorprone.AvoidAssertAsIdentifierRule{},
		&errorprone.AvoidBranchingStatementAsLastInLoopRule{},
		&errorprone.AvoidCallingFinalizeRule{},
		&errorprone.AvoidCatchingNPERule{},
		&errorprone.AvoidCatchingThrowableRule{},
		&errorprone.AvoidDecimalLiteralsInBigDecimalConstructorRule{},
		&errorprone.AvoidDuplicateLiteralsRule{},
		&errorprone.AvoidEnumAsIdentifierRule{},
		&security.HardCodedCryptoKeyRule{},
		&security.InsecureCryptoIvRule{},
		//&SystemOutPrintlnRule{},
		//&ClassNameMismatchRule{},
		//	&CommentedOutCodeRule{},
		//	&ConsoleLogRule{},
		// &UninitializedVariableRule{},
		// &UnusedLocalVariableRule{},
		// &UnusedFieldRule{},
		//&EmptyCatchBlockRule{},
		//&MissingDefaultCaseRule{},
		//&StringConcatInLoopRule{},

		//&PublicFieldRule{},
		//	&MissingJavadocRule{},
		//&MultipleClassesRule{},
	}
}

func hasGenericName(node *sitter.Node, src []byte) bool {
	nameNode := node.ChildByFieldName("name")
	if nameNode == nil {
		return false
	}
	nameText := string(nameNode.Content(src))
	return strings.HasPrefix(nameText, "T") || strings.Contains(nameText, "Generic")
}
