package errorprone

import (
	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidEnumAsIdentifierRule detects use of "enum" as an identifier
type AvoidEnumAsIdentifierRule struct{}

func (r AvoidEnumAsIdentifierRule) Rule() string {
	return "AvoidEnumAsIdentifier"
}

func (r AvoidEnumAsIdentifierRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidEnumAsIdentifierRule) Classification() string {
	return "Maintainability"
}

func (r AvoidEnumAsIdentifierRule) Priority() int {
	return 2
}

func (r AvoidEnumAsIdentifierRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Query for identifiers
	queryStr := `(identifier) @identifier`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			node := capture.Node
			identifierText := string(source[node.StartByte():node.EndByte()])

			// Check if the identifier is "enum"
			if identifierText == "enum" {
				// Make sure this is being used as an identifier, not an enum declaration
				if r.isUsedAsIdentifier(node) {
					issues = append(issues, staticanalyzer.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Priority:       r.Priority(),
						Description:    "Avoid using enum as an identifier; it's a reserved word in JDK 1.5",
						BeginLine:      int(node.StartPoint().Row) + 1,
						EndLine:        int(node.EndPoint().Row) + 1,
						BeginColumn:    int(node.StartPoint().Column) + 1,
						EndColumn:      int(node.EndPoint().Column) + 1,
					})
				}
			}
		}
	}

	return issues
}

// isUsedAsIdentifier checks if "enum" is being used as an identifier rather than a keyword
func (r AvoidEnumAsIdentifierRule) isUsedAsIdentifier(node *sitter.Node) bool {
	parent := node.Parent()
	if parent == nil {
		return false
	}

	// Check various contexts where "enum" would be used as an identifier
	switch parent.Type() {
	case "variable_declarator":
		// String enum = "foo";
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "field_declaration":
		// field declaration with enum as field name
		return true
	case "formal_parameter":
		// method parameter named enum
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "method_declaration":
		// method named enum
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "class_declaration":
		// class named enum
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "package_declaration":
		// package containing enum
		return true
	case "import_declaration":
		// import with enum
		return true
	case "enum_declaration":
		// If parent is enum_declaration and this is the name field, it's a keyword use
		nameField := parent.ChildByFieldName("name")
		if nameField == node {
			return false // This is the enum declaration name, not identifier use
		}
		return true
	default:
		// Check if parent is enum-related keywords - if so, it's a keyword use
		enumKeywordTypes := map[string]bool{
			"enum_declaration": true,
			"enum_body":        true,
			"enum_constant":    true,
		}
		if enumKeywordTypes[parent.Type()] {
			return false
		}
		// Otherwise, likely being used as identifier
		return true
	}
}
