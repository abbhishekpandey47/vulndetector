package errorprone

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// parseJavaFile parses a Java file and returns the AST tree
func parseJavaFile(t *testing.T, filename string) (*sitter.Tree, []byte) {
	// Get the path to the test file
	testDataPath := filepath.Join("testdata", filename)

	// Read the file
	source, err := os.ReadFile(testDataPath)
	if err != nil {
		t.Fatalf("Failed to read test file %s: %v", testDataPath, err)
	}

	// Parse the file
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree := parser.Parse(nil, source)
	if tree == nil {
		t.Fatalf("Failed to parse %s", filename)
	}

	return tree, source
}

func TestAssignmentInOperandRule(t *testing.T) {
	rule := AssignmentInOperandRule{}
	tree, source := parseJavaFile(t, "AssignmentInOperandExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect multiple assignment in operand violations
	if len(issues) == 0 {
		t.Error("Expected violations for assignment in operand, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AssignmentInOperand" {
		t.Errorf("Expected rule name 'AssignmentInOperand', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	// Verify issue details
	for _, issue := range issues {
		if issue.Rule != "AssignmentInOperand" {
			t.Errorf("Expected issue rule 'AssignmentInOperand', got '%s'", issue.Rule)
		}
		if issue.BeginLine <= 0 || issue.EndLine <= 0 {
			t.Errorf("Invalid line numbers: begin=%d, end=%d", issue.BeginLine, issue.EndLine)
		}
	}

	t.Logf("Found %d AssignmentInOperand violations", len(issues))
}

func TestAssignmentToNonFinalStaticRule(t *testing.T) {
	rule := AssignmentToNonFinalStaticRule{}
	tree, source := parseJavaFile(t, "AssignmentToNonFinalStaticExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect assignments to non-final static fields in constructors
	if len(issues) == 0 {
		t.Error("Expected violations for assignment to non-final static, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AssignmentToNonFinalStatic" {
		t.Errorf("Expected rule name 'AssignmentToNonFinalStatic', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AssignmentToNonFinalStatic violations", len(issues))
}

func TestAvoidAccessibilityAlterationRule(t *testing.T) {
	rule := AvoidAccessibilityAlterationRule{}
	tree, source := parseJavaFile(t, "AvoidAccessibilityAlterationExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect setAccessible calls
	if len(issues) == 0 {
		t.Error("Expected violations for accessibility alteration, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidAccessibilityAlteration" {
		t.Errorf("Expected rule name 'AvoidAccessibilityAlteration', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Security" {
		t.Errorf("Expected classification 'Security', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidAccessibilityAlteration violations", len(issues))
}

func TestAvoidAssertAsIdentifierRule(t *testing.T) {
	rule := AvoidAssertAsIdentifierRule{}
	tree, source := parseJavaFile(t, "AvoidAssertAsIdentifierExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect usage of "assert" as identifier
	if len(issues) == 0 {
		t.Error("Expected violations for assert as identifier, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidAssertAsIdentifier" {
		t.Errorf("Expected rule name 'AvoidAssertAsIdentifier', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 2 {
		t.Errorf("Expected priority 2, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidAssertAsIdentifier violations", len(issues))
}

func TestAvoidBranchingStatementAsLastInLoopRule(t *testing.T) {
	rule := AvoidBranchingStatementAsLastInLoopRule{}
	tree, source := parseJavaFile(t, "AvoidBranchingStatementAsLastInLoopExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect branching statements as last in loop
	if len(issues) == 0 {
		t.Error("Expected violations for branching statement as last in loop, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidBranchingStatementAsLastInLoop" {
		t.Errorf("Expected rule name 'AvoidBranchingStatementAsLastInLoop', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 2 {
		t.Errorf("Expected priority 2, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidBranchingStatementAsLastInLoop violations", len(issues))
}

func TestAvoidCallingFinalizeRule(t *testing.T) {
	rule := AvoidCallingFinalizeRule{}
	tree, source := parseJavaFile(t, "AvoidCallingFinalizeExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect explicit finalize calls
	if len(issues) == 0 {
		t.Error("Expected violations for calling finalize, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidCallingFinalize" {
		t.Errorf("Expected rule name 'AvoidCallingFinalize', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidCallingFinalize violations", len(issues))
}

func TestAvoidCatchingNPERule(t *testing.T) {
	rule := AvoidCatchingNPERule{}
	tree, source := parseJavaFile(t, "AvoidCatchingNPEExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect catching NullPointerException
	if len(issues) == 0 {
		t.Error("Expected violations for catching NPE, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidCatchingNPE" {
		t.Errorf("Expected rule name 'AvoidCatchingNPE', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidCatchingNPE violations", len(issues))
}

func TestAvoidCatchingThrowableRule(t *testing.T) {
	rule := AvoidCatchingThrowableRule{}
	tree, source := parseJavaFile(t, "AvoidCatchingThrowableExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect catching Throwable
	if len(issues) == 0 {
		t.Error("Expected violations for catching Throwable, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidCatchingThrowable" {
		t.Errorf("Expected rule name 'AvoidCatchingThrowable', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidCatchingThrowable violations", len(issues))
}

func TestAvoidDecimalLiteralsInBigDecimalConstructorRule(t *testing.T) {
	rule := AvoidDecimalLiteralsInBigDecimalConstructorRule{}
	tree, source := parseJavaFile(t, "AvoidDecimalLiteralsInBigDecimalConstructorExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect decimal literals in BigDecimal constructor
	if len(issues) == 0 {
		t.Error("Expected violations for decimal literals in BigDecimal constructor, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidDecimalLiteralsInBigDecimalConstructor" {
		t.Errorf("Expected rule name 'AvoidDecimalLiteralsInBigDecimalConstructor', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidDecimalLiteralsInBigDecimalConstructor violations", len(issues))
}

func TestAvoidDuplicateLiteralsRule(t *testing.T) {
	rule := AvoidDuplicateLiteralsRule{}
	tree, source := parseJavaFile(t, "AvoidDuplicateLiteralsExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect duplicate string literals
	if len(issues) == 0 {
		t.Error("Expected violations for duplicate literals, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidDuplicateLiterals" {
		t.Errorf("Expected rule name 'AvoidDuplicateLiterals', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidDuplicateLiterals violations", len(issues))
}

func TestAvoidEnumAsIdentifierRule(t *testing.T) {
	rule := AvoidEnumAsIdentifierRule{}
	tree, source := parseJavaFile(t, "AvoidEnumAsIdentifierExample.java")

	issues := rule.Analyze(tree, source, nil)

	// Should detect usage of "enum" as identifier
	if len(issues) == 0 {
		t.Error("Expected violations for enum as identifier, but found none")
	}

	// Verify rule metadata
	if rule.Rule() != "AvoidEnumAsIdentifier" {
		t.Errorf("Expected rule name 'AvoidEnumAsIdentifier', got '%s'", rule.Rule())
	}
	if rule.RuleSet() != "errorprone" {
		t.Errorf("Expected ruleset 'errorprone', got '%s'", rule.RuleSet())
	}
	if rule.Classification() != "Maintainability" {
		t.Errorf("Expected classification 'Maintainability', got '%s'", rule.Classification())
	}
	if rule.Priority() != 2 {
		t.Errorf("Expected priority 2, got %d", rule.Priority())
	}

	t.Logf("Found %d AvoidEnumAsIdentifier violations", len(issues))
}

// Test all rules with nil/invalid inputs
func TestRulesWithNilInputs(t *testing.T) {
	rules := []struct {
		name string
		rule staticanalyzer.Rule
	}{
		{"AssignmentInOperand", AssignmentInOperandRule{}},
		{"AssignmentToNonFinalStatic", AssignmentToNonFinalStaticRule{}},
		{"AvoidAccessibilityAlteration", AvoidAccessibilityAlterationRule{}},
		{"AvoidAssertAsIdentifier", AvoidAssertAsIdentifierRule{}},
		{"AvoidBranchingStatementAsLastInLoop", AvoidBranchingStatementAsLastInLoopRule{}},
		{"AvoidCallingFinalize", AvoidCallingFinalizeRule{}},
		{"AvoidCatchingNPE", AvoidCatchingNPERule{}},
		{"AvoidCatchingThrowable", AvoidCatchingThrowableRule{}},
		{"AvoidDecimalLiteralsInBigDecimalConstructor", AvoidDecimalLiteralsInBigDecimalConstructorRule{}},
		{"AvoidDuplicateLiterals", AvoidDuplicateLiteralsRule{}},
		{"AvoidEnumAsIdentifier", AvoidEnumAsIdentifierRule{}},
	}

	for _, r := range rules {
		t.Run("NilAST_"+r.name, func(t *testing.T) {
			issues := r.rule.Analyze(nil, []byte("dummy"), nil)
			if len(issues) != 0 {
				t.Errorf("Expected no issues for nil AST, got %d", len(issues))
			}
		})

		t.Run("NilTree_"+r.name, func(t *testing.T) {
			var nilTree *sitter.Tree
			issues := r.rule.Analyze(nilTree, []byte("dummy"), nil)
			if len(issues) != 0 {
				t.Errorf("Expected no issues for nil tree, got %d", len(issues))
			}
		})
	}
}

// Integration test that runs all rules on all sample files
func TestAllRulesIntegration(t *testing.T) {
	ruleTests := []struct {
		filename string
		ruleName string
		rule     staticanalyzer.Rule
	}{
		{"AssignmentInOperandExample.java", "AssignmentInOperand", AssignmentInOperandRule{}},
		{"AssignmentToNonFinalStaticExample.java", "AssignmentToNonFinalStatic", AssignmentToNonFinalStaticRule{}},
		{"AvoidAccessibilityAlterationExample.java", "AvoidAccessibilityAlteration", AvoidAccessibilityAlterationRule{}},
		{"AvoidAssertAsIdentifierExample.java", "AvoidAssertAsIdentifier", AvoidAssertAsIdentifierRule{}},
		{"AvoidBranchingStatementAsLastInLoopExample.java", "AvoidBranchingStatementAsLastInLoop", AvoidBranchingStatementAsLastInLoopRule{}},
		{"AvoidCallingFinalizeExample.java", "AvoidCallingFinalize", AvoidCallingFinalizeRule{}},
		{"AvoidCatchingNPEExample.java", "AvoidCatchingNPE", AvoidCatchingNPERule{}},
		{"AvoidCatchingThrowableExample.java", "AvoidCatchingThrowable", AvoidCatchingThrowableRule{}},
		{"AvoidDecimalLiteralsInBigDecimalConstructorExample.java", "AvoidDecimalLiteralsInBigDecimalConstructor", AvoidDecimalLiteralsInBigDecimalConstructorRule{}},
		{"AvoidDuplicateLiteralsExample.java", "AvoidDuplicateLiterals", AvoidDuplicateLiteralsRule{}},
		{"AvoidEnumAsIdentifierExample.java", "AvoidEnumAsIdentifier", AvoidEnumAsIdentifierRule{}},
	}

	totalIssues := 0
	for _, rt := range ruleTests {
		t.Run("Integration_"+rt.ruleName, func(t *testing.T) {
			tree, source := parseJavaFile(t, rt.filename)
			issues := rt.rule.Analyze(tree, source, nil)

			if len(issues) == 0 {
				t.Errorf("Expected violations for %s with rule %s, but found none", rt.filename, rt.ruleName)
			}

			totalIssues += len(issues)
			t.Logf("Rule %s found %d issues in %s", rt.ruleName, len(issues), rt.filename)
		})
	}

	t.Logf("Total issues found across all rules: %d", totalIssues)
}
