package errorprone

import (
	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidCallingFinalizeRule detects explicit calls to finalize()
type AvoidCallingFinalizeRule struct{}

func (r AvoidCallingFinalizeRule) Rule() string {
	return "AvoidCallingFinalize"
}

func (r AvoidCallingFinalizeRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidCallingFinalizeRule) Classification() string {
	return "Maintainability"
}

func (r AvoidCallingFinalizeRule) Priority() int {
	return 3
}

func (r AvoidCallingFinalizeRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Query for method invocations
	queryStr := `
		(method_invocation
			name: (identifier) @method_name
		) @method_call
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var methodName string
		var methodCallNode *sitter.Node

		for _, capture := range match.Captures {
			captureName := query.CaptureNameForId(capture.Index)
			if captureName == "method_name" {
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			} else if captureName == "method_call" {
				methodCallNode = capture.Node
			}
		}

		// Check if it's a finalize call
		if methodName == "finalize" && methodCallNode != nil {
			// Make sure this is an explicit call and not overriding the method
			if r.isExplicitCall(methodCallNode) {
				issues = append(issues, staticanalyzer.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Priority:       r.Priority(),
					Description:    "Avoid calling finalize() explicitly",
					BeginLine:      int(methodCallNode.StartPoint().Row) + 1,
					EndLine:        int(methodCallNode.EndPoint().Row) + 1,
					BeginColumn:    int(methodCallNode.StartPoint().Column) + 1,
					EndColumn:      int(methodCallNode.EndPoint().Column) + 1,
				})
			}
		}
	}

	return issues
}

// isExplicitCall checks if this is an explicit method call (not a method declaration)
func (r AvoidCallingFinalizeRule) isExplicitCall(node *sitter.Node) bool {
	// Check if this is inside a method declaration context
	parent := node.Parent()
	for parent != nil {
		// If we're in a method declaration, this might be an override, not a call
		if parent.Type() == "method_declaration" {
			// Check if the method being declared is finalize itself
			methodDecl := parent
			nameNode := methodDecl.ChildByFieldName("name")
			if nameNode != nil {
				// If this method declaration is for finalize, then calls within it are explicit
				// But if we're just declaring the method, that's not a call
				return true // For now, assume all calls within any method are explicit
			}
		}
		parent = parent.Parent()
	}

	// If we reach here, it's likely an explicit call
	return true
}
