package errorprone

import (
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidDecimalLiteralsInBigDecimalConstructorRule detects BigDecimal constructor with decimal literals
type AvoidDecimalLiteralsInBigDecimalConstructorRule struct{}

func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) Rule() string {
	return "AvoidDecimalLiteralsInBigDecimalConstructor"
}

func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) Classification() string {
	return "Maintainability"
}

func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) Priority() int {
	return 3
}

func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Query for object creation expressions
	queryStr := `
		(object_creation_expression
			type: (_) @type
			arguments: (argument_list) @args
		) @constructor_call
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var typeName string
		var argsNode *sitter.Node
		var constructorCallNode *sitter.Node

		for _, capture := range match.Captures {
			captureName := query.CaptureNameForId(capture.Index)
			if captureName == "type" {
				typeName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			} else if captureName == "args" {
				argsNode = capture.Node
			} else if captureName == "constructor_call" {
				constructorCallNode = capture.Node
			}
		}

		// Check if it's a BigDecimal constructor
		if r.isBigDecimal(typeName) && argsNode != nil && constructorCallNode != nil {
			// Check if any argument is a decimal literal
			if r.hasDecimalLiteralArgument(argsNode, source) {
				issues = append(issues, staticanalyzer.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Priority:       r.Priority(),
					Description:    "Avoid creating BigDecimal with a decimal (float/double) literal. Use a String literal",
					BeginLine:      int(constructorCallNode.StartPoint().Row) + 1,
					EndLine:        int(constructorCallNode.EndPoint().Row) + 1,
					BeginColumn:    int(constructorCallNode.StartPoint().Column) + 1,
					EndColumn:      int(constructorCallNode.EndPoint().Column) + 1,
				})
			}
		}
	}

	return issues
}

// isBigDecimal checks if the type is BigDecimal
func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) isBigDecimal(typeName string) bool {
	typeName = strings.TrimSpace(typeName)
	return typeName == "BigDecimal" ||
		typeName == "java.math.BigDecimal" ||
		strings.HasSuffix(typeName, ".BigDecimal")
}

// hasDecimalLiteralArgument checks if any argument is a decimal literal
func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) hasDecimalLiteralArgument(argsNode *sitter.Node, source []byte) bool {
	for i := 0; i < int(argsNode.ChildCount()); i++ {
		child := argsNode.Child(i)
		if child != nil && r.isDecimalLiteral(child, source) {
			return true
		}
	}
	return false
}

// isDecimalLiteral checks if a node is a decimal literal (float or double)
func (r AvoidDecimalLiteralsInBigDecimalConstructorRule) isDecimalLiteral(node *sitter.Node, source []byte) bool {
	if node == nil {
		return false
	}

	// Check if it's a decimal literal
	if node.Type() == "decimal_floating_point_literal" {
		return true
	}

	// Check if it's a literal that contains a decimal point
	if node.Type() == "decimal_integer_literal" {
		text := string(source[node.StartByte():node.EndByte()])
		return strings.Contains(text, ".")
	}

	// Check other literal types that might be decimal
	literalTypes := []string{
		"floating_point_literal",
		"decimal_literal",
		"float_literal",
		"double_literal",
	}

	for _, literalType := range literalTypes {
		if node.Type() == literalType {
			text := string(source[node.StartByte():node.EndByte()])
			// Check if it contains a decimal point and is not an integer
			if strings.Contains(text, ".") || strings.Contains(strings.ToLower(text), "f") || strings.Contains(strings.ToLower(text), "d") {
				return true
			}
		}
	}

	return false
}
