package errorprone

import (
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidCatchingThrowableRule detects catching Throwable
type AvoidCatchingThrowableRule struct{}

func (r AvoidCatchingThrowableRule) Rule() string {
	return "AvoidCatchingThrowable"
}

func (r AvoidCatchingThrowableRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidCatchingThrowableRule) Classification() string {
	return "Maintainability"
}

func (r AvoidCatchingThrowableRule) Priority() int {
	return 3
}

func (r AvoidCatchingThrowableRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Updated query based on actual AST structure
	queryStr := `
		(catch_clause
			(catch_formal_parameter
				(catch_type (type_identifier) @exception_type)
				(identifier) @exception_name
			)
		) @catch_clause
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var exceptionType string
		var catchClauseNode *sitter.Node

		for _, capture := range match.Captures {
			captureName := query.CaptureNameForId(capture.Index)
			if captureName == "exception_type" {
				exceptionType = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			} else if captureName == "catch_clause" {
				catchClauseNode = capture.Node
			}
		}

		// Check if it's catching Throwable
		if r.isThrowable(exceptionType) && catchClauseNode != nil {
			issues = append(issues, staticanalyzer.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "A catch statement should never catch throwable since it includes errors.",
				BeginLine:      int(catchClauseNode.StartPoint().Row) + 1,
				EndLine:        int(catchClauseNode.EndPoint().Row) + 1,
				BeginColumn:    int(catchClauseNode.StartPoint().Column) + 1,
				EndColumn:      int(catchClauseNode.EndPoint().Column) + 1,
			})
		}
	}

	return issues
}

// isThrowable checks if the exception type is Throwable
func (r AvoidCatchingThrowableRule) isThrowable(exceptionType string) bool {
	// Remove whitespace and check for various forms of Throwable
	exceptionType = strings.TrimSpace(exceptionType)

	return exceptionType == "Throwable" ||
		exceptionType == "java.lang.Throwable" ||
		strings.HasSuffix(exceptionType, ".Throwable")
}
