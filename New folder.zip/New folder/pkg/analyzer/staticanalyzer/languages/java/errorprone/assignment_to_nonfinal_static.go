package errorprone

import (
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AssignmentToNonFinalStaticRule detects unsafe assignments to non-final static fields in constructors
type AssignmentToNonFinalStaticRule struct{}

func (r AssignmentToNonFinalStaticRule) Rule() string {
	return "AssignmentToNonFinalStatic"
}

func (r AssignmentToNonFinalStaticRule) RuleSet() string {
	return "errorprone"
}

func (r AssignmentToNonFinalStaticRule) Classification() string {
	return "Maintainability"
}

func (r AssignmentToNonFinalStaticRule) Priority() int {
	return 3
}

func (r AssignmentToNonFinalStaticRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// First find all non-final static fields
	staticFields := r.findNonFinalStaticFields(tree.RootNode(), source)

	// Then find assignments to these fields in constructors
	r.findAssignmentsInConstructors(tree.RootNode(), source, staticFields, &issues)

	return issues
}

// findNonFinalStaticFields finds all static fields that are not final
func (r AssignmentToNonFinalStaticRule) findNonFinalStaticFields(root *sitter.Node, source []byte) map[string]bool {
	staticFields := make(map[string]bool)

	// Updated query based on actual AST structure
	queryStr := `
		(field_declaration
			(modifiers) @modifiers
			(variable_declarator
				(identifier) @field_name
			)
		) @field
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return staticFields
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var modifiersNode *sitter.Node
		var fieldName string

		for _, capture := range match.Captures {
			captureName := query.CaptureNameForId(capture.Index)
			if captureName == "modifiers" {
				modifiersNode = capture.Node
			} else if captureName == "field_name" {
				fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			}
		}

		if modifiersNode != nil && fieldName != "" {
			modifiersText := string(source[modifiersNode.StartByte():modifiersNode.EndByte()])
			isStatic := strings.Contains(modifiersText, "static")
			isFinal := strings.Contains(modifiersText, "final")

			// If it's static but not final, add it to our list
			if isStatic && !isFinal {
				staticFields[fieldName] = true
			}
		}
	}

	return staticFields
}

// findAssignmentsInConstructors finds assignments to static fields in constructors
func (r AssignmentToNonFinalStaticRule) findAssignmentsInConstructors(root *sitter.Node, source []byte, staticFields map[string]bool, issues *[]staticanalyzer.Issue) {
	// Updated query based on actual AST structure
	queryStr := `
		(constructor_declaration
			(constructor_body) @constructor_body
		) @constructor
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			captureName := query.CaptureNameForId(capture.Index)
			if captureName == "constructor_body" {
				r.findAssignmentsInNode(capture.Node, source, staticFields, issues)
			}
		}
	}
}

// findAssignmentsInNode recursively finds assignments to static fields
func (r AssignmentToNonFinalStaticRule) findAssignmentsInNode(node *sitter.Node, source []byte, staticFields map[string]bool, issues *[]staticanalyzer.Issue) {
	if node == nil {
		return
	}

	// Check if this is an assignment expression
	if node.Type() == "assignment_expression" {
		// Get the left side of the assignment
		leftNode := node.ChildByFieldName("left")
		if leftNode != nil {
			// Check if it's a field access or simple identifier
			var fieldName string

			if leftNode.Type() == "identifier" {
				fieldName = string(source[leftNode.StartByte():leftNode.EndByte()])
			} else if leftNode.Type() == "field_access" {
				// Get the field part of the field access
				fieldNode := leftNode.ChildByFieldName("field")
				if fieldNode != nil {
					fieldName = string(source[fieldNode.StartByte():fieldNode.EndByte()])
				}
			}

			// Check if this field is a non-final static field
			if fieldName != "" && staticFields[fieldName] {
				*issues = append(*issues, staticanalyzer.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Priority:       r.Priority(),
					Description:    "Possible unsafe assignment to non-final static field '" + fieldName + "' in a constructor.",
					BeginLine:      int(node.StartPoint().Row) + 1,
					EndLine:        int(node.EndPoint().Row) + 1,
					BeginColumn:    int(node.StartPoint().Column) + 1,
					EndColumn:      int(node.EndPoint().Column) + 1,
				})
			}
		}
	}

	// Recursively check child nodes
	for i := 0; i < int(node.ChildCount()); i++ {
		child := node.Child(i)
		r.findAssignmentsInNode(child, source, staticFields, issues)
	}
}
