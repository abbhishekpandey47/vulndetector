package errorprone

import (
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidAccessibilityAlterationRule detects calls to setAccessible()
type AvoidAccessibilityAlterationRule struct{}

func (r AvoidAccessibilityAlterationRule) Rule() string {
	return "AvoidAccessibilityAlteration"
}

func (r AvoidAccessibilityAlterationRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidAccessibilityAlterationRule) Classification() string {
	return "Security"
}

func (r AvoidAccessibilityAlterationRule) Priority() int {
	return 3
}

func (r AvoidAccessibilityAlterationRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Query for method invocations
	queryStr := `
		(method_invocation
			object: (_) @object
			name: (identifier) @method_name
			arguments: (argument_list) @args
		) @method_call
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var methodName string
		var methodCallNode *sitter.Node

		for _, capture := range match.Captures {
			captureName := query.CaptureNameForId(capture.Index)
			if captureName == "method_name" {
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			} else if captureName == "method_call" {
				methodCallNode = capture.Node
			}
		}

		// Check if it's a setAccessible call
		if methodName == "setAccessible" && methodCallNode != nil {
			// Check if this call is not within a PrivilegedAction
			if !r.isWithinPrivilegedAction(methodCallNode, source) {
				issues = append(issues, staticanalyzer.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Priority:       r.Priority(),
					Description:    "You should not modify visibility of constructors, methods or fields using setAccessible()",
					BeginLine:      int(methodCallNode.StartPoint().Row) + 1,
					EndLine:        int(methodCallNode.EndPoint().Row) + 1,
					BeginColumn:    int(methodCallNode.StartPoint().Column) + 1,
					EndColumn:      int(methodCallNode.EndPoint().Column) + 1,
				})
			}
		}
	}

	return issues
}

// isWithinPrivilegedAction checks if the setAccessible call is within a PrivilegedAction
func (r AvoidAccessibilityAlterationRule) isWithinPrivilegedAction(node *sitter.Node, source []byte) bool {
	// Look for AccessController.doPrivileged or PrivilegedAction in the ancestor chain
	current := node.Parent()

	for current != nil {
		// Check if we're inside an anonymous class that implements PrivilegedAction
		if current.Type() == "object_creation_expression" {
			// Get the type identifier
			typeNode := current.ChildByFieldName("type")
			if typeNode != nil {
				typeText := string(source[typeNode.StartByte():typeNode.EndByte()])
				if strings.Contains(typeText, "PrivilegedAction") {
					return true
				}
			}
		}

		// Check for AccessController.doPrivileged method calls
		if current.Type() == "method_invocation" {
			objectNode := current.ChildByFieldName("object")
			methodNameNode := current.ChildByFieldName("name")

			if objectNode != nil && methodNameNode != nil {
				objectText := string(source[objectNode.StartByte():objectNode.EndByte()])
				methodText := string(source[methodNameNode.StartByte():methodNameNode.EndByte()])

				if objectText == "AccessController" && methodText == "doPrivileged" {
					return true
				}
			}
		}

		current = current.Parent()
	}

	return false
}
