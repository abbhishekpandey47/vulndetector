package errorprone

import (
	"fmt"
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidDuplicateLiteralsRule detects duplicate string literals
type AvoidDuplicateLiteralsRule struct{}

func (r AvoidDuplicateLiteralsRule) Rule() string {
	return "AvoidDuplicateLiterals"
}

func (r AvoidDuplicateLiteralsRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidDuplicateLiteralsRule) Classification() string {
	return "Maintainability"
}

func (r AvoidDuplicateLiteralsRule) Priority() int {
	return 3
}

func (r AvoidDuplicateLiteralsRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Map to track string literals: literal -> {count, first_line, nodes}
	type literalInfo struct {
		count     int
		firstLine int
		nodes     []*sitter.Node
	}

	literalMap := make(map[string]*literalInfo)

	// Query for string literals
	queryStr := `(string_literal) @string_literal`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			node := capture.Node
			literalText := string(source[node.StartByte():node.EndByte()])

			// Normalize the literal (remove quotes for comparison)
			normalizedLiteral := r.normalizeLiteral(literalText)

			// Skip very short literals or common ones
			if r.shouldSkipLiteral(normalizedLiteral) {
				continue
			}

			line := int(node.StartPoint().Row) + 1

			if info, exists := literalMap[normalizedLiteral]; exists {
				info.count++
				info.nodes = append(info.nodes, node)
			} else {
				literalMap[normalizedLiteral] = &literalInfo{
					count:     1,
					firstLine: line,
					nodes:     []*sitter.Node{node},
				}
			}
		}
	}

	// Report duplicates (threshold of 3 or more occurrences)
	for literal, info := range literalMap {
		if info.count >= 3 {
			// Report on the first occurrence
			firstNode := info.nodes[0]
			issues = append(issues, staticanalyzer.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    fmt.Sprintf("The String literal %s appears %d times in this file; the first occurrence is on line %d", literal, info.count, info.firstLine),
				BeginLine:      int(firstNode.StartPoint().Row) + 1,
				EndLine:        int(firstNode.EndPoint().Row) + 1,
				BeginColumn:    int(firstNode.StartPoint().Column) + 1,
				EndColumn:      int(firstNode.EndPoint().Column) + 1,
			})
		}
	}

	return issues
}

// normalizeLiteral removes quotes and normalizes the literal for comparison
func (r AvoidDuplicateLiteralsRule) normalizeLiteral(literal string) string {
	// Remove leading and trailing quotes
	if len(literal) >= 2 && literal[0] == '"' && literal[len(literal)-1] == '"' {
		return literal[1 : len(literal)-1]
	}
	return literal
}

// shouldSkipLiteral determines if a literal should be skipped from duplicate detection
func (r AvoidDuplicateLiteralsRule) shouldSkipLiteral(literal string) bool {
	// Skip empty strings
	if literal == "" {
		return true
	}

	// Skip very short literals (less than 3 characters)
	if len(literal) < 3 {
		return true
	}

	// Skip common single character or very common literals
	commonLiterals := map[string]bool{
		" ":     true,
		"\n":    true,
		"\t":    true,
		",":     true,
		".":     true,
		":":     true,
		";":     true,
		"=":     true,
		"0":     true,
		"1":     true,
		"true":  true,
		"false": true,
		"null":  true,
		"":      true,
		"utf-8": true,
		"UTF-8": true,
	}

	return commonLiterals[strings.ToLower(literal)]
}
