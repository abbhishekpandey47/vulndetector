package errorprone

import (
	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidBranchingStatementAsLastInLoopRule detects branching statements as the last statement in loops
type AvoidBranchingStatementAsLastInLoopRule struct{}

func (r AvoidBranchingStatementAsLastInLoopRule) Rule() string {
	return "AvoidBranchingStatementAsLastInLoop"
}

func (r AvoidBranchingStatementAsLastInLoopRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidBranchingStatementAsLastInLoopRule) Classification() string {
	return "Maintainability"
}

func (r AvoidBranchingStatementAsLastInLoopRule) Priority() int {
	return 2
}

func (r AvoidBranchingStatementAsLastInLoopRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Query for different types of loops
	loopQueries := []string{
		`(for_statement body: (block) @loop_body) @loop`,
		`(enhanced_for_statement body: (block) @loop_body) @loop`,
		`(while_statement body: (block) @loop_body) @loop`,
		`(do_statement body: (block) @loop_body) @loop`,
	}

	for _, queryStr := range loopQueries {
		query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
		if err != nil {
			continue
		}

		cursor := sitter.NewQueryCursor()
		cursor.Exec(query, tree.RootNode())

		for {
			match, ok := cursor.NextMatch()
			if !ok {
				break
			}

			for _, capture := range match.Captures {
				captureName := query.CaptureNameForId(capture.Index)
				if captureName == "loop_body" {
					r.checkLastStatementInBlock(capture.Node, source, &issues)
				}
			}
		}
	}

	return issues
}

// checkLastStatementInBlock checks if the last statement in a block is a branching statement
func (r AvoidBranchingStatementAsLastInLoopRule) checkLastStatementInBlock(blockNode *sitter.Node, source []byte, issues *[]staticanalyzer.Issue) {
	if blockNode == nil || blockNode.Type() != "block" {
		return
	}

	// Get all statements in the block
	var statements []*sitter.Node
	for i := 0; i < int(blockNode.ChildCount()); i++ {
		child := blockNode.Child(i)
		if child != nil && r.isStatement(child) {
			statements = append(statements, child)
		}
	}

	if len(statements) == 0 {
		return
	}

	// Check the last statement
	lastStatement := statements[len(statements)-1]
	if r.isBranchingStatement(lastStatement) {
		// Get the actual branching statement node
		branchingNode := r.getBranchingStatementNode(lastStatement)
		if branchingNode != nil {
			*issues = append(*issues, staticanalyzer.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Avoid using a branching statement as the last in a loop.",
				BeginLine:      int(branchingNode.StartPoint().Row) + 1,
				EndLine:        int(branchingNode.EndPoint().Row) + 1,
				BeginColumn:    int(branchingNode.StartPoint().Column) + 1,
				EndColumn:      int(branchingNode.EndPoint().Column) + 1,
			})
		}
	}
}

// isStatement checks if a node is a statement
func (r AvoidBranchingStatementAsLastInLoopRule) isStatement(node *sitter.Node) bool {
	if node == nil {
		return false
	}

	statementTypes := map[string]bool{
		"expression_statement":       true,
		"if_statement":               true,
		"while_statement":            true,
		"for_statement":              true,
		"enhanced_for_statement":     true,
		"do_statement":               true,
		"break_statement":            true,
		"continue_statement":         true,
		"return_statement":           true,
		"throw_statement":            true,
		"try_statement":              true,
		"switch_statement":           true,
		"block":                      true,
		"empty_statement":            true,
		"local_variable_declaration": true,
	}

	return statementTypes[node.Type()]
}

// isBranchingStatement checks if a statement contains a branching statement (break/continue)
func (r AvoidBranchingStatementAsLastInLoopRule) isBranchingStatement(node *sitter.Node) bool {
	if node == nil {
		return false
	}

	// Direct branching statements
	if node.Type() == "break_statement" || node.Type() == "continue_statement" {
		return true
	}

	// Check for branching statements within the node
	return r.containsBranchingStatement(node)
}

// containsBranchingStatement recursively checks if a node contains branching statements
func (r AvoidBranchingStatementAsLastInLoopRule) containsBranchingStatement(node *sitter.Node) bool {
	if node == nil {
		return false
	}

	if node.Type() == "break_statement" || node.Type() == "continue_statement" {
		return true
	}

	// Recursively check children
	for i := 0; i < int(node.ChildCount()); i++ {
		child := node.Child(i)
		if r.containsBranchingStatement(child) {
			return true
		}
	}

	return false
}

// getBranchingStatementNode finds the actual break/continue statement node
func (r AvoidBranchingStatementAsLastInLoopRule) getBranchingStatementNode(node *sitter.Node) *sitter.Node {
	if node == nil {
		return nil
	}

	if node.Type() == "break_statement" || node.Type() == "continue_statement" {
		return node
	}

	// Recursively search for branching statement
	for i := 0; i < int(node.ChildCount()); i++ {
		child := node.Child(i)
		if result := r.getBranchingStatementNode(child); result != nil {
			return result
		}
	}

	return nil
}
