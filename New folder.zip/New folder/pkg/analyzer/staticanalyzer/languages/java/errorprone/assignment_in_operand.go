package errorprone

import (
	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AssignmentInOperandRule detects assignments in operands
type AssignmentInOperandRule struct{}

func (r AssignmentInOperandRule) Rule() string {
	return "AssignmentInOperand"
}

func (r AssignmentInOperandRule) RuleSet() string {
	return "errorprone"
}

func (r AssignmentInOperandRule) Classification() string {
	return "Maintainability"
}

func (r AssignmentInOperandRule) Priority() int {
	return 3
}

func (r AssignmentInOperandRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Updated query based on actual AST structure
	queryStr := `
		[
			(if_statement 
				(parenthesized_expression 
					(binary_expression 
						(parenthesized_expression 
							(assignment_expression) @assignment))))
			(if_statement 
				(parenthesized_expression 
					(assignment_expression) @assignment))
			(while_statement 
				(parenthesized_expression 
					(binary_expression 
						(parenthesized_expression 
							(assignment_expression) @assignment))))
			(while_statement 
				(parenthesized_expression 
					(assignment_expression) @assignment))
			(for_statement 
				(assignment_expression) @assignment)
			(method_invocation 
				(argument_list 
					(assignment_expression) @assignment))
			(method_invocation 
				(argument_list 
					(parenthesized_expression 
						(assignment_expression) @assignment)))
		]
	`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			node := capture.Node

			// Check if this is really an assignment in an operand context
			if r.isAssignmentInOperand(node) {
				issues = append(issues, staticanalyzer.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Priority:       r.Priority(),
					Description:    "Avoid assignments in operands; this can make code more complicated and harder to read.",
					BeginLine:      int(node.StartPoint().Row) + 1,
					EndLine:        int(node.EndPoint().Row) + 1,
					BeginColumn:    int(node.StartPoint().Column) + 1,
					EndColumn:      int(node.EndPoint().Column) + 1,
				})
			}
		}
	}

	return issues
}

// isAssignmentInOperand checks if the assignment is within an operand context
func (r AssignmentInOperandRule) isAssignmentInOperand(node *sitter.Node) bool {
	// Check if the assignment is within a condition or expression context
	parent := node.Parent()
	for parent != nil {
		switch parent.Type() {
		case "if_statement", "while_statement", "for_statement":
			// Check if we're in the condition part
			if parent.ChildByFieldName("condition") != nil {
				return true
			}
		case "parenthesized_expression":
			// Check if parenthesized expression is part of a condition
			grandparent := parent.Parent()
			if grandparent != nil && (grandparent.Type() == "if_statement" || grandparent.Type() == "while_statement") {
				return true
			}
		case "method_invocation":
			// Assignment in method arguments
			return true
		case "binary_expression":
			// Assignment as part of binary expression
			return true
		}
		parent = parent.Parent()
	}
	return false
}
