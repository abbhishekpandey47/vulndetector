package errorprone

import (
	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

// AvoidAssertAsIdentifierRule detects use of "assert" as an identifier
type AvoidAssertAsIdentifierRule struct{}

func (r AvoidAssertAsIdentifierRule) Rule() string {
	return "AvoidAssertAsIdentifier"
}

func (r AvoidAssertAsIdentifierRule) RuleSet() string {
	return "errorprone"
}

func (r AvoidAssertAsIdentifierRule) Classification() string {
	return "Maintainability"
}

func (r AvoidAssertAsIdentifierRule) Priority() int {
	return 2
}

func (r AvoidAssertAsIdentifierRule) Analyze(rawAST interface{}, source []byte, _ staticanalyzer.Language) []staticanalyzer.Issue {
	var issues []staticanalyzer.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	// Query for identifiers
	queryStr := `(identifier) @identifier`

	query, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
	if err != nil {
		return issues
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, tree.RootNode())

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			node := capture.Node
			identifierText := string(source[node.StartByte():node.EndByte()])

			// Check if the identifier is "assert"
			if identifierText == "assert" {
				// Make sure this is being used as an identifier, not an assert statement
				if r.isUsedAsIdentifier(node) {
					issues = append(issues, staticanalyzer.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Priority:       r.Priority(),
						Description:    "Avoid using assert as an identifier; it became a reserved word in JDK 1.4",
						BeginLine:      int(node.StartPoint().Row) + 1,
						EndLine:        int(node.EndPoint().Row) + 1,
						BeginColumn:    int(node.StartPoint().Column) + 1,
						EndColumn:      int(node.EndPoint().Column) + 1,
					})
				}
			}
		}
	}

	return issues
}

// isUsedAsIdentifier checks if "assert" is being used as an identifier rather than a keyword
func (r AvoidAssertAsIdentifierRule) isUsedAsIdentifier(node *sitter.Node) bool {
	parent := node.Parent()
	if parent == nil {
		return false
	}

	// Check various contexts where "assert" would be used as an identifier
	switch parent.Type() {
	case "variable_declarator":
		// String assert = "foo";
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "field_declaration":
		// field declaration with assert as field name
		return true
	case "formal_parameter":
		// method parameter named assert
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "method_declaration":
		// method named assert
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "class_declaration":
		// class named assert
		nameField := parent.ChildByFieldName("name")
		return nameField == node
	case "package_declaration":
		// package containing assert
		return true
	case "import_declaration":
		// import with assert
		return true
	default:
		// Check if parent is assert_statement - if so, it's a keyword use
		if parent.Type() == "assert_statement" {
			return false
		}
		// Otherwise, likely being used as identifier
		return true
	}
}
