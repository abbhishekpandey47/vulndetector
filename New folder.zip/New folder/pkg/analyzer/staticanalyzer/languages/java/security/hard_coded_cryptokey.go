package security

import (
	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type HardCodedCryptoKeyRule struct{}

func (r *HardCodedCryptoKeyRule) Rule() string           { return "HardCodedCryptoKey" }
func (r *HardCodedCryptoKeyRule) RuleSet() string        { return "Security" }
func (r *HardCodedCryptoKeyRule) Classification() string { return "Security" }
func (r *HardCodedCryptoKeyRule) Priority() int          { return 3 }

func (r *HardCodedCryptoKeyRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for crypto-related constructor calls with potential hard-coded keys
	query := `
	(object_creation_expression
		type: (type_identifier) @class_name
		arguments: (argument_list
			(string_literal) @key_arg
		)
	) @constructor

	(object_creation_expression
		type: (type_identifier) @class_name
		arguments: (argument_list
			(method_invocation
				object: (string_literal) @string_literal
				name: (identifier) @method_name
			) @getbytes_call
		)
	) @constructor_getbytes

	(variable_declarator
		name: (identifier) @var_name
		value: (string_literal) @string_value
	) @string_var

	(field_declaration
		declarator: (variable_declarator
			name: (identifier) @field_name
			value: (string_literal) @field_value
		)
	) @field_decl
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)

			switch captureName {
			case "constructor":
				if r.isCryptoConstructor(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded encryption key detected in constructor. Store keys outside of source code.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "constructor_getbytes":
				if r.isCryptoConstructorWithGetBytes(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded encryption key detected in constructor using getBytes(). Store keys outside of source code.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "string_var":
				if r.isCryptoRelatedVariable(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded encryption key in variable. Store keys outside of source code.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "field_decl":
				if r.isCryptoRelatedField(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded encryption key in field. Store keys outside of source code.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}
			}
		}
	}

	return issues
}

// isCryptoConstructor checks if this is a cryptographic constructor with hard-coded key
func (r *HardCodedCryptoKeyRule) isCryptoConstructor(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var className, keyArg string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "class_name":
			className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "key_arg":
			keyArg = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isCryptoClass(className) && r.isHardCodedKey(keyArg)
}

// isCryptoConstructorWithGetBytes checks constructor with string.getBytes() pattern
func (r *HardCodedCryptoKeyRule) isCryptoConstructorWithGetBytes(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var className, methodName string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "class_name":
			className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "method_name":
			methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isCryptoClass(className) && methodName == "getBytes"
}

// isCryptoRelatedVariable checks if variable name suggests it's crypto-related
func (r *HardCodedCryptoKeyRule) isCryptoRelatedVariable(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var varName, stringValue string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "var_name":
			varName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "string_value":
			stringValue = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isCryptoVariableName(varName) && r.isHardCodedKey(stringValue)
}

// isCryptoRelatedField checks if field name suggests it's crypto-related
func (r *HardCodedCryptoKeyRule) isCryptoRelatedField(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var fieldName, fieldValue string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "field_name":
			fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "field_value":
			fieldValue = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isCryptoVariableName(fieldName) && r.isHardCodedKey(fieldValue)
}

// isCryptoClass checks if the class name is related to cryptography
func (r *HardCodedCryptoKeyRule) isCryptoClass(className string) bool {
	cryptoClasses := []string{
		"SecretKeySpec",
		"KeySpec",
		"SecretKey",
		"Cipher",
		"Mac",
		"KeyGenerator",
		"SecretKeyFactory",
		"PBEKeySpec",
		"DESKeySpec",
		"DESedeKeySpec",
	}

	for _, cryptoClass := range cryptoClasses {
		if className == cryptoClass {
			return true
		}
	}
	return false
}

// isCryptoVariableName checks if variable name suggests cryptographic usage
func (r *HardCodedCryptoKeyRule) isCryptoVariableName(varName string) bool {
	lowerName := strings.ToLower(varName)
	cryptoKeywords := []string{
		"key", "secret", "password", "pass", "crypto", "cipher",
		"encrypt", "decrypt", "aes", "des", "rsa", "hmac", "salt",
	}

	for _, keyword := range cryptoKeywords {
		if strings.Contains(lowerName, keyword) {
			return true
		}
	}
	return false
}

// isHardCodedKey checks if the string looks like a hard-coded key
func (r *HardCodedCryptoKeyRule) isHardCodedKey(value string) bool {
	// Remove quotes and check if it's a non-empty string literal
	if len(value) < 3 { // At least "" or ''
		return false
	}

	// Check for quoted strings
	if (strings.HasPrefix(value, "\"") && strings.HasSuffix(value, "\"")) ||
		(strings.HasPrefix(value, "'") && strings.HasSuffix(value, "'")) {

		// Extract content without quotes
		content := value[1 : len(value)-1]

		// Skip if empty or very short
		if len(content) < 3 {
			return false
		}

		// Skip common non-key patterns
		excludePatterns := []string{
			"utf-8", "utf8", "iso-8859-1", "ascii",
			"aes", "des", "rsa", "md5", "sha", "hmac",
			"algorithm", "transformation",
		}

		contentLower := strings.ToLower(content)
		for _, pattern := range excludePatterns {
			if contentLower == pattern {
				return false
			}
		}

		// If it contains spaces or looks like a sentence, likely a key
		if strings.Contains(content, " ") || len(content) > 8 {
			return true
		}
	}

	return false
}

func (r *HardCodedCryptoKeyRule) GetDescription() string {
	return `Do not use hard coded values for cryptographic operations. Please store keys outside of source code.

Hard-coded cryptographic keys pose serious security risks:
1. Keys are visible in source code and version control
2. Keys cannot be rotated without code changes
3. Different environments cannot use different keys
4. Keys may be exposed in compiled binaries

Example of problematic code:
public class Foo {
    void bad() {
        SecretKeySpec secretKeySpec = new SecretKeySpec("my secret here".getBytes(), "AES");
        String hardCodedKey = "super-secret-key-123";
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec("hardcoded".getBytes(), "AES"));
    }
}

Recommended alternatives:
public class Foo {
    void good() {
        // Load from external configuration
        SecretKeySpec secretKeySpec = new SecretKeySpec(Properties.getKey(), "AES");
        
        // Load from environment variables
        String key = System.getenv("ENCRYPTION_KEY");
        
        // Load from secure configuration files
        String key = configService.getSecureProperty("crypto.key");
        
        // Use key management services
        SecretKey key = keyManagementService.getKey("my-key-id");
    }
}

Store encryption keys in:
- Environment variables
- Secure configuration files (outside version control)
- Key management systems (AWS KMS, Azure Key Vault, etc.)
- Hardware Security Modules (HSMs)
- Dedicated secret management tools (HashiCorp Vault, etc.)`
}
