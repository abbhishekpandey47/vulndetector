package security

import (
	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type InsecureCryptoIvRule struct{}

func (r *InsecureCryptoIvRule) Rule() string           { return "InsecureCryptoIv" }
func (r *InsecureCryptoIvRule) RuleSet() string        { return "Security" }
func (r *InsecureCryptoIvRule) Classification() string { return "Security" }
func (r *InsecureCryptoIvRule) Priority() int          { return 3 }

func (r *InsecureCryptoIvRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for various IV-related patterns
	query := `
	(object_creation_expression
		type: (type_identifier) @class_name
		arguments: (argument_list
			(array_creation_expression) @array_arg
		)
	) @constructor

	(object_creation_expression
		type: (type_identifier) @class_name
		arguments: (argument_list
			(string_literal) @string_arg
		)
	) @constructor_string

	(object_creation_expression
		type: (type_identifier) @class_name
		arguments: (argument_list
			(method_invocation
				object: (string_literal) @string_literal
				name: (identifier) @method_name
			) @getbytes_call
		)
	) @constructor_getbytes

	(variable_declarator
		name: (identifier) @var_name
		value: (array_creation_expression) @array_value
	) @array_var

	(variable_declarator
		name: (identifier) @var_name
		value: (array_initializer) @array_value
	) @array_var_init

	(variable_declarator
		name: (identifier) @var_name
		value: (string_literal) @string_value
	) @string_var

	(field_declaration
		declarator: (variable_declarator
			name: (identifier) @field_name
			value: (array_creation_expression) @field_array_value
		)
	) @field_array_decl

	(field_declaration
		declarator: (variable_declarator
			name: (identifier) @field_name
			value: (array_initializer) @field_array_value
		)
	) @field_array_init

	(field_declaration
		declarator: (variable_declarator
			name: (identifier) @field_name
			value: (string_literal) @field_string_value
		)
	) @field_string_decl

	(method_invocation
		name: (identifier) @method_name
		arguments: (argument_list
			(array_creation_expression) @init_array_arg
		)
	) @method_call_array

	(method_invocation
		name: (identifier) @method_name
		arguments: (argument_list
			(object_creation_expression
				type: (type_identifier) @param_class
				arguments: (argument_list
					(array_creation_expression) @param_array
				)
			) @param_spec
		)
	) @method_call_param_spec
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)

			switch captureName {
			case "constructor":
				if r.isIvConstructorWithArray(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded initialization vector detected in constructor. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "constructor_string":
				if r.isIvConstructorWithString(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded initialization vector detected in constructor using string. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "constructor_getbytes":
				if r.isIvConstructorWithGetBytes(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded initialization vector detected in constructor using getBytes(). Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "array_var":
				if r.isIvRelatedArrayVariable(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded initialization vector in variable. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "array_var_init":
				if r.isIvRelatedArrayVariable(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded initialization vector in variable. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "string_var":
				if r.isIvRelatedStringVariable(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded initialization vector in string variable. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "field_array_decl":
				if r.isIvRelatedArrayField(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded initialization vector in field. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "field_array_init":
				if r.isIvRelatedArrayField(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded initialization vector in field. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "field_string_decl":
				if r.isIvRelatedStringField(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Potential hard-coded initialization vector in string field. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "method_call_array":
				if r.isIvMethodCallWithArray(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded initialization vector detected in method call. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}

			case "method_call_param_spec":
				if r.isIvMethodCallWithParamSpec(match, q, source) {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "Hard-coded initialization vector detected in parameter spec. Use randomly generated IVs.",
						Priority:       r.Priority(),
						BeginLine:      int(capture.Node.StartPoint().Row + 1),
						BeginColumn:    int(capture.Node.StartPoint().Column + 1),
						EndLine:        int(capture.Node.EndPoint().Row + 1),
						EndColumn:      int(capture.Node.EndPoint().Column + 1),
					})
				}
			}
		}
	}

	return issues
}

// isIvConstructorWithArray checks if this is an IV-related constructor with hard-coded array
func (r *InsecureCryptoIvRule) isIvConstructorWithArray(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var className string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		if captureName == "class_name" {
			className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			break
		}
	}

	return r.isIvClass(className)
}

// isIvConstructorWithString checks if this is an IV-related constructor with hard-coded string
func (r *InsecureCryptoIvRule) isIvConstructorWithString(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var className, stringArg string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "class_name":
			className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "string_arg":
			stringArg = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isIvClass(className) && r.isHardCodedValue(stringArg)
}

// isIvConstructorWithGetBytes checks constructor with string.getBytes() pattern
func (r *InsecureCryptoIvRule) isIvConstructorWithGetBytes(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var className, methodName string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "class_name":
			className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "method_name":
			methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isIvClass(className) && methodName == "getBytes"
}

// isIvRelatedArrayVariable checks if variable name suggests it's IV-related array
func (r *InsecureCryptoIvRule) isIvRelatedArrayVariable(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var varName string
	var arrayContent string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "var_name":
			varName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "array_value":
			arrayContent = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	// Only flag if variable has IV-related name AND contains literal values
	if !r.isIvVariableName(varName) {
		return false
	}

	// Check if array contains literal values (not just "new byte[...]")
	// We're looking for arrays with explicit values like {1, 2, 3, ...}
	return strings.Contains(arrayContent, "{") && strings.Contains(arrayContent, "}")
}

// isIvRelatedStringVariable checks if variable name suggests it's IV-related string
func (r *InsecureCryptoIvRule) isIvRelatedStringVariable(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var varName, stringValue string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "var_name":
			varName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "string_value":
			stringValue = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isIvVariableName(varName) && r.isHardCodedValue(stringValue)
}

// isIvRelatedArrayField checks if field name suggests it's IV-related array
func (r *InsecureCryptoIvRule) isIvRelatedArrayField(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var fieldName string
	var arrayContent string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "field_name":
			fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "field_array_value":
			arrayContent = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	// Only flag if field has IV-related name AND contains literal values
	if !r.isIvVariableName(fieldName) {
		return false
	}

	// Check if array contains literal values (not just "new byte[...]")
	return strings.Contains(arrayContent, "{") && strings.Contains(arrayContent, "}")
}

// isIvRelatedStringField checks if field name suggests it's IV-related string
func (r *InsecureCryptoIvRule) isIvRelatedStringField(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var fieldName, fieldValue string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "field_name":
			fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "field_string_value":
			fieldValue = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isIvVariableName(fieldName) && r.isHardCodedValue(fieldValue)
}

// isIvMethodCallWithArray checks if method call uses hard-coded array for IV
func (r *InsecureCryptoIvRule) isIvMethodCallWithArray(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var methodName string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		if captureName == "method_name" {
			methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			break
		}
	}

	return r.isCipherInitMethod(methodName)
}

// isIvMethodCallWithParamSpec checks if method call uses hard-coded parameter spec for IV
func (r *InsecureCryptoIvRule) isIvMethodCallWithParamSpec(match *sitter.QueryMatch, q *sitter.Query, source []byte) bool {
	var methodName, paramClass string

	for _, capture := range match.Captures {
		captureName := q.CaptureNameForId(capture.Index)
		switch captureName {
		case "method_name":
			methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		case "param_class":
			paramClass = string(source[capture.Node.StartByte():capture.Node.EndByte()])
		}
	}

	return r.isCipherInitMethod(methodName) && r.isIvParameterClass(paramClass)
}

// isIvClass checks if the class name is related to IV operations
func (r *InsecureCryptoIvRule) isIvClass(className string) bool {
	ivClasses := []string{
		"IvParameterSpec",
		"GCMParameterSpec",
		"PBEParameterSpec",
		"DHParameterSpec",
		"OAEPParameterSpec",
		"RC2ParameterSpec",
		"RC5ParameterSpec",
	}

	for _, ivClass := range ivClasses {
		if className == ivClass {
			return true
		}
	}
	return false
}

// isIvVariableName checks if variable name suggests IV usage
func (r *InsecureCryptoIvRule) isIvVariableName(varName string) bool {
	lowerName := strings.ToLower(varName)
	ivKeywords := []string{
		"iv", "initvector", "initialization", "nonce", "salt",
		"vector", "ivbytes", "ivdata", "ivparam",
	}

	// Only match if the variable name contains these keywords as significant parts
	for _, keyword := range ivKeywords {
		if strings.Contains(lowerName, keyword) {
			// Avoid false positives for common words that might contain these substrings
			// but are not actually IV-related
			if keyword == "iv" && (strings.Contains(lowerName, "private") ||
				strings.Contains(lowerName, "drive") ||
				strings.Contains(lowerName, "derive") ||
				strings.Contains(lowerName, "archive")) {
				continue
			}
			return true
		}
	}
	return false
}

// isCipherInitMethod checks if method is cipher initialization
func (r *InsecureCryptoIvRule) isCipherInitMethod(methodName string) bool {
	return methodName == "init"
}

// isIvParameterClass checks if class is an IV parameter class
func (r *InsecureCryptoIvRule) isIvParameterClass(className string) bool {
	return strings.Contains(className, "ParameterSpec") || strings.Contains(className, "Parameter")
}

// isHardCodedValue checks if the string looks like a hard-coded value
func (r *InsecureCryptoIvRule) isHardCodedValue(value string) bool {
	// Remove quotes and check if it's a non-empty string literal
	if len(value) < 3 { // At least "" or ''
		return false
	}

	// Check for quoted strings
	if (strings.HasPrefix(value, "\"") && strings.HasSuffix(value, "\"")) ||
		(strings.HasPrefix(value, "'") && strings.HasSuffix(value, "'")) {

		// Extract content without quotes
		content := value[1 : len(value)-1]

		// Skip if empty or very short
		if len(content) < 4 {
			return false
		}

		// Skip common non-IV patterns
		excludePatterns := []string{
			"utf-8", "utf8", "iso-8859-1", "ascii",
			"aes", "des", "rsa", "md5", "sha", "hmac",
			"algorithm", "transformation", "mode", "padding",
		}

		contentLower := strings.ToLower(content)
		for _, pattern := range excludePatterns {
			if contentLower == pattern {
				return false
			}
		}

		// If it contains meaningful content, likely an IV
		return len(content) >= 4
	}

	return false
}

func (r *InsecureCryptoIvRule) GetDescription() string {
	return `Do not use hard coded initialization vector in cryptographic operations. Please use a randomly generated IV.

Hard-coded initialization vectors (IVs) pose serious security risks:
1. IVs should be unique and random for each encryption operation
2. Reusing IVs with the same key makes encrypted data predictable
3. Same plaintext with same key and IV produces identical ciphertext
4. This enables pattern analysis and cryptographic attacks
5. Violates semantic security requirements

Example of problematic code:
public class Foo {
    void bad() {
        byte[] iv = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        
        String ivString = "1234567890123456";
        IvParameterSpec hardcodedIvSpec = new IvParameterSpec(ivString.getBytes());
        
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
    }
}

Recommended alternatives:
public class Foo {
    void good() {
        // Generate random IV for each operation
        SecureRandom random = new SecureRandom();
        byte[] iv = new byte[16];
        random.nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        
        // Use cipher-generated IV
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        
        // Load IV from secure external source
        byte[] storedIv = loadIvFromSecureSource();
        IvParameterSpec externalIvSpec = new IvParameterSpec(storedIv);
        
        // For GCM mode, use proper nonce generation
        byte[] nonce = new byte[12];
        random.nextBytes(nonce);
        GCMParameterSpec gcmSpec = new GCMParameterSpec(128, nonce);
    }
}

Best practices for IV generation:
- Use SecureRandom for IV generation
- Generate a new IV for each encryption operation  
- Store IV alongside encrypted data (it's not secret)
- Use appropriate IV/nonce sizes for your cipher mode
- For GCM mode, ensure nonce uniqueness per key
- Never reuse IV with the same key`
}
