package security

import (
	"context"
	"os"
	"testing"

	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

func TestHardCodedCryptoKeyRule_DetectsViolations(t *testing.T) {
	rule := &HardCodedCryptoKeyRule{}

	// Sample Java code with various hard-coded crypto key patterns
	javaCode := `
package com.example;

import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import javax.crypto.Mac;

public class CryptoExample {
    // Field with hard-coded key (should be detected)
    private static final String SECRET_KEY = "my-super-secret-key-123";
    private final String encryptionKey = "hardcoded-aes-key";
    
    // Fields that should NOT be detected
    private static final String ALGORITHM = "AES";
    private final String charset = "UTF-8";

    public void badExamples() {
        // Direct string literal in constructor (should be detected)
        SecretKeySpec secretKeySpec1 = new SecretKeySpec("my secret here", "AES");
        
        // String with getBytes() (should be detected)
        SecretKeySpec secretKeySpec2 = new SecretKeySpec("another secret".getBytes(), "AES");
        
        // Local variables with crypto-related names (should be detected)
        String password = "hardcoded-password";
        String cryptoKey = "super-secret-123";
        String hmacSecret = "my-hmac-key";
        
        // Cipher with hard-coded key (should be detected)
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec("hardcoded".getBytes(), "AES"));
        
        // Variables that should NOT be detected (no crypto keywords)
        String username = "john_doe";
        String message = "hello world";
    }

    public void goodExamples() {
        // These should NOT be detected (proper practices)
        SecretKeySpec secretKeySpec = new SecretKeySpec(getKeyFromConfig(), "AES");
        String key = System.getenv("ENCRYPTION_KEY");
        String secret = Properties.getProperty("crypto.key");
        
        // Algorithm names should not be detected
        String algorithm = "AES";
        String transformation = "AES/CBC/PKCS5Padding";
    }
    
    private byte[] getKeyFromConfig() {
        return new byte[16]; // Placeholder
    }
}
`

	// Parse the Java code
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(javaCode))
	if err != nil {
		t.Fatalf("Failed to parse Java code: %v", err)
	}

	// Analyze with our rule
	issues := rule.Analyze(tree, []byte(javaCode), nil)

	if len(issues) == 0 {
		t.Error("Expected to find hard-coded crypto key violations, but found none")
		return
	}

	t.Logf("Found %d violations:", len(issues))
	for i, issue := range issues {
		t.Logf("  %d. Line %d: %s", i+1, issue.BeginLine, issue.Description)
	}

	// Verify we have a reasonable number of detections
	if len(issues) < 3 {
		t.Errorf("Expected at least 3 violations, but found %d", len(issues))
	}

	// Verify all issues are from our rule
	for _, issue := range issues {
		if issue.Rule != "HardCodedCryptoKey" {
			t.Errorf("Expected rule 'HardCodedCryptoKey', got '%s'", issue.Rule)
		}
		if issue.RuleSet != "Security" {
			t.Errorf("Expected ruleset 'Security', got '%s'", issue.RuleSet)
		}
		if issue.Classification != "Security" {
			t.Errorf("Expected classification 'Security', got '%s'", issue.Classification)
		}
		if issue.Priority != 3 {
			t.Errorf("Expected priority 3, got %d", issue.Priority)
		}
	}
}

func TestHardCodedCryptoKeyRule_IgnoresGoodPractices(t *testing.T) {
	rule := &HardCodedCryptoKeyRule{}

	// Java code with proper practices (should NOT trigger violations)
	goodJavaCode := `
package com.example;

import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;

public class GoodCryptoExample {
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    
    public void goodPractices() {
        // Load from external sources (should NOT be detected)
        SecretKeySpec secretKeySpec = new SecretKeySpec(loadKeyFromFile(), "AES");
        String key = System.getenv("ENCRYPTION_KEY");
        String secret = config.getProperty("crypto.key");
        
        // Algorithm and transformation constants (should NOT be detected)
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        
        // Short strings or algorithm names (should NOT be detected)
        String alg = "AES";
        String mode = "CBC";
        String padding = "PKCS5Padding";
        
        // Non-crypto variables (should NOT be detected)
        String username = "user123";
        String message = "hello world";
        String data = "some data to encrypt";
    }
    
    private byte[] loadKeyFromFile() {
        return new byte[16]; // Placeholder
    }
}
`

	// Parse the Java code
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(goodJavaCode))
	if err != nil {
		t.Fatalf("Failed to parse Java code: %v", err)
	}

	// Analyze with our rule
	issues := rule.Analyze(tree, []byte(goodJavaCode), nil)

	// Should find no violations in good code
	if len(issues) > 0 {
		t.Errorf("Expected no violations in good code, but found %d:", len(issues))
		for i, issue := range issues {
			t.Errorf("  %d. Line %d: %s", i+1, issue.BeginLine, issue.Description)
		}
	}
}

func TestHardCodedCryptoKeyRule_SpecificPatterns(t *testing.T) {
	rule := &HardCodedCryptoKeyRule{}

	testCases := []struct {
		name         string
		code         string
		shouldDetect bool
		description  string
	}{
		{
			name:         "SecretKeySpec with literal",
			code:         `SecretKeySpec spec = new SecretKeySpec("secret123", "AES");`,
			shouldDetect: true,
			description:  "Should detect hard-coded key in SecretKeySpec",
		},
		{
			name:         "Cipher with getBytes",
			code:         `cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec("key123".getBytes(), "AES"));`,
			shouldDetect: true,
			description:  "Should detect hard-coded key with getBytes()",
		},
		{
			name:         "Variable with crypto name",
			code:         `String encryptionKey = "my-secret-key-value";`,
			shouldDetect: true,
			description:  "Should detect crypto-named variable with hard-coded value",
		},
		{
			name:         "Algorithm constant",
			code:         `String algorithm = "AES";`,
			shouldDetect: false,
			description:  "Should NOT detect algorithm names",
		},
		{
			name:         "Short string",
			code:         `String key = "ab";`,
			shouldDetect: false,
			description:  "Should NOT detect very short strings",
		},
		{
			name:         "Non-crypto variable",
			code:         `String username = "very-long-username-value";`,
			shouldDetect: false,
			description:  "Should NOT detect non-crypto variables",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Wrap in a simple class
			fullCode := `
public class Test {
    void method() {
        ` + tc.code + `
    }
}`

			parser := sitter.NewParser()
			parser.SetLanguage(java.GetLanguage())

			tree, err := parser.ParseCtx(context.Background(), nil, []byte(fullCode))
			if err != nil {
				t.Fatalf("Failed to parse Java code: %v", err)
			}

			issues := rule.Analyze(tree, []byte(fullCode), nil)

			if tc.shouldDetect {
				if len(issues) == 0 {
					t.Errorf("%s: Expected violation but found none", tc.description)
				}
			} else {
				if len(issues) > 0 {
					t.Errorf("%s: Expected no violation but found %d", tc.description, len(issues))
					for _, issue := range issues {
						t.Logf("  Unexpected issue: %s", issue.Description)
					}
				}
			}
		})
	}
}

func TestHardCodedCryptoKeyRule_RuleMetadata(t *testing.T) {
	rule := &HardCodedCryptoKeyRule{}

	// Test rule metadata
	if rule.Rule() != "HardCodedCryptoKey" {
		t.Errorf("Expected rule name 'HardCodedCryptoKey', got '%s'", rule.Rule())
	}

	if rule.RuleSet() != "Security" {
		t.Errorf("Expected ruleset 'Security', got '%s'", rule.RuleSet())
	}

	if rule.Classification() != "Security" {
		t.Errorf("Expected classification 'Security', got '%s'", rule.Classification())
	}

	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	// Test description is not empty
	description := rule.GetDescription()
	if len(description) == 0 {
		t.Error("Expected non-empty description")
	}

	// Test description contains key information
	if !contains(description, "hard coded") || !contains(description, "cryptographic") {
		t.Error("Description should mention hard coded cryptographic operations")
	}
}

func contains(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

func TestHardCodedCryptoKeyRule_WithExampleFile(t *testing.T) {
	rule := &HardCodedCryptoKeyRule{}

	// Read the example Java file
	exampleFile := "HardCodedCryptoKeyExample.java"
	javaCode, err := os.ReadFile(exampleFile)
	if err != nil {
		t.Skipf("Example file %s not found, skipping test: %v", exampleFile, err)
		return
	}

	// Parse the Java code
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, javaCode)
	if err != nil {
		t.Fatalf("Failed to parse example Java file: %v", err)
	}

	// Analyze with our rule
	issues := rule.Analyze(tree, javaCode, nil)

	if len(issues) == 0 {
		t.Error("Expected to find violations in example file, but found none")
		return
	}

	t.Logf("Found %d violations in example file:", len(issues))
	for i, issue := range issues {
		t.Logf("  %d. Line %d: %s", i+1, issue.BeginLine, issue.Description)
	}

	// We should find a substantial number of violations (at least 15)
	if len(issues) < 15 {
		t.Errorf("Expected at least 15 violations in comprehensive example, found %d", len(issues))
	}
}

func TestInsecureCryptoIvRule_DetectsViolations(t *testing.T) {
	rule := &InsecureCryptoIvRule{}

	// Sample Java code with various hard-coded IV patterns
	javaCode := `
package com.example;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.Cipher;

public class IvExample {
    // Field with hard-coded IV (should be detected)
    private static final byte[] DEFAULT_IV = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    private final String ivString = "1234567890123456";
    
    public void badExamples() {
        // Direct byte array in constructor (should be detected)
        IvParameterSpec ivSpec1 = new IvParameterSpec(new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16});
        
        // String with getBytes() (should be detected)
        IvParameterSpec ivSpec2 = new IvParameterSpec("hardcoded-iv-value".getBytes());
        
        // Local variables with IV-related names (should be detected)
        byte[] iv = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10};
        byte[] initVector = new byte[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        String ivData = "fixed-iv-string-123";
        String nonce = "fixed-nonce-value";
        
        // GCM parameter spec with hard-coded nonce (should be detected)
        GCMParameterSpec gcmSpec = new GCMParameterSpec(128, new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12});
        
        // Cipher init with hard-coded IV parameter (should be detected)
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(new byte[16]));
        
        // Variables that should NOT be detected (no IV keywords)
        String username = "user123";
        byte[] data = {1, 2, 3};
    }

    public void goodExamples() {
        // These should NOT be detected (proper practices)
        IvParameterSpec ivSpec = new IvParameterSpec(generateRandomIv());
        byte[] randomIv = loadIvFromConfig();
        
        // Algorithm names should not be detected
        String algorithm = "AES";
        String mode = "CBC";
    }
    
    private byte[] generateRandomIv() {
        return new byte[16]; // Placeholder
    }
    
    private byte[] loadIvFromConfig() {
        return new byte[16]; // Placeholder
    }
}
`

	// Parse the Java code
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(javaCode))
	if err != nil {
		t.Fatalf("Failed to parse Java code: %v", err)
	}

	// Analyze with our rule
	issues := rule.Analyze(tree, []byte(javaCode), nil)

	if len(issues) == 0 {
		t.Error("Expected to find hard-coded IV violations, but found none")
		return
	}

	t.Logf("Found %d violations:", len(issues))
	for i, issue := range issues {
		t.Logf("  %d. Line %d: %s", i+1, issue.BeginLine, issue.Description)
	}

	// Verify we have a reasonable number of detections
	if len(issues) < 5 {
		t.Errorf("Expected at least 5 violations, but found %d", len(issues))
	}

	// Verify all issues are from our rule
	for _, issue := range issues {
		if issue.Rule != "InsecureCryptoIv" {
			t.Errorf("Expected rule 'InsecureCryptoIv', got '%s'", issue.Rule)
		}
		if issue.RuleSet != "Security" {
			t.Errorf("Expected ruleset 'Security', got '%s'", issue.RuleSet)
		}
		if issue.Classification != "Security" {
			t.Errorf("Expected classification 'Security', got '%s'", issue.Classification)
		}
		if issue.Priority != 3 {
			t.Errorf("Expected priority 3, got %d", issue.Priority)
		}
	}
}

func TestInsecureCryptoIvRule_IgnoresGoodPractices(t *testing.T) {
	rule := &InsecureCryptoIvRule{}

	// Java code with proper IV practices (should NOT trigger violations)
	goodJavaCode := `
package com.example;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.Cipher;
import java.security.SecureRandom;

public class GoodIvExample {
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    
    public void goodPractices() {
        // Generate random IV (should NOT be detected)
        SecureRandom random = new SecureRandom();
        byte[] iv = new byte[16];
        random.nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        
        // Load from external sources (should NOT be detected)
        IvParameterSpec externalIvSpec = new IvParameterSpec(loadIvFromFile());
        
        // Algorithm and mode constants (should NOT be detected)
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        String algorithm = "AES";
        String mode = "CBC";
        String padding = "PKCS5Padding";
        
        // Non-IV variables (should NOT be detected)
        String username = "user123";
        String message = "hello world";
        byte[] data = loadDataFromFile();
    }
    
    private byte[] loadIvFromFile() {
        return new byte[16]; // Placeholder
    }
    
    private byte[] loadDataFromFile() {
        return new byte[32]; // Placeholder
    }
}
`

	// Parse the Java code
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(goodJavaCode))
	if err != nil {
		t.Fatalf("Failed to parse Java code: %v", err)
	}

	// Analyze with our rule
	issues := rule.Analyze(tree, []byte(goodJavaCode), nil)

	// Should find no violations in good code
	if len(issues) > 0 {
		t.Errorf("Expected no violations in good code, but found %d:", len(issues))
		for i, issue := range issues {
			t.Errorf("  %d. Line %d: %s", i+1, issue.BeginLine, issue.Description)
		}
	}
}

func TestInsecureCryptoIvRule_SpecificPatterns(t *testing.T) {
	rule := &InsecureCryptoIvRule{}

	testCases := []struct {
		name         string
		code         string
		shouldDetect bool
		description  string
	}{
		{
			name:         "IvParameterSpec with byte array",
			code:         `IvParameterSpec spec = new IvParameterSpec(new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16});`,
			shouldDetect: true,
			description:  "Should detect hard-coded byte array in IvParameterSpec",
		},
		{
			name:         "IvParameterSpec with getBytes",
			code:         `IvParameterSpec spec = new IvParameterSpec("fixed-iv-value".getBytes());`,
			shouldDetect: true,
			description:  "Should detect hard-coded IV with getBytes()",
		},
		{
			name:         "Variable with IV name",
			code:         `byte[] iv = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};`,
			shouldDetect: true,
			description:  "Should detect IV-named variable with hard-coded value",
		},
		{
			name:         "Algorithm constant",
			code:         `String algorithm = "AES";`,
			shouldDetect: false,
			description:  "Should NOT detect algorithm names",
		},
		{
			name:         "Short array",
			code:         `byte[] data = {1, 2};`,
			shouldDetect: false,
			description:  "Should NOT detect very short arrays",
		},
		{
			name:         "Non-IV variable",
			code:         `byte[] data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};`,
			shouldDetect: false,
			description:  "Should NOT detect non-IV variables",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Wrap in a simple class
			fullCode := `
public class Test {
    void method() {
        ` + tc.code + `
    }
}`

			parser := sitter.NewParser()
			parser.SetLanguage(java.GetLanguage())

			tree, err := parser.ParseCtx(context.Background(), nil, []byte(fullCode))
			if err != nil {
				t.Fatalf("Failed to parse Java code: %v", err)
			}

			issues := rule.Analyze(tree, []byte(fullCode), nil)

			if tc.shouldDetect {
				if len(issues) == 0 {
					t.Errorf("%s: Expected violation but found none", tc.description)
				}
			} else {
				if len(issues) > 0 {
					t.Errorf("%s: Expected no violation but found %d", tc.description, len(issues))
					for _, issue := range issues {
						t.Logf("  Unexpected issue: %s", issue.Description)
					}
				}
			}
		})
	}
}

func TestInsecureCryptoIvRule_RuleMetadata(t *testing.T) {
	rule := &InsecureCryptoIvRule{}

	// Test rule metadata
	if rule.Rule() != "InsecureCryptoIv" {
		t.Errorf("Expected rule name 'InsecureCryptoIv', got '%s'", rule.Rule())
	}

	if rule.RuleSet() != "Security" {
		t.Errorf("Expected ruleset 'Security', got '%s'", rule.RuleSet())
	}

	if rule.Classification() != "Security" {
		t.Errorf("Expected classification 'Security', got '%s'", rule.Classification())
	}

	if rule.Priority() != 3 {
		t.Errorf("Expected priority 3, got %d", rule.Priority())
	}

	// Test description is not empty
	description := rule.GetDescription()
	if len(description) == 0 {
		t.Error("Expected non-empty description")
	}

	// Test description contains key information
	if !contains(description, "initialization vector") || !contains(description, "randomly generated") {
		t.Error("Description should mention initialization vector and random generation")
	}
}

func TestInsecureCryptoIvRule_WithExampleFile(t *testing.T) {
	rule := &InsecureCryptoIvRule{}

	// Read the example Java file
	exampleFile := "InsecureCryptoIvExample.java"
	javaCode, err := os.ReadFile(exampleFile)
	if err != nil {
		t.Skipf("Example file %s not found, skipping test: %v", exampleFile, err)
		return
	}

	// Parse the Java code
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, javaCode)
	if err != nil {
		t.Fatalf("Failed to parse example Java file: %v", err)
	}

	// Analyze with our rule
	issues := rule.Analyze(tree, javaCode, nil)

	if len(issues) == 0 {
		t.Error("Expected to find violations in example file, but found none")
		return
	}

	t.Logf("Found %d violations in example file:", len(issues))
	for i, issue := range issues {
		t.Logf("  %d. Line %d: %s", i+1, issue.BeginLine, issue.Description)
	}

	// We should find a substantial number of violations (at least 10)
	if len(issues) < 10 {
		t.Errorf("Expected at least 10 violations in comprehensive example, found %d", len(issues))
	}
}
