package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type AvoidSynchronizedStatementRule struct{}

func (r *AvoidSynchronizedStatementRule) Rule() string           { return "AvoidSynchronizedStatement" }
func (r *AvoidSynchronizedStatementRule) RuleSet() string        { return "Multithreading" }
func (r *AvoidSynchronizedStatementRule) Classification() string { return "Performance" }
func (r *AvoidSynchronizedStatementRule) Priority() int          { return 3 }

func (r *AvoidSynchronizedStatementRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for synchronized statements
	query := `
	(synchronized_statement) @sync_stmt
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			if name == "sync_stmt" {
				syncNode := capture.Node
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Use ReentrantLock rather than synchronization. Synchronization will pin virtual threads and can cause performance problems",
					Priority:       r.Priority(),
					BeginLine:      int(syncNode.StartPoint().Row + 1),
					BeginColumn:    int(syncNode.StartPoint().Column + 1),
					EndLine:        int(syncNode.EndPoint().Row + 1),
					EndColumn:      int(syncNode.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

func (r *AvoidSynchronizedStatementRule) GetDescription() string {
	return `Synchronization will pin virtual threads and can cause performance problems.

Example of problematic code:
// Try to avoid this:
void foo() {
    // code that doesn't need mutual exclusion
    synchronized(this) {
        // code that requires mutual exclusion
    }
    // more code that doesn't need mutual exclusion
}

Prefer using ReentrantLock:
Lock instanceLock = new ReentrantLock();

void foo() {
    // code that doesn't need mutual exclusion
    try {
        instanceLock.lock();  // or instanceLock.tryLock(long time, TimeUnit unit)
        // code that requires mutual exclusion
    } finally {
        instanceLock.unlock();
    }
    // more code that doesn't need mutual exclusion
}`
}
