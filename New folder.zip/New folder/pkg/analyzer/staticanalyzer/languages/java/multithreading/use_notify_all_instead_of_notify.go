package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type UseNotifyAllInsteadOfNotifyRule struct{}

func (r *UseNotifyAllInsteadOfNotifyRule) Rule() string           { return "UseNotifyAllInsteadOfNotify" }
func (r *UseNotifyAllInsteadOfNotifyRule) RuleSet() string        { return "Multithreading" }
func (r *UseNotifyAllInsteadOfNotifyRule) Classification() string { return "Reliability" }
func (r *UseNotifyAllInsteadOfNotifyRule) Priority() int          { return 3 }

func (r *UseNotifyAllInsteadOfNotifyRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for method invocation of notify()
	query := `
	(method_invocation
		name: (identifier) @method_name
	) @method_call
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var methodName string
		var methodCallNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "method_name":
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "method_call":
				methodCallNode = capture.Node
			}
		}

		if methodName == "notify" && methodCallNode != nil {
			// Check if this is a notify() call (not notifyAll())
			if r.isNotifyCall(methodCallNode, source) {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Call Thread.notifyAll() rather than Thread.notify(). Using notify() awakens only one arbitrary thread, while notifyAll() awakens all waiting threads",
					Priority:       r.Priority(),
					BeginLine:      int(methodCallNode.StartPoint().Row + 1),
					BeginColumn:    int(methodCallNode.StartPoint().Column + 1),
					EndLine:        int(methodCallNode.EndPoint().Row + 1),
					EndColumn:      int(methodCallNode.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

func (r *UseNotifyAllInsteadOfNotifyRule) isNotifyCall(methodCallNode *sitter.Node, source []byte) bool {
	// Verify this is actually notify() and not some other method named notify
	// We'll check that it has no arguments (notify() vs notify(args))
	for i := uint32(0); i < methodCallNode.ChildCount(); i++ {
		child := methodCallNode.Child(int(i))
		if child != nil && child.Type() == "argument_list" {
			// Check if argument list is empty
			if child.ChildCount() <= 2 { // Just opening and closing parentheses
				return true
			}
		}
	}
	return true // Default to true if we can't determine argument count
}

func (r *UseNotifyAllInsteadOfNotifyRule) GetDescription() string {
	return `Thread.notify() awakens a thread monitoring the object. If more than one thread is monitoring, then only
one is chosen. The thread chosen is arbitrary; thus its usually safer to call notifyAll() instead.

Example of problematic code:
void bar() {
    x.notify();
    // If many threads are monitoring x, only one (and you won't know which) will be notified.
    // use instead:
    x.notifyAll();
}

Using notifyAll() ensures all waiting threads are awakened and can compete for the lock, preventing potential deadlocks.`
}
