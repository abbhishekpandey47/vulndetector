package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type DoubleCheckedLockingRule struct{}

func (r *DoubleCheckedLockingRule) Rule() string           { return "DoubleCheckedLocking" }
func (r *DoubleCheckedLockingRule) RuleSet() string        { return "Multithreading" }
func (r *DoubleCheckedLockingRule) Classification() string { return "Reliability" }
func (r *DoubleCheckedLockingRule) Priority() int          { return 1 }

func (r *DoubleCheckedLockingRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Look for the double-checked locking pattern:
	// if (var == null) {
	//   synchronized(...) {
	//     if (var == null) {
	//       var = new Object();
	//     }
	//   }
	// }

	query := `
	(if_statement
		condition: (parenthesized_expression 
			(binary_expression
				left: (identifier) @outer_var
				operator: "=="
				right: (null_literal)
			)
		)
		consequence: (block
			(synchronized_statement
				body: (block
					(if_statement
						condition: (parenthesized_expression
							(binary_expression
								left: (identifier) @inner_var
								operator: "=="
								right: (null_literal)
							)
						)
						consequence: (block
							(expression_statement
								(assignment_expression
									left: (identifier) @assign_var
									right: (object_creation_expression) @creation
								)
							)
						)
					)
				)
			)
		)
	) @double_check_pattern
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var outerVar, innerVar, assignVar string
		var patternNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "outer_var":
				outerVar = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "inner_var":
				innerVar = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "assign_var":
				assignVar = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "double_check_pattern":
				patternNode = capture.Node
			}
		}

		// Check if all three variables are the same (classic double-checked locking)
		if outerVar == innerVar && innerVar == assignVar && patternNode != nil {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Double checked locking is not thread safe in Java. Partially created objects can be returned when used without 'volatile' keyword. Consider using 'volatile' modifier or initialization-on-demand holder pattern",
				Priority:       r.Priority(),
				BeginLine:      int(patternNode.StartPoint().Row + 1),
				BeginColumn:    int(patternNode.StartPoint().Column + 1),
				EndLine:        int(patternNode.EndPoint().Row + 1),
				EndColumn:      int(patternNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

func (r *DoubleCheckedLockingRule) GetDescription() string {
	return `Partially created objects can be returned by the Double Checked Locking pattern when used in Java.
An optimizing JRE may assign a reference to the baz variable before it calls the constructor of the object the
reference points to.

Note: With Java 5, you can make Double checked locking work, if you declare the variable to be 'volatile'.

For more details refer to: <http://www.javaworld.com/javaworld/jw-02-2001/jw-0209-double.html>
or <http://www.cs.umd.edu/~pugh/java/memoryModel/DoubleCheckedLocking.html>

Example of problematic code:
public class Foo {
    /*volatile */ Object baz = null; // fix for Java5 and later: volatile
    Object bar() {
        if (baz == null) { // baz may be non-null yet not fully created
            synchronized(this) {
                if (baz == null) {
                    baz = new Object();
                }
              }
        }
        return baz;
    }
}

Consider using the initialization-on-demand holder pattern instead.`
}
