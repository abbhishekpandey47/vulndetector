package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type AvoidThreadGroupRule struct{}

func (r *AvoidThreadGroupRule) Rule() string           { return "AvoidThreadGroup" }
func (r *AvoidThreadGroupRule) RuleSet() string        { return "Multithreading" }
func (r *AvoidThreadGroupRule) Classification() string { return "Reliability" }
func (r *AvoidThreadGroupRule) Priority() int          { return 3 }

func (r *AvoidThreadGroupRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for ThreadGroup usage in object creation and method calls
	queries := []string{
		// ThreadGroup constructor calls
		`(object_creation_expression
			type: (type_identifier) @type_name
		) @creation
		`,
		// Method calls that return ThreadGroup
		`(method_invocation
			name: (identifier) @method_name
		) @method_call
		`,
	}

	for _, queryStr := range queries {
		q, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
		if err != nil {
			continue
		}

		cursor := sitter.NewQueryCursor()
		cursor.Exec(q, root)

		for {
			match, ok := cursor.NextMatch()
			if !ok {
				break
			}

			for _, capture := range match.Captures {
				name := q.CaptureNameForId(capture.Index)

				switch name {
				case "type_name":
					typeName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
					if typeName == "ThreadGroup" {
						// Find the creation node for this match
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "creation" {
								issues = append(issues, core.Issue{
									Rule:           r.Rule(),
									RuleSet:        r.RuleSet(),
									Classification: r.Classification(),
									Description:    "Avoid using java.lang.ThreadGroup; it is not thread safe. Although it is intended to be used in a threaded environment, it contains methods that are not thread-safe",
									Priority:       r.Priority(),
									BeginLine:      int(c.Node.StartPoint().Row + 1),
									BeginColumn:    int(c.Node.StartPoint().Column + 1),
									EndLine:        int(c.Node.EndPoint().Row + 1),
									EndColumn:      int(c.Node.EndPoint().Column + 1),
								})
								break
							}
						}
					}
				case "method_name":
					methodName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
					if methodName == "getThreadGroup" {
						// Find the method_call node for this match
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "method_call" {
								issues = append(issues, core.Issue{
									Rule:           r.Rule(),
									RuleSet:        r.RuleSet(),
									Classification: r.Classification(),
									Description:    "Avoid using java.lang.ThreadGroup; it is not thread safe. Method getThreadGroup() returns a ThreadGroup which contains non-thread-safe methods",
									Priority:       r.Priority(),
									BeginLine:      int(c.Node.StartPoint().Row + 1),
									BeginColumn:    int(c.Node.StartPoint().Column + 1),
									EndLine:        int(c.Node.EndPoint().Row + 1),
									EndColumn:      int(c.Node.EndPoint().Column + 1),
								})
								break
							}
						}
					}
				}
			}
		}

		cursor.Close()
		q.Close()
	}

	return issues
}

func (r *AvoidThreadGroupRule) GetDescription() string {
	return `Avoid using java.lang.ThreadGroup; although it is intended to be used in a threaded environment
it contains methods that are not thread-safe.

Example of problematic code:
public class Bar {
    void buz() {
        ThreadGroup tg = new ThreadGroup("My threadgroup");
        tg = new ThreadGroup(tg, "my thread group");
        tg = Thread.currentThread().getThreadGroup();
        tg = System.getSecurityManager().getThreadGroup();
    }
}

Instead, consider using ExecutorService or other thread-safe alternatives from java.util.concurrent package.`
}
