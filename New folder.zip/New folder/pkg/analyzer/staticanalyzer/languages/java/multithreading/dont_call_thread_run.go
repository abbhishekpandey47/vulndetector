package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type DontCallThreadRunRule struct{}

func (r *DontCallThreadRunRule) Rule() string           { return "DontCallThreadRun" }
func (r *DontCallThreadRunRule) RuleSet() string        { return "Multithreading" }
func (r *DontCallThreadRunRule) Classification() string { return "Correctness" }
func (r *DontCallThreadRunRule) Priority() int          { return 4 }

func (r *DontCallThreadRunRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for method invocation of run() on Thread objects
	query := `
	(method_invocation
		name: (identifier) @method_name
	) @method_call
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var methodName string
		var methodCallNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "method_name":
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "method_call":
				methodCallNode = capture.Node
			}
		}

		if methodName == "run" && methodCallNode != nil {
			// Check if this is a Thread.run() call by examining the context
			if r.isThreadRunCall(methodCallNode, source) {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Don't call Thread.run() explicitly, use Thread.start(). Calling run() directly executes in the caller's thread instead of creating a new thread",
					Priority:       r.Priority(),
					BeginLine:      int(methodCallNode.StartPoint().Row + 1),
					BeginColumn:    int(methodCallNode.StartPoint().Column + 1),
					EndLine:        int(methodCallNode.EndPoint().Row + 1),
					EndColumn:      int(methodCallNode.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

func (r *DontCallThreadRunRule) isThreadRunCall(methodCallNode *sitter.Node, source []byte) bool {
	// Check if the method call has an object that could be a Thread
	for i := uint32(0); i < methodCallNode.ChildCount(); i++ {
		child := methodCallNode.Child(int(i))
		if child == nil {
			continue
		}

		// Look for object creation expression with Thread
		if child.Type() == "object_creation_expression" {
			for j := uint32(0); j < child.ChildCount(); j++ {
				grandchild := child.Child(int(j))
				if grandchild != nil && grandchild.Type() == "type_identifier" {
					typeName := string(source[grandchild.StartByte():grandchild.EndByte()])
					if typeName == "Thread" {
						return true
					}
				}
			}
		}

		// Look for variable references (t.run(), thread.run(), etc.)
		if child.Type() == "identifier" {
			// This could be a Thread variable, but we can't be 100% sure without type analysis
			// We'll be permissive and flag any .run() call as potentially problematic
			return true
		}
	}

	return false
}

func (r *DontCallThreadRunRule) GetDescription() string {
	return `Explicitly calling Thread.run() method will execute in the caller's thread of control. Instead, call Thread.start() for the intended behavior.

Examples of problematic code:
Thread t = new Thread();
t.run();            // use t.start() instead
new Thread().run(); // same violation

The run() method should only be called by the thread itself, not by external code. Use start() to create and start a new thread.`
}
