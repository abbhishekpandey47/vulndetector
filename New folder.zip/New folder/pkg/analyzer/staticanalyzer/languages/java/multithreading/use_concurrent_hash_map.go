package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type UseConcurrentHashMapRule struct{}

func (r *UseConcurrentHashMapRule) Rule() string           { return "UseConcurrentHashMap" }
func (r *UseConcurrentHashMapRule) RuleSet() string        { return "Multithreading" }
func (r *UseConcurrentHashMapRule) Classification() string { return "Performance" }
func (r *UseConcurrentHashMapRule) Priority() int          { return 3 }

func (r *UseConcurrentHashMapRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for HashMap object creation and variable declarations
	queries := []string{
		// Object creation with HashMap
		`(object_creation_expression
			type: (type_identifier) @type_name
		) @creation`,
		// Variable declarations with HashMap type
		`(variable_declarator
			name: (identifier) @var_name
		) @var_decl`,
	}

	for _, queryStr := range queries {
		q, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
		if err != nil {
			continue
		}

		cursor := sitter.NewQueryCursor()
		cursor.Exec(q, root)

		for {
			match, ok := cursor.NextMatch()
			if !ok {
				break
			}

			for _, capture := range match.Captures {
				name := q.CaptureNameForId(capture.Index)

				if name == "type_name" {
					typeName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
					if typeName == "HashMap" {
						// Find the creation node for this match
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "creation" {
								issues = append(issues, core.Issue{
									Rule:           r.Rule(),
									RuleSet:        r.RuleSet(),
									Classification: r.Classification(),
									Description:    "If you run in Java5 or newer and have concurrent access, use ConcurrentHashMap instead of HashMap. ConcurrentHashMap allows efficient map reads without blocking other threads",
									Priority:       r.Priority(),
									BeginLine:      int(c.Node.StartPoint().Row + 1),
									BeginColumn:    int(c.Node.StartPoint().Column + 1),
									EndLine:        int(c.Node.EndPoint().Row + 1),
									EndColumn:      int(c.Node.EndPoint().Column + 1),
								})
								break
							}
						}
					}
				}
			}
		}

		cursor.Close()
		q.Close()
	}

	// Also check for HashMap in field declarations and method parameters
	fieldQuery := `
	(field_declaration
		type: (type_identifier) @type_name
	) @field_decl
	`

	q, err := sitter.NewQuery([]byte(fieldQuery), java.GetLanguage())
	if err == nil {
		cursor := sitter.NewQueryCursor()
		cursor.Exec(q, root)

		for {
			match, ok := cursor.NextMatch()
			if !ok {
				break
			}

			for _, capture := range match.Captures {
				name := q.CaptureNameForId(capture.Index)

				if name == "type_name" {
					typeName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
					if typeName == "HashMap" {
						// Find the field_decl node for this match
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "field_decl" {
								issues = append(issues, core.Issue{
									Rule:           r.Rule(),
									RuleSet:        r.RuleSet(),
									Classification: r.Classification(),
									Description:    "Member variable using HashMap detected. If you have concurrent access, use ConcurrentHashMap for better thread safety and performance",
									Priority:       r.Priority(),
									BeginLine:      int(c.Node.StartPoint().Row + 1),
									BeginColumn:    int(c.Node.StartPoint().Column + 1),
									EndLine:        int(c.Node.EndPoint().Row + 1),
									EndColumn:      int(c.Node.EndPoint().Column + 1),
								})
								break
							}
						}
					}
				}
			}
		}

		cursor.Close()
		q.Close()
	}

	return issues
}

func (r *UseConcurrentHashMapRule) GetDescription() string {
	return `Since Java5 brought a new implementation of the Map designed for multi-threaded access, you can
perform efficient map reads without blocking other threads.

Example of the issue:
public class ConcurrentApp {
  public void getMyInstance() {
    Map map1 = new HashMap();           // fine for single-threaded access
    Map map2 = new ConcurrentHashMap(); // preferred for use with multiple threads

    // the following case will be ignored by this rule
    Map map3 = someModule.methodThatReturnMap(); // might be OK, if the returned map is already thread-safe
  }
}

Use ConcurrentHashMap when you expect concurrent access to the map from multiple threads.`
}
