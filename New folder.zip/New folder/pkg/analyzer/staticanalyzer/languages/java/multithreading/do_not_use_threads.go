package multithreading

import (
	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type DoNotUseThreadsRule struct{}

func (r *DoNotUseThreadsRule) Rule() string           { return "DoNotUseThreads" }
func (r *DoNotUseThreadsRule) RuleSet() string        { return "Multithreading" }
func (r *DoNotUseThreadsRule) Classification() string { return "J2EE" }
func (r *DoNotUseThreadsRule) Priority() int          { return 3 }

func (r *DoNotUseThreadsRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for thread-related classes and method calls
	queries := []string{
		// Class extends Thread
		`(class_declaration
			superclass: (superclass (type_identifier) @superclass_name)
		) @class_decl`,
		// Class implements ExecutorService/Executor
		`(class_declaration
			interfaces: (super_interfaces (interface_type_list (type_identifier) @interface_name))
		) @class_decl`,
		// Object creation with Thread/ExecutorService
		`(object_creation_expression
			type: (type_identifier) @type_name
		) @creation`,
		// Method calls to Executors
		`(method_invocation
			object: (identifier) @object_name
			name: (identifier) @method_name
		) @method_call`,
	}

	for _, queryStr := range queries {
		q, err := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
		if err != nil {
			continue
		}

		cursor := sitter.NewQueryCursor()
		cursor.Exec(q, root)

		for {
			match, ok := cursor.NextMatch()
			if !ok {
				break
			}

			for _, capture := range match.Captures {
				name := q.CaptureNameForId(capture.Index)
				text := string(source[capture.Node.StartByte():capture.Node.EndByte()])

				switch name {
				case "superclass_name":
					if text == "Thread" {
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "class_decl" {
								issues = append(issues, r.createIssue(c.Node, "Extending Thread class is not allowed in J2EE applications"))
								break
							}
						}
					}
				case "interface_name":
					if strings.Contains(text, "ExecutorService") || strings.Contains(text, "Executor") {
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "class_decl" {
								issues = append(issues, r.createIssue(c.Node, "Implementing ExecutorService/Executor interface is not allowed in J2EE applications"))
								break
							}
						}
					}
				case "type_name":
					if r.isProhibitedThreadType(text) {
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "creation" {
								issues = append(issues, r.createIssue(c.Node, "Creating "+text+" instances is not allowed in J2EE applications"))
								break
							}
						}
					}
				case "object_name":
					if text == "Executors" {
						for _, c := range match.Captures {
							if q.CaptureNameForId(c.Index) == "method_call" {
								issues = append(issues, r.createIssue(c.Node, "Using Executors utility class is not allowed in J2EE applications"))
								break
							}
						}
					}
				}
			}
		}

		cursor.Close()
		q.Close()
	}

	return issues
}

func (r *DoNotUseThreadsRule) isProhibitedThreadType(typeName string) bool {
	prohibitedTypes := []string{
		"Thread",
		"ExecutorService",
		"ThreadPoolExecutor",
		"ScheduledExecutorService",
		"ScheduledThreadPoolExecutor",
		"ForkJoinPool",
	}

	for _, prohibited := range prohibitedTypes {
		if typeName == prohibited {
			return true
		}
	}
	return false
}

func (r *DoNotUseThreadsRule) createIssue(node *sitter.Node, description string) core.Issue {
	return core.Issue{
		Rule:           r.Rule(),
		RuleSet:        r.RuleSet(),
		Classification: r.Classification(),
		Description:    description + ". J2EE specification forbids the use of threads. Use managed resources provided by the container instead",
		Priority:       r.Priority(),
		BeginLine:      int(node.StartPoint().Row + 1),
		BeginColumn:    int(node.StartPoint().Column + 1),
		EndLine:        int(node.EndPoint().Row + 1),
		EndColumn:      int(node.EndPoint().Column + 1),
	}
}

func (r *DoNotUseThreadsRule) GetDescription() string {
	return `The J2EE specification explicitly forbids the use of threads. Threads are resources, that should be managed and monitored by the J2EE server.
If the application creates threads on its own or uses own custom thread pools, then these threads are not managed, which could lead to resource exhaustion.
Also, EJBs might be moved between machines in a cluster and only managed resources can be moved along.

Examples of violations:
// This is not allowed
public class UsingThread extends Thread {
}

// Neither this,
public class UsingExecutorService {
    public void methodX() {
        ExecutorService executorService = Executors.newFixedThreadPool(5);
    }
}

// Nor this,
public class Example implements ExecutorService {
}

// Nor this
public class UsingExecutors {
    public void methodX() {
        Executors.newSingleThreadExecutor().submit(() -> System.out.println("Hello!"));
    }
}

Use container-managed resources and JCA adapters instead.`
}
