package multithreading

import (
	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type UnsynchronizedStaticFormatterRule struct{}

func (r *UnsynchronizedStaticFormatterRule) Rule() string           { return "UnsynchronizedStaticFormatter" }
func (r *UnsynchronizedStaticFormatterRule) RuleSet() string        { return "Multithreading" }
func (r *UnsynchronizedStaticFormatterRule) Classification() string { return "Reliability" }
func (r *UnsynchronizedStaticFormatterRule) Priority() int          { return 3 }

func (r *UnsynchronizedStaticFormatterRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// First, find static formatter fields
	staticFormatters := r.findStaticFormatters(root, source)

	// Then, find method calls on these formatters that are not synchronized
	for formatterName := range staticFormatters {
		r.findUnsynchronizedFormatterUsage(root, source, formatterName, &issues)
	}

	return issues
}

func (r *UnsynchronizedStaticFormatterRule) findStaticFormatters(root *sitter.Node, source []byte) map[string]bool {
	formatters := make(map[string]bool)

	query := `
	(field_declaration
		(modifiers) @modifiers
		type: (type_identifier) @type_name
		declarator: (variable_declarator
			name: (identifier) @field_name
		)
	) @field_decl
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return formatters
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var modifiersNode *sitter.Node
		var typeName, fieldName string

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "modifiers":
				modifiersNode = capture.Node
			case "type_name":
				typeName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "field_name":
				fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			}
		}

		if modifiersNode != nil && r.isFormatterType(typeName) && r.isStatic(modifiersNode) {
			formatters[fieldName] = true
		}
	}

	return formatters
}

func (r *UnsynchronizedStaticFormatterRule) findUnsynchronizedFormatterUsage(root *sitter.Node, source []byte, formatterName string, issues *[]core.Issue) {
	query := `
	(method_invocation
		object: (identifier) @object_name
		name: (identifier) @method_name
	) @method_call
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var objectName, methodName string
		var methodCallNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "object_name":
				objectName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "method_name":
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "method_call":
				methodCallNode = capture.Node
			}
		}

		if objectName == formatterName && methodCallNode != nil && r.isFormatterMethod(methodName) {
			// Check if this call is within a synchronized block
			if !r.isInSynchronizedBlock(methodCallNode, formatterName, source) {
				*issues = append(*issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Static Formatter objects should be accessed in a synchronized manner. Instances of java.text.Format are generally not synchronized. Use synchronized blocks when accessing static formatters",
					Priority:       r.Priority(),
					BeginLine:      int(methodCallNode.StartPoint().Row + 1),
					BeginColumn:    int(methodCallNode.StartPoint().Column + 1),
					EndLine:        int(methodCallNode.EndPoint().Row + 1),
					EndColumn:      int(methodCallNode.EndPoint().Column + 1),
				})
			}
		}
	}
}

func (r *UnsynchronizedStaticFormatterRule) isFormatterType(typeName string) bool {
	formatterTypes := []string{
		"SimpleDateFormat",
		"DateFormat",
		"NumberFormat",
		"DecimalFormat",
		"MessageFormat",
		"ChoiceFormat",
	}

	for _, formatter := range formatterTypes {
		if strings.Contains(typeName, formatter) {
			return true
		}
	}
	return false
}

func (r *UnsynchronizedStaticFormatterRule) isFormatterMethod(methodName string) bool {
	formatterMethods := []string{
		"format",
		"parse",
		"parseObject",
	}

	for _, method := range formatterMethods {
		if methodName == method {
			return true
		}
	}
	return false
}

func (r *UnsynchronizedStaticFormatterRule) isStatic(modifiersNode *sitter.Node) bool {
	for i := uint32(0); i < modifiersNode.ChildCount(); i++ {
		child := modifiersNode.Child(int(i))
		if child != nil && child.Type() == "static" {
			return true
		}
	}
	return false
}

func (r *UnsynchronizedStaticFormatterRule) isInSynchronizedBlock(node *sitter.Node, formatterName string, source []byte) bool {
	// Walk up the tree to see if we're in a synchronized block
	current := node.Parent()
	for current != nil {
		if current.Type() == "synchronized_statement" {
			// Check if the synchronized block is on the same formatter
			for i := uint32(0); i < current.ChildCount(); i++ {
				child := current.Child(int(i))
				if child != nil && child.Type() == "parenthesized_expression" {
					content := string(source[child.StartByte():child.EndByte()])
					if strings.Contains(content, formatterName) {
						return true
					}
				}
			}
		}
		current = current.Parent()
	}
	return false
}

func (r *UnsynchronizedStaticFormatterRule) GetDescription() string {
	return `Instances of java.text.Format are generally not synchronized.
Sun recommends using separate format instances for each thread.
If multiple threads must access a static formatter, the formatter must be
synchronized on block level.

Example of problematic code:
public class Foo {
    private static final SimpleDateFormat sdf = new SimpleDateFormat();
    void bar() {
        sdf.format(); // poor, no thread-safety
    }
    void foo() {
        synchronized (sdf) { // preferred
            sdf.format();
        }
    }
}

Consider using ThreadLocal for formatters or DateTimeFormatter (thread-safe) from java.time package.`
}
