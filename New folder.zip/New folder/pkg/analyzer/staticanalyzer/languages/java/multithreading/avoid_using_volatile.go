package multithreading

import (
	"fmt"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type AvoidUsingVolatileRule struct{}

func (r *AvoidUsingVolatileRule) Rule() string           { return "AvoidUsingVolatile" }
func (r *AvoidUsingVolatileRule) RuleSet() string        { return "Multithreading" }
func (r *AvoidUsingVolatileRule) Classification() string { return "Maintainability" }
func (r *AvoidUsingVolatileRule) Priority() int          { return 2 }

func (r *AvoidUsingVolatileRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for field declarations with volatile modifier
	query := `
	(field_declaration
		(modifiers) @modifiers
		type: (_)
		declarator: (variable_declarator
			name: (identifier) @field_name
		)
	) @field_decl
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var modifiersNode *sitter.Node
		var fieldName string
		var fieldDeclNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "modifiers":
				modifiersNode = capture.Node
			case "field_name":
				fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "field_decl":
				fieldDeclNode = capture.Node
			}
		}

		if modifiersNode != nil && fieldDeclNode != nil && containsVolatileModifier(modifiersNode, source) {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Avoid using 'volatile' modifier for field '%s'. The volatile keyword requires expertise in Java Memory Model and is not recommended for maintenance and portability purposes", fieldName),
				Priority:       r.Priority(),
				BeginLine:      int(fieldDeclNode.StartPoint().Row + 1),
				BeginColumn:    int(fieldDeclNode.StartPoint().Column + 1),
				EndLine:        int(fieldDeclNode.EndPoint().Row + 1),
				EndColumn:      int(fieldDeclNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

func containsVolatileModifier(modifiersNode *sitter.Node, source []byte) bool {
	for i := uint32(0); i < modifiersNode.ChildCount(); i++ {
		child := modifiersNode.Child(int(i))
		if child != nil && child.Type() == "volatile" {
			return true
		}
	}
	return false
}

func (r *AvoidUsingVolatileRule) GetDescription() string {
	return `Use of modifier volatile is not recommended. Use of the keyword 'volatile' is generally used to fine tune a Java application, and therefore, requires
a good expertise of the Java Memory Model. Moreover, its range of action is somewhat misknown. Therefore,
the volatile keyword should not be used for maintenance purpose and portability.

Example of problematic code:
public class ThrDeux {
  private volatile String var1; // not suggested
  private          String var2; // preferred
}

Consider using higher-level concurrency constructs from java.util.concurrent package instead of volatile for thread-safe operations.`
}
