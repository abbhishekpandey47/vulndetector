package multithreading

import (
	"context"
	"fmt"
	"testing"

	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Sample Java codes for testing each rule
const (
	avoidSynchronizedMethodTestCode = `/**
 * Test file for AvoidSynchronizedAtMethodLevel rule
 * This file demonstrates violations of method-level synchronization
 */
public class TestAvoidSynchronizedAtMethodLevel {
    
    private String sharedData = "initial";
    private static String staticData = "static";
    
    // Violation 1: Synchronized instance method
    synchronized void processData() {
        // code, that doesn't need synchronization
        System.out.println("Processing...");
        
        // code, that requires synchronization
        if (!sharedData.equals("processed")) {
            sharedData = "processed";
        }
        
        // more code, that doesn't need synchronization
        System.out.println("Done processing");
    }
    
    // Violation 2: Synchronized static method
    static synchronized void processStaticData() {
        System.out.println("Processing static data...");
        staticData = "updated";
        System.out.println("Static data processed");
    }
    
    // Violation 3: Public synchronized method
    public synchronized String getData() {
        return sharedData;
    }
    
    // Violation 4: Protected synchronized method
    protected synchronized void setData(String data) {
        this.sharedData = data;
    }
    
    // Acceptable alternatives (no violations)
    void normalMethod() {
        System.out.println("Normal method - no synchronization needed");
    }
    
    void methodWithBlockLevelSync() {
        // code that doesn't need synchronization
        System.out.println("Before sync");
        
        synchronized(this) {
            // only code that needs mutual exclusion
            if (!sharedData.equals("block-processed")) {
                sharedData = "block-processed";
            }
        }
        
        // more code that doesn't need synchronization
        System.out.println("After sync");
    }
}`

	avoidSynchronizedStatementTestCode = `import java.util.concurrent.locks.ReentrantLock;

/**
 * Test file for AvoidSynchronizedStatement rule
 * This file demonstrates violations of synchronized statement blocks
 */
public class TestAvoidSynchronizedStatement {
    
    private String instanceData = "initial";
    private static String staticData = "static";
    private final Object lockObject = new Object();
    
    // Violation 1: Synchronized on this
    void methodWithThisSync() {
        System.out.println("Before sync");
        
        synchronized(this) {  // Violation
            instanceData = "updated";
            System.out.println("Inside sync block");
        }
        
        System.out.println("After sync");
    }
    
    // Violation 2: Synchronized on class
    void methodWithClassSync() {
        System.out.println("Before class sync");
        
        synchronized(TestAvoidSynchronizedStatement.class) {  // Violation
            staticData = "class-updated";
            System.out.println("Inside class sync block");
        }
        
        System.out.println("After class sync");
    }
    
    // Violation 3: Synchronized on custom object
    void methodWithObjectSync() {
        System.out.println("Before object sync");
        
        synchronized(lockObject) {  // Violation
            instanceData = "object-updated";
            System.out.println("Inside object sync block");
        }
        
        System.out.println("After object sync");
    }
    
    // Violation 4: Nested synchronized blocks
    void methodWithNestedSync() {
        synchronized(this) {  // Violation 1
            System.out.println("Outer sync");
            
            synchronized(lockObject) {  // Violation 2
                instanceData = "nested-updated";
                System.out.println("Inner sync");
            }
        }
    }
}`

	avoidThreadGroupTestCode = `import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Test file for AvoidThreadGroup rule  
 * This file demonstrates violations of ThreadGroup usage
 */
public class TestAvoidThreadGroup {
    
    // Violation 1: Creating ThreadGroup with name
    void createThreadGroupWithName() {
        ThreadGroup tg = new ThreadGroup("My threadgroup");  // Violation
        System.out.println("Created thread group: " + tg.getName());
    }
    
    // Violation 2: Creating ThreadGroup with parent and name
    void createThreadGroupWithParent() {
        ThreadGroup parent = new ThreadGroup("Parent");      // Violation 1
        ThreadGroup child = new ThreadGroup(parent, "Child"); // Violation 2
        System.out.println("Parent: " + parent.getName() + ", Child: " + child.getName());
    }
    
    // Violation 3: Getting current thread's ThreadGroup
    void getCurrentThreadGroup() {
        ThreadGroup current = Thread.currentThread().getThreadGroup(); // Violation
        System.out.println("Current thread group: " + current.getName());
    }
}`

	doNotUseThreadsTestCode = `import java.util.concurrent.*;

/**
 * Test file for DoNotUseThreads rule
 * This file demonstrates violations of J2EE thread restrictions
 */

// Violation 1: Extending Thread class
public class TestDoNotUseThreads extends Thread {  // Violation
    
    @Override
    public void run() {
        System.out.println("Thread running: " + Thread.currentThread().getName());
    }
    
    // Violation 2: Creating Thread instances
    void createThreads() {
        Thread t1 = new Thread();                    // Violation
        Thread t2 = new Thread(() -> {               // Violation
            System.out.println("Lambda thread");
        });
        
        t1.start();
        t2.start();
    }
    
    // Violation 3: Creating ExecutorService instances
    void createExecutorServices() {
        ExecutorService executor1 = Executors.newFixedThreadPool(5);     // Violation
        ExecutorService executor2 = Executors.newCachedThreadPool();     // Violation
        ExecutorService executor3 = Executors.newSingleThreadExecutor(); // Violation
        
        executor1.shutdown();
        executor2.shutdown();
        executor3.shutdown();
    }
}

// Violation 4: Implementing ExecutorService interface
class CustomExecutorService implements ExecutorService {  // Violation
    public void shutdown() {}
    public java.util.List<Runnable> shutdownNow() { return null; }
    public boolean isShutdown() { return false; }
    public boolean isTerminated() { return false; }
    public boolean awaitTermination(long timeout, TimeUnit unit) { return false; }
    public <T> java.util.concurrent.Future<T> submit(java.util.concurrent.Callable<T> task) { return null; }
    public <T> java.util.concurrent.Future<T> submit(Runnable task, T result) { return null; }
    public java.util.concurrent.Future<?> submit(Runnable task) { return null; }
    public <T> java.util.List<java.util.concurrent.Future<T>> invokeAll(java.util.Collection<? extends java.util.concurrent.Callable<T>> tasks) { return null; }
    public <T> java.util.List<java.util.concurrent.Future<T>> invokeAll(java.util.Collection<? extends java.util.concurrent.Callable<T>> tasks, long timeout, TimeUnit unit) { return null; }
    public <T> T invokeAny(java.util.Collection<? extends java.util.concurrent.Callable<T>> tasks) { return null; }
    public <T> T invokeAny(java.util.Collection<? extends java.util.concurrent.Callable<T>> tasks, long timeout, TimeUnit unit) { return null; }
    public void execute(Runnable command) {}
}`

	dontCallThreadRunTestCode = `/**
 * Test file for DontCallThreadRun rule
 * This file demonstrates violations of calling Thread.run() instead of Thread.start()
 */
public class TestDontCallThreadRun {
    
    // Violation 1: Calling run() on Thread instance
    void callRunOnThreadInstance() {
        Thread t = new Thread(() -> {
            System.out.println("Thread task executed");
        });
        
        t.run();  // Violation - should use start()
        System.out.println("Called run() instead of start()");
    }
    
    // Violation 2: Calling run() on new Thread directly
    void callRunOnNewThread() {
        new Thread(() -> {
            System.out.println("Direct thread task");
        }).run();  // Violation - should use start()
        
        System.out.println("Called run() on new Thread instance");
    }
    
    // Violation 3: Multiple run() calls
    void multipleRunCalls() {
        Thread t = new Thread(() -> {
            System.out.println("Task execution");
        });
        
        t.run();  // Violation 1
        t.run();  // Violation 2 - can call run() multiple times
        
        System.out.println("Called run() multiple times");
    }
}`

	doubleCheckedLockingTestCode = `/**
 * Test file for DoubleCheckedLocking rule
 * This file demonstrates violations of the double-checked locking pattern
 */
public class TestDoubleCheckedLocking {
    
    // Violation 1: Classic double-checked locking (not thread-safe)
    private Object instance = null;
    
    Object getInstance() {
        if (instance == null) {  // First check
            synchronized(this) {
                if (instance == null) {  // Second check - Violation
                    instance = new Object();
                }
            }
        }
        return instance;
    }
    
    // Violation 2: Double-checked locking with static field
    private static Object staticInstance = null;
    
    static Object getStaticInstance() {
        if (staticInstance == null) {  // First check
            synchronized(TestDoubleCheckedLocking.class) {
                if (staticInstance == null) {  // Second check - Violation
                    staticInstance = new Object();
                }
            }
        }
        return staticInstance;
    }
}`

	nonThreadSafeSingletonTestCode = `/**
 * Test file for NonThreadSafeSingleton rule
 * This file demonstrates violations of non-thread-safe singleton patterns
 */
public class TestNonThreadSafeSingleton {
    
    // Violation 1: Classic non-thread-safe singleton
    private static TestNonThreadSafeSingleton instance = null;
    
    public static TestNonThreadSafeSingleton getInstance() {  // Violation
        if (instance == null) {
            instance = new TestNonThreadSafeSingleton();
        }
        return instance;
    }
    
    // Violation 2: Lazy initialization without synchronization
    private static TestNonThreadSafeSingleton lazyInstance = null;
    
    public static TestNonThreadSafeSingleton getLazyInstance() {  // Violation
        if (lazyInstance == null) {
            System.out.println("Creating lazy instance...");
            lazyInstance = new TestNonThreadSafeSingleton();
        }
        return lazyInstance;
    }
    
    private TestNonThreadSafeSingleton() {}
}

// Violation 3: Another class with non-thread-safe singleton
class AnotherSingleton {
    private static AnotherSingleton instance = null;
    
    public static AnotherSingleton getInstance() {  // Violation
        if (instance == null) {
            instance = new AnotherSingleton();
        }
        return instance;
    }
    
    private AnotherSingleton() {}
}`

	unsynchronizedStaticFormatterTestCode = `import java.text.*;
import java.util.Date;

/**
 * Test file for UnsynchronizedStaticFormatter rule
 * This file demonstrates violations of using static formatters without synchronization
 */
public class TestUnsynchronizedStaticFormatter {
    
    // Violation 1: Static SimpleDateFormat without synchronization
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    void unsafeDateFormatting() {
        Date now = new Date();
        String formatted = sdf.format(now);  // Violation
        System.out.println("Formatted date: " + formatted);
    }
    
    // Violation 2: Static NumberFormat without synchronization
    private static final NumberFormat nf = NumberFormat.getInstance();
    
    void unsafeNumberFormatting() {
        double number = 1234.56;
        String formatted = nf.format(number);  // Violation
        System.out.println("Formatted number: " + formatted);
    }
    
    // Violation 3: Static DecimalFormat without synchronization
    private static final DecimalFormat df = new DecimalFormat("#,##0.00");
    
    void unsafeDecimalFormatting() {
        double value = 9876.543;
        String formatted = df.format(value);  // Violation
        System.out.println("Formatted decimal: " + formatted);
    }
    
    // Safe alternatives (no violations)
    void safeSynchronizedFormatting() {
        Date now = new Date();
        synchronized (sdf) {  // Safe
            String formatted = sdf.format(now);
            System.out.println("Synchronized formatted: " + formatted);
        }
    }
}`

	useConcurrentHashMapTestCode = `import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Test file for UseConcurrentHashMap rule
 * This file demonstrates violations of using HashMap instead of ConcurrentHashMap in concurrent scenarios
 */
public class TestUseConcurrentHashMap {
    
    // Violation 1: HashMap field declaration
    private HashMap<String, String> userMap;  // Violation
    
    // Violation 2: Static HashMap field
    private static HashMap<String, Object> staticDataMap;  // Violation
    
    // Violation 3: HashMap with type parameters
    private HashMap<Integer, String> integerMap = new HashMap<>();  // Violation
    
    // Safe alternatives (no violations)
    private ConcurrentHashMap<String, String> safeUserMap;  // Safe
    
    // Constructor with violations
    public TestUseConcurrentHashMap() {
        // Violation 4: HashMap object creation
        this.userMap = new HashMap<>();  // Violation
        
        // Safe alternatives
        this.safeUserMap = new ConcurrentHashMap<>();  // Safe
    }
    
    // Method with violations
    void processData() {
        // Violation 5: Local HashMap variable
        Map localMap = new HashMap();  // Violation
        
        // Violation 6: HashMap in method body
        HashMap<String, List<String>> groupMap = new HashMap<>();  // Violation
        
        // Safe alternatives
        Map safeLocalMap = new ConcurrentHashMap();  // Safe
    }
}`

	useNotifyAllTestCode = `/**
 * Test file for UseNotifyAllInsteadOfNotify rule
 * This file demonstrates violations of using notify() instead of notifyAll()
 */
public class TestUseNotifyAllInsteadOfNotify {
    
    private final Object lockObject = new Object();
    private final Object sharedResource = new Object();
    private boolean condition = false;
    private String data = null;
    
    // Violation 1: Basic notify() usage
    void basicNotifyViolation() {
        synchronized(lockObject) {
            condition = true;
            lockObject.notify();  // Violation - should use notifyAll()
        }
    }
    
    // Violation 2: notify() in producer-consumer scenario
    void producerNotifyViolation() {
        synchronized(sharedResource) {
            // Produce some data
            data = "produced data";
            
            // Wake up ONE waiting consumer (problematic if multiple consumers)
            sharedResource.notify();  // Violation
        }
    }
    
    // Violation 3: Multiple notify() calls (each call is a violation)
    void multipleNotifyCalls() {
        synchronized(lockObject) {
            condition = true;
            lockObject.notify();  // Violation 1
        }
        
        // Later in another synchronized block
        synchronized(sharedResource) {
            data = "updated";
            sharedResource.notify();  // Violation 2
        }
    }
    
    // Safe alternatives (no violations)
    void correctNotifyAllUsage() {
        synchronized(lockObject) {
            condition = true;
            lockObject.notifyAll();  // Correct - wakes up all waiting threads
        }
    }
}`
)

func TestAvoidUsingVolatileRule(t *testing.T) {
	rule := &AvoidUsingVolatileRule{}

	// Test basic rule properties
	assert.Equal(t, "AvoidUsingVolatile", rule.Rule())
	assert.Equal(t, "Multithreading", rule.RuleSet())
	assert.Equal(t, "Maintainability", rule.Classification())
	assert.Equal(t, 2, rule.Priority())

	tests := []struct {
		name           string
		javaCode       string
		expectedIssues int
		expectedFields []string
	}{
		{
			name: "Single private volatile field",
			javaCode: `
public class Test {
    private volatile String var1;
}`,
			expectedIssues: 1,
			expectedFields: []string{"var1"},
		},
		{
			name: "Multiple volatile fields with different modifiers",
			javaCode: `
public class Test {
    private volatile String var1;
    public volatile int counter;
    protected volatile boolean flag;
    volatile double value;
    private static volatile long timestamp;
}`,
			expectedIssues: 5,
			expectedFields: []string{"var1", "counter", "flag", "value", "timestamp"},
		},
		{
			name: "ThrDeux example from specification",
			javaCode: `
public class ThrDeux {
    private volatile String var1; // not suggested
    private          String var2; // preferred
}`,
			expectedIssues: 1,
			expectedFields: []string{"var1"},
		},
		{
			name: "Complex modifiers with volatile",
			javaCode: `
public class Test {
    public final volatile Object complexField;
    private static final volatile String config;
}`,
			expectedIssues: 2,
			expectedFields: []string{"complexField", "config"},
		},
		{
			name: "No volatile fields",
			javaCode: `
public class Test {
    private String var2;
    public int normalCounter;
    protected boolean normalFlag;
    double normalValue;
    private static long normalTime;
}`,
			expectedIssues: 0,
			expectedFields: []string{},
		},
		{
			name: "Mixed volatile and non-volatile fields",
			javaCode: `
public class Test {
    private volatile String volatileField;
    private String normalField;
    public volatile int volatileCounter;
    public int normalCounter;
}`,
			expectedIssues: 2,
			expectedFields: []string{"volatileField", "volatileCounter"},
		},
		{
			name: "Nested class with volatile fields",
			javaCode: `
public class Outer {
    private volatile String outerField;
    
    public static class Inner {
        private volatile int innerField;
    }
}`,
			expectedIssues: 2,
			expectedFields: []string{"outerField", "innerField"},
		},
		{
			name: "Complete test case from specification",
			javaCode: `
public class TestAvoidUsingVolatile {
    
    // These will violate the AvoidUsingVolatile rule
    private volatile String var1;           // Violation 1
    public volatile int counter;            // Violation 2
    protected volatile boolean flag;        // Violation 3
    volatile double value;                  // Violation 4
    private static volatile long timestamp; // Violation 5
    
    // These are acceptable (no volatile modifier)
    private String var2;              // OK
    public int normalCounter;         // OK
    protected boolean normalFlag;     // OK
    double normalValue;               // OK
    private static long normalTime;   // OK
    
    // Example class from the original description
    public static class ThrDeux {
        private volatile String var1; // not suggested - Violation 6
        private          String var2; // preferred - OK
    }
    
    // More complex example with multiple modifiers
    public final volatile Object complexField; // Violation 7
}`,
			expectedIssues: 7,
			expectedFields: []string{"var1", "counter", "flag", "value", "timestamp", "var1", "complexField"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Parse the Java code
			parser := sitter.NewParser()
			parser.SetLanguage(java.GetLanguage())

			tree, err := parser.ParseCtx(context.Background(), nil, []byte(tt.javaCode))
			require.NoError(t, err, "Failed to parse Java code")
			require.NotNil(t, tree, "Parse tree should not be nil")

			// Analyze with the rule
			issues := rule.Analyze(tree, []byte(tt.javaCode), nil)

			// Verify number of issues
			assert.Equal(t, tt.expectedIssues, len(issues), "Expected %d issues, got %d", tt.expectedIssues, len(issues))

			// Verify issue details
			if tt.expectedIssues > 0 {
				for _, issue := range issues {
					assert.Equal(t, "AvoidUsingVolatile", issue.Rule)
					assert.Equal(t, "Multithreading", issue.RuleSet)
					assert.Equal(t, "Maintainability", issue.Classification)
					assert.Equal(t, 2, issue.Priority)
					assert.Contains(t, issue.Description, "Avoid using 'volatile' modifier")
					assert.Contains(t, issue.Description, "Java Memory Model")
					assert.Contains(t, issue.Description, "maintenance and portability")
					assert.Greater(t, issue.BeginLine, 0)
					assert.Greater(t, issue.BeginColumn, 0)
					assert.Greater(t, issue.EndLine, 0)
					assert.Greater(t, issue.EndColumn, 0)
				}

				// For simple cases, verify field names are mentioned
				if len(tt.expectedFields) == 1 {
					assert.Contains(t, issues[0].Description, tt.expectedFields[0])
				}
			}
		})
	}
}

func TestAvoidUsingVolatileRule_GetDescription(t *testing.T) {
	rule := &AvoidUsingVolatileRule{}
	description := rule.GetDescription()

	assert.Contains(t, description, "volatile is not recommended")
	assert.Contains(t, description, "Java Memory Model")
	assert.Contains(t, description, "maintenance purpose and portability")
	assert.Contains(t, description, "ThrDeux")
	assert.Contains(t, description, "java.util.concurrent")
	assert.Contains(t, description, "private volatile String var1; // not suggested")
	assert.Contains(t, description, "private          String var2; // preferred")
}

func TestContainsVolatileModifier(t *testing.T) {
	tests := []struct {
		name     string
		javaCode string
		expected bool
	}{
		{
			name: "Contains volatile modifier",
			javaCode: `
public class Test {
    private volatile String field;
}`,
			expected: true,
		},
		{
			name: "Does not contain volatile modifier",
			javaCode: `
public class Test {
    private String field;
}`,
			expected: false,
		},
		{
			name: "Multiple modifiers including volatile",
			javaCode: `
public class Test {
    public static final volatile String field;
}`,
			expected: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			parser := sitter.NewParser()
			parser.SetLanguage(java.GetLanguage())

			tree, err := parser.ParseCtx(context.Background(), nil, []byte(tt.javaCode))
			require.NoError(t, err)

			// Find the modifiers node
			root := tree.RootNode()
			var modifiersNode *sitter.Node

			// Walk through the tree to find field_declaration -> modifiers
			var findModifiers func(*sitter.Node)
			findModifiers = func(node *sitter.Node) {
				if node.Type() == "field_declaration" {
					for i := uint32(0); i < node.ChildCount(); i++ {
						child := node.Child(int(i))
						if child != nil && child.Type() == "modifiers" {
							modifiersNode = child
							return
						}
					}
				}
				for i := uint32(0); i < node.ChildCount(); i++ {
					findModifiers(node.Child(int(i)))
				}
			}

			findModifiers(root)

			if modifiersNode != nil {
				result := containsVolatileModifier(modifiersNode, []byte(tt.javaCode))
				assert.Equal(t, tt.expected, result)
			} else if tt.expected {
				t.Errorf("Expected to find modifiers node but didn't")
			}
		})
	}
}

func TestAvoidUsingVolatileRule_ErrorHandling(t *testing.T) {
	rule := &AvoidUsingVolatileRule{}

	// Test with nil AST
	issues := rule.Analyze(nil, []byte("some code"), nil)
	assert.Empty(t, issues)

	// Test with empty but valid tree
	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	emptyCode := ""
	tree, err := parser.ParseCtx(context.Background(), nil, []byte(emptyCode))
	require.NoError(t, err)

	issues = rule.Analyze(tree, []byte(emptyCode), nil)
	assert.Empty(t, issues)

	// Test with invalid Java code (should not crash)
	invalidCode := "this is not valid java code {"
	tree, err = parser.ParseCtx(context.Background(), nil, []byte(invalidCode))
	require.NoError(t, err) // Tree-sitter is resilient to syntax errors

	issues = rule.Analyze(tree, []byte(invalidCode), nil)
	assert.Empty(t, issues) // Should not find any volatile fields in invalid code
}

func TestAvoidSynchronizedAtMethodLevelRule(t *testing.T) {
	rule := &AvoidSynchronizedAtMethodLevelRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(avoidSynchronizedMethodTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(avoidSynchronizedMethodTestCode), nil)
	assert.Equal(t, 4, len(issues)) // Updated: processData, processStaticData, getData, setData

	for _, issue := range issues {
		assert.Equal(t, "AvoidSynchronizedAtMethodLevel", issue.Rule)
		assert.Contains(t, issue.Description, "block level locking")
	}
}

func TestAvoidSynchronizedStatementRule(t *testing.T) {
	rule := &AvoidSynchronizedStatementRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(avoidSynchronizedStatementTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(avoidSynchronizedStatementTestCode), nil)
	assert.Equal(t, 5, len(issues)) // Updated: methodWithThisSync, methodWithClassSync, methodWithObjectSync, methodWithNestedSync (2 blocks)

	for _, issue := range issues {
		assert.Equal(t, "AvoidSynchronizedStatement", issue.Rule)
		assert.Contains(t, issue.Description, "ReentrantLock")
	}
}

func TestAvoidThreadGroupRule(t *testing.T) {
	rule := &AvoidThreadGroupRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(avoidThreadGroupTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(avoidThreadGroupTestCode), nil)
	assert.GreaterOrEqual(t, len(issues), 2) // ThreadGroup constructor calls

	for _, issue := range issues {
		assert.Equal(t, "AvoidThreadGroup", issue.Rule)
		assert.Contains(t, issue.Description, "not thread safe")
	}
}

func TestDoNotUseThreadsRule(t *testing.T) {
	rule := &DoNotUseThreadsRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(doNotUseThreadsTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(doNotUseThreadsTestCode), nil)
	assert.GreaterOrEqual(t, len(issues), 3) // Thread extension, ExecutorService creation, Executors call

	for _, issue := range issues {
		assert.Equal(t, "DoNotUseThreads", issue.Rule)
		assert.Contains(t, issue.Description, "J2EE")
	}
}

func TestDontCallThreadRunRule(t *testing.T) {
	rule := &DontCallThreadRunRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(dontCallThreadRunTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(dontCallThreadRunTestCode), nil)
	assert.GreaterOrEqual(t, len(issues), 2) // two run() calls

	for _, issue := range issues {
		assert.Equal(t, "DontCallThreadRun", issue.Rule)
		assert.Contains(t, issue.Description, "Thread.start()")
	}
}

func TestDoubleCheckedLockingRule(t *testing.T) {
	rule := &DoubleCheckedLockingRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(doubleCheckedLockingTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(doubleCheckedLockingTestCode), nil)
	assert.GreaterOrEqual(t, len(issues), 1) // double-checked locking pattern

	for _, issue := range issues {
		assert.Equal(t, "DoubleCheckedLocking", issue.Rule)
		assert.Contains(t, issue.Description, "not thread safe")
	}
}

func TestNonThreadSafeSingletonRule(t *testing.T) {
	rule := &NonThreadSafeSingletonRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(nonThreadSafeSingletonTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(nonThreadSafeSingletonTestCode), nil)
	assert.Equal(t, 2, len(issues)) // Updated: Only detects getInstance and getLazyInstance methods, not AnotherSingleton.getInstance

	for _, issue := range issues {
		assert.Equal(t, "NonThreadSafeSingleton", issue.Rule)
		assert.Contains(t, issue.Description, "not thread safe")
	}
}

func TestUnsynchronizedStaticFormatterRule(t *testing.T) {
	rule := &UnsynchronizedStaticFormatterRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(unsynchronizedStaticFormatterTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(unsynchronizedStaticFormatterTestCode), nil)
	assert.GreaterOrEqual(t, len(issues), 1) // unsynchronized sdf.format()

	for _, issue := range issues {
		assert.Equal(t, "UnsynchronizedStaticFormatter", issue.Rule)
		assert.Contains(t, issue.Description, "synchronized manner")
	}
}

func TestUseConcurrentHashMapRule(t *testing.T) {
	rule := &UseConcurrentHashMapRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(useConcurrentHashMapTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(useConcurrentHashMapTestCode), nil)
	assert.GreaterOrEqual(t, len(issues), 1) // HashMap usage

	for _, issue := range issues {
		assert.Equal(t, "UseConcurrentHashMap", issue.Rule)
		assert.Contains(t, issue.Description, "ConcurrentHashMap")
	}
}

func TestUseNotifyAllInsteadOfNotifyRule(t *testing.T) {
	rule := &UseNotifyAllInsteadOfNotifyRule{}

	parser := sitter.NewParser()
	parser.SetLanguage(java.GetLanguage())

	tree, err := parser.ParseCtx(context.Background(), nil, []byte(useNotifyAllTestCode))
	require.NoError(t, err)

	issues := rule.Analyze(tree, []byte(useNotifyAllTestCode), nil)
	assert.Equal(t, 4, len(issues)) // Updated: basicNotifyViolation, producerNotifyViolation, multipleNotifyCalls (2 calls)

	for _, issue := range issues {
		assert.Equal(t, "UseNotifyAllInsteadOfNotify", issue.Rule)
		assert.Contains(t, issue.Description, "notifyAll")
	}
}

// Test rule properties for all rules
func TestAllRuleProperties(t *testing.T) {
	rules := []struct {
		rule interface {
			Rule() string
			RuleSet() string
			Classification() string
			Priority() int
		}
		expectedRule    string
		expectedRuleSet string
	}{
		{&AvoidUsingVolatileRule{}, "AvoidUsingVolatile", "Multithreading"},
		{&AvoidSynchronizedAtMethodLevelRule{}, "AvoidSynchronizedAtMethodLevel", "Multithreading"},
		{&AvoidSynchronizedStatementRule{}, "AvoidSynchronizedStatement", "Multithreading"},
		{&AvoidThreadGroupRule{}, "AvoidThreadGroup", "Multithreading"},
		{&DoNotUseThreadsRule{}, "DoNotUseThreads", "Multithreading"},
		{&DontCallThreadRunRule{}, "DontCallThreadRun", "Multithreading"},
		{&DoubleCheckedLockingRule{}, "DoubleCheckedLocking", "Multithreading"},
		{&NonThreadSafeSingletonRule{}, "NonThreadSafeSingleton", "Multithreading"},
		{&UnsynchronizedStaticFormatterRule{}, "UnsynchronizedStaticFormatter", "Multithreading"},
		{&UseConcurrentHashMapRule{}, "UseConcurrentHashMap", "Multithreading"},
		{&UseNotifyAllInsteadOfNotifyRule{}, "UseNotifyAllInsteadOfNotify", "Multithreading"},
	}

	for _, test := range rules {
		t.Run(test.expectedRule, func(t *testing.T) {
			assert.Equal(t, test.expectedRule, test.rule.Rule())
			assert.Equal(t, test.expectedRuleSet, test.rule.RuleSet())
			assert.Greater(t, test.rule.Priority(), 0)
			assert.NotEmpty(t, test.rule.Classification())
		})
	}
}

// Test GetDescription methods
func TestRuleDescriptions(t *testing.T) {
	rules := []interface{ GetDescription() string }{
		&AvoidUsingVolatileRule{},
		&AvoidSynchronizedAtMethodLevelRule{},
		&AvoidSynchronizedStatementRule{},
		&AvoidThreadGroupRule{},
		&DoNotUseThreadsRule{},
		&DontCallThreadRunRule{},
		&DoubleCheckedLockingRule{},
		&NonThreadSafeSingletonRule{},
		&UnsynchronizedStaticFormatterRule{},
		&UseConcurrentHashMapRule{},
		&UseNotifyAllInsteadOfNotifyRule{},
	}

	for i, rule := range rules {
		t.Run(fmt.Sprintf("Rule_%d", i), func(t *testing.T) {
			description := rule.GetDescription()
			assert.NotEmpty(t, description)
			assert.Greater(t, len(description), 50) // Ensure meaningful descriptions
		})
	}
}
