package multithreading

import (
	"fmt"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type AvoidSynchronizedAtMethodLevelRule struct{}

func (r *AvoidSynchronizedAtMethodLevelRule) Rule() string           { return "AvoidSynchronizedAtMethodLevel" }
func (r *AvoidSynchronizedAtMethodLevelRule) RuleSet() string        { return "Multithreading" }
func (r *AvoidSynchronizedAtMethodLevelRule) Classification() string { return "Performance" }
func (r *AvoidSynchronizedAtMethodLevelRule) Priority() int          { return 3 }

func (r *AvoidSynchronizedAtMethodLevelRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Query for synchronized methods
	query := `
	(method_declaration
		(modifiers) @modifiers
		name: (identifier) @method_name
	) @method_decl
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var modifiersNode *sitter.Node
		var methodName string
		var methodDeclNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "modifiers":
				modifiersNode = capture.Node
			case "method_name":
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "method_decl":
				methodDeclNode = capture.Node
			}
		}

		if modifiersNode != nil && methodDeclNode != nil && containsSynchronizedModifier(modifiersNode, source) {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Use block level locking rather than method level synchronization for method '%s'. Method-level synchronization can pin virtual threads and cause performance problems", methodName),
				Priority:       r.Priority(),
				BeginLine:      int(methodDeclNode.StartPoint().Row + 1),
				BeginColumn:    int(methodDeclNode.StartPoint().Column + 1),
				EndLine:        int(methodDeclNode.EndPoint().Row + 1),
				EndColumn:      int(methodDeclNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

func containsSynchronizedModifier(modifiersNode *sitter.Node, source []byte) bool {
	for i := uint32(0); i < modifiersNode.ChildCount(); i++ {
		child := modifiersNode.Child(int(i))
		if child != nil && child.Type() == "synchronized" {
			return true
		}
	}
	return false
}

func (r *AvoidSynchronizedAtMethodLevelRule) GetDescription() string {
	return `Method-level synchronization will pin virtual threads and can cause performance problems. Additionally, it can cause
problems when new code is added to the method. Block-level ReentrantLock helps to ensure that only the code that
needs mutual exclusion will be locked.

Example of problematic code:
// Try to avoid this:
synchronized void foo() {
    // code, that doesn't need synchronization
    // ...
    // code, that requires synchronization
    if (!sharedData.has("bar")) {
        sharedData.add("bar");
    }
    // more code, that doesn't need synchronization
    // ...
}

// Try to avoid this for static methods:
static synchronized void fooStatic() {
}

Prefer using ReentrantLock with try-finally blocks for better control over the synchronization scope.`
}
