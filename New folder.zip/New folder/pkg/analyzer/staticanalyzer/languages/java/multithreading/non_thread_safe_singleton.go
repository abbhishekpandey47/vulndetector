package multithreading

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

type NonThreadSafeSingletonRule struct{}

func (r *NonThreadSafeSingletonRule) Rule() string           { return "NonThreadSafeSingleton" }
func (r *NonThreadSafeSingletonRule) RuleSet() string        { return "Multithreading" }
func (r *NonThreadSafeSingletonRule) Classification() string { return "Reliability" }
func (r *NonThreadSafeSingletonRule) Priority() int          { return 3 }

func (r *NonThreadSafeSingletonRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue

	if rawAST == nil {
		return issues
	}

	tree := rawAST.(*sitter.Tree)
	if tree == nil {
		return issues
	}

	root := tree.RootNode()

	// Look for singleton pattern: static field + getInstance method without synchronization
	// Pattern: private static Foo instance = null; public static Foo getInstance() { if (instance == null) instance = new Foo(); return instance; }

	query := `
	(method_declaration
		(modifiers) @modifiers
		name: (identifier) @method_name
		body: (block
			(if_statement
				condition: (parenthesized_expression
					(binary_expression
						left: (identifier) @check_var
						operator: "=="
						right: (null_literal)
					)
				)
				consequence: (block
					(expression_statement
						(assignment_expression
							left: (identifier) @assign_var
							right: (object_creation_expression)
						)
					)
				)
			)
		)
	) @method_decl
	`

	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var methodName, checkVar, assignVar string
		var modifiersNode, methodDeclNode *sitter.Node

		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			switch name {
			case "modifiers":
				modifiersNode = capture.Node
			case "method_name":
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "check_var":
				checkVar = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "assign_var":
				assignVar = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "method_decl":
				methodDeclNode = capture.Node
			}
		}

		// Check if this looks like a singleton pattern
		if methodName == "getInstance" && checkVar == assignVar && modifiersNode != nil && methodDeclNode != nil {
			isStatic := r.containsModifier(modifiersNode, "static")
			isPublic := r.containsModifier(modifiersNode, "public")
			isSynchronized := r.containsModifier(modifiersNode, "synchronized")

			if isStatic && isPublic && !isSynchronized {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Singleton is not thread safe. Non-thread safe singletons can result in bad state changes. Consider synchronizing the method, using initialization-on-demand holder class, or eliminating static singletons",
					Priority:       r.Priority(),
					BeginLine:      int(methodDeclNode.StartPoint().Row + 1),
					BeginColumn:    int(methodDeclNode.StartPoint().Column + 1),
					EndLine:        int(methodDeclNode.EndPoint().Row + 1),
					EndColumn:      int(methodDeclNode.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

func (r *NonThreadSafeSingletonRule) containsModifier(modifiersNode *sitter.Node, modifier string) bool {
	for i := uint32(0); i < modifiersNode.ChildCount(); i++ {
		child := modifiersNode.Child(int(i))
		if child != nil && child.Type() == modifier {
			return true
		}
	}
	return false
}

func (r *NonThreadSafeSingletonRule) GetDescription() string {
	return `Non-thread safe singletons can result in bad state changes. Eliminate
static singletons if possible by instantiating the object directly. Static
singletons are usually not needed as only a single instance exists anyway.
Other possible fixes are to synchronize the entire method or to use an
[initialize-on-demand holder class](https://en.wikipedia.org/wiki/Initialization-on-demand_holder_idiom).

Refrain from using the double-checked locking pattern. The Java Memory Model doesn't
guarantee it to work unless the variable is declared as 'volatile', adding an uneeded
performance penalty. [Reference](http://www.cs.umd.edu/~pugh/java/memoryModel/DoubleCheckedLocking.html)

See Effective Java, item 48.

Example of problematic code:
private static Foo foo = null;

//multiple simultaneous callers may see partially initialized objects
public static Foo getFoo() {
    if (foo==null) {
        foo = new Foo();
    }
    return foo;
}

Better alternatives:
1. Synchronize the method: public synchronized static Foo getFoo()
2. Use initialization-on-demand holder pattern
3. Use enum singleton pattern`
}
