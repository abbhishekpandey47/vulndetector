package java

import (
	"fmt"
	"log"
	"path/filepath"

	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"

	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/java"
)

func ClassificationRuleSetJava(ruleSet string) string {
	switch ruleSet {
	case "Vulnerability":
		return "Security"
	case "Stability":
		return "Maintainability"
	case "Efficiency":
		return "Performance"
	case "Structure":
		return "Maintainability"
	case "Conventions":
		return "Compliance"
	case "Concurrency":
		return "Performance"
	case "Style":
		return "Maintainability"
	case "Comments":
		return "Compliance"
	default:
		return ""
	}
}

type UnusedImportsRule struct{}

func (r *UnusedImportsRule) Rule() string    { return "UnnecessaryImport" }
func (r *UnusedImportsRule) RuleSet() string { return "Style" }
func (r *UnusedImportsRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}
func (r *UnusedImportsRule) Priority() int { return 4 }
func (r *UnusedImportsRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	// Capture explicit imports (excluding wildcards)
	importQuery := `
	(import_declaration 
		(scoped_identifier 
			(identifier)* 
			(identifier) @class_name
		)
			
			
	) @import
	`
	qImports, _ := sitter.NewQuery([]byte(importQuery), java.GetLanguage())
	defer qImports.Close()

	cursorImports := sitter.NewQueryCursor()
	defer cursorImports.Close()
	cursorImports.Exec(qImports, root)

	// Track imported class names and their nodes
	imports := make(map[string][]*sitter.Node)
	for {
		match, ok := cursorImports.NextMatch()
		if !ok {
			break
		}
		var className string
		var importNode *sitter.Node
		for _, cap := range match.Captures {
			name := qImports.CaptureNameForId(cap.Index)
			switch name {
			case "class_name":
				start := cap.Node.StartByte()
				end := cap.Node.EndByte()
				className = string(source[start:end])
			case "import":
				importNode = cap.Node
			}
		}
		if className != "" && importNode != nil {
			imports[className] = append(imports[className], importNode)
		}
	}

	// Capture all used identifiers (excluding imports)
	usedIdentQuery := `
	(type_identifier) @ident
	(#not-parent? @ident import_declaration)
	`
	qUsedIdents, _ := sitter.NewQuery([]byte(usedIdentQuery), java.GetLanguage())
	defer qUsedIdents.Close()

	cursorUsedIdents := sitter.NewQueryCursor()
	defer cursorUsedIdents.Close()
	cursorUsedIdents.Exec(qUsedIdents, root)

	// Track used identifiers
	usedIdents := make(map[string]bool)
	for {
		match, ok := cursorUsedIdents.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := qImports.CaptureNameForId(cap.Index)
			if name == "ident" {
				start := cap.Node.StartByte()
				end := cap.Node.EndByte()
				identName := string(source[start:end])
				usedIdents[identName] = true
			} else if name == "class_name" {
				start := cap.Node.StartByte()
				end := cap.Node.EndByte()
				identName := string(source[start:end])
				usedIdents[identName] = true
			}
		}
	}

	// Report unused imports
	for className, nodes := range imports {

		if !usedIdents[className] {
			for _, node := range nodes {
				// pos := sitter.Point{
				// 	Row:    node.StartPoint().Row + 1,
				// 	Column: node.StartPoint().Column,
				// }
				issues = append(issues, core.Issue{
					// RuleID:      r.ID(),
					// Message:     fmt.Sprintf("Unused import: %s", className),
					// Severity:    r.Severity(),
					// Line:        int(pos.Row),
					// Column:      int(pos.Column),
					// FilePath:    "", // Populate from context
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    fmt.Sprintf("Unused import: %s", className),
					Priority:       r.Priority(),
					BeginLine:      int(node.StartPoint().Row + 1),
					BeginColumn:    int(node.StartPoint().Column + 1),
					EndLine:        int(node.EndPoint().Row + 1),
					EndColumn:      int(node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type DuplicateFunctionName struct{}

func (r *DuplicateFunctionName) Rule() string    { return "DuplicateFunction" }
func (r *DuplicateFunctionName) RuleSet() string { return "Stability" }
func (r *DuplicateFunctionName) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *DuplicateFunctionName) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue
	codeBlocks := make(map[string][]*sitter.Node)
	codeInfo := make(map[string]bool)

	// Query to get the function Name
	query := `
        (
        (method_declaration
            name: (identifier) @function_name
            
        )
    )
    `
	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		log.Fatalf("Error compiling query: %v", err)
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		// Ensure we're capturing the correct node
		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			if name == "function_name" {
				codeText := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if key := codeInfo[codeText]; key {
					codeBlocks[codeText] = append(codeBlocks[codeText], capture.Node)

				}
				codeInfo[codeText] = true

			} else if name == "code_statement" {
				codeText := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if key := codeInfo[codeText]; key {
					codeBlocks[codeText] = append(codeBlocks[codeText], capture.Node)

				}
				codeInfo[codeText] = true

			}
		}
	}
	for code, nodes := range codeBlocks {
		for _, node := range nodes {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Duplicate Function Name detected: %s", code),
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row) + 1,
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Duplicate Function Name detected: %s", code),
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}

	}
	return issues
}

type DuplicateCodeBlockRule struct{}

func (r *DuplicateCodeBlockRule) Rule() string    { return "DuplicateCodeBlock" }
func (r *DuplicateCodeBlockRule) RuleSet() string { return "Structure" }
func (r *DuplicateCodeBlockRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *DuplicateCodeBlockRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue
	codeBlocks := make(map[string][]*sitter.Node)
	codeInfo := make(map[string]bool)

	// Query to get the function Name
	query := `
        (
        (method_declaration
            
            body: (block)@code_statement
      
        )
    )
    `
	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		log.Fatalf("Error compiling query: %v", err)
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		// Ensure we're capturing the correct node
		for _, capture := range match.Captures {
			name := q.CaptureNameForId(capture.Index)
			if name == "function_name" {
				codeText := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if key := codeInfo[codeText]; key {
					codeBlocks[codeText] = append(codeBlocks[codeText], capture.Node)

				}
				codeInfo[codeText] = true

			} else if name == "code_statement" {
				codeText := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if key := codeInfo[codeText]; key {
					codeBlocks[codeText] = append(codeBlocks[codeText], capture.Node)

				}
				codeInfo[codeText] = true

			}
		}
	}
	for code, nodes := range codeBlocks {
		for _, node := range nodes {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Duplicate Code Block detected: %s", code),
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row) + 1,
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Duplicate Code Block detected: %s", code),
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}

	}
	return issues
}

type HardCodedCredentialsRule struct{}

func (r *HardCodedCredentialsRule) Rule() string    { return "HardCodedCredentials" }
func (r *HardCodedCredentialsRule) RuleSet() string { return "Vulnerability" }
func (r *HardCodedCredentialsRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *HardCodedCredentialsRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (
        (string_literal) @credential
    )
    `
	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		fmt.Println(err)
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		credential := string(source[match.Captures[0].Node.StartByte():match.Captures[0].Node.EndByte()])
		if isCredential(credential) {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Hardcoded credential detected: %s", credential),
				// Severity:    r.Severity(),
				// Line:        int(match.Captures[0].Node.StartPoint().Row) + 1,
				// Column:      int(match.Captures[0].Node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Hardcoded credential detected: %s", credential),
				BeginLine:      int(match.Captures[0].Node.StartPoint().Row) + 1,
				BeginColumn:    int(match.Captures[0].Node.StartPoint().Column),
				EndLine:        int(match.Captures[0].Node.EndPoint().Row) + 1,
				EndColumn:      int(match.Captures[0].Node.EndPoint().Column),
			})
		}
	}
	return issues
}

func isCredential(value string) bool {
	// Basic check for common credential patterns
	lower := strings.ToLower(value)
	return strings.Contains(lower, "password") ||
		strings.Contains(lower, "apiKey") ||
		strings.Contains(lower, "secret") ||
		strings.Contains(lower, "token") ||
		len(value) > 10 && strings.ContainsAny(value, "0123456789") // crude entropy check

}

type MissingJavadocCommentRule struct{}

func (r *MissingJavadocCommentRule) Rule() string    { return "CommentRequired" }
func (r *MissingJavadocCommentRule) RuleSet() string { return "Comments" }
func (r *MissingJavadocCommentRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *MissingJavadocCommentRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (
        (class_declaration
            (name: (identifier) @class_name)
            (class_body
                (class_body_declaration
                    (method_declaration
                        (method_header
                            (method_modifier)* 
                            (type) @method_return_type
                            (identifier) @method_name
                        )
                        (method_body
                            (block) @method_body
                        )
                    )
                )
            )
        )
    )
    `
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := q.CaptureNameForId(cap.Index)
			if name == "method_name" {
				start := cap.Node.StartByte()
				end := cap.Node.EndByte()
				methodName := string(source[start:end])
				if !hasJavadocComment(source, int(start), int(end)) {
					issues = append(issues, core.Issue{
						// RuleID:      r.ID(),
						// Message:     fmt.Sprintf("Missing Javadoc comment for method: %s", methodName),
						// Severity:    r.Severity(),
						// Line:        int(cap.Node.StartPoint().Row) + 1,
						// Column:      int(cap.Node.StartPoint().Column),
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    fmt.Sprintf("Missing Javadoc comment for method: %s", methodName),
						BeginLine:      int(cap.Node.StartPoint().Row) + 1,
						BeginColumn:    int(cap.Node.StartPoint().Column),
						EndLine:        int(cap.Node.EndPoint().Row) + 1,
						EndColumn:      int(cap.Node.EndPoint().Column),
					})
				}
			}
		}
	}
	return issues
}

// Dummy function to simulate Javadoc check (adjust as needed)
func hasJavadocComment(source []byte, start, end int) bool {
	// Implement logic to check for Javadoc comments before the method declaration
	return false
}

type MagicNumberRule struct{}

func (r *MagicNumberRule) Rule() string    { return "MagicNumberRule" }
func (r *MagicNumberRule) RuleSet() string { return "Conventions" }
func (r *MagicNumberRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *MagicNumberRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    [
			(decimal_integer_literal) 
			(decimal_floating_point_literal)
		] @magic_number
    `
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			magicNumber := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			if len(magicNumber) > 0 && !isDefinedConstant(magicNumber) {
				issues = append(issues, core.Issue{
					// RuleID:      r.ID(),
					// Message:     fmt.Sprintf("Magic number detected: %s", magicNumber),
					// Severity:    r.Severity(),
					// Line:        int(cap.Node.StartPoint().Row) + 1,
					// Column:      int(cap.Node.StartPoint().Column),
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    fmt.Sprintf("Magic number detected: %s", magicNumber),
					BeginLine:      int(cap.Node.StartPoint().Row) + 1,
					BeginColumn:    int(cap.Node.StartPoint().Column),
					EndLine:        int(cap.Node.EndPoint().Row) + 1,
					EndColumn:      int(cap.Node.EndPoint().Column),
				})
			}
		}
	}
	return issues
}

func isDefinedConstant(number string) bool {
	// Add logic to check if the number is a defined constant in the code
	return false
}

type NestedIfElseRule struct {
	MaxDepth int
}

func (r *NestedIfElseRule) Rule() string    { return "AvoidDeeplyNestedIfStmts" }
func (r *NestedIfElseRule) RuleSet() string { return "Structure" }
func (r *NestedIfElseRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *NestedIfElseRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (if_statement
        (if_condition) 
        (if_body
            (block
                (block_statement
                    (if_statement) @nested_if
                )*
            )
        )
    )
    `
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		depth := calculateDepth(match.Captures[0].Node)
		if depth > r.MaxDepth {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Nested if-else exceeds maximum depth (%d)", depth),
				// Severity:    r.Severity(),
				// Line:        int(match.Captures[0].Node.StartPoint().Row) + 1,
				// Column:      int(match.Captures[0].Node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Nested if-else exceeds maximum depth (%d)", depth),
				BeginLine:      int(match.Captures[0].Node.StartPoint().Row) + 1,
				BeginColumn:    int(match.Captures[0].Node.StartPoint().Column),
				EndLine:        int(match.Captures[0].Node.EndPoint().Row) + 1,
				EndColumn:      int(match.Captures[0].Node.EndPoint().Column),
			})
		}
	}
	return issues
}

func calculateDepth(node *sitter.Node) int {
	depth := 0
	for parent := node.Parent(); parent != nil; parent = parent.Parent() {
		if parent.Type() == "if_statement" {
			depth++
		}
	}
	return depth
}

type UnnecessaryNullCheckRule struct{}

func (r *UnnecessaryNullCheckRule) Rule() string    { return "UnusedNullCheckInEquals" }
func (r *UnnecessaryNullCheckRule) RuleSet() string { return "Stability" }
func (r *UnnecessaryNullCheckRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *UnnecessaryNullCheckRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (if_statement
    (if_condition
        (binary_expression
            (identifier) @var
            (operator) @op
            (literal
                (null_literal) @null_check
            )
        )
    )
)
	`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		varName := string(source[match.Captures[0].Node.StartByte():match.Captures[0].Node.EndByte()])
		if isNonNullableVariable(varName) {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Unnecessary null check for variable: %s", varName),
				// Severity:    r.Severity(),
				// Line:        int(match.Captures[0].Node.StartPoint().Row) + 1,
				// Column:      int(match.Captures[0].Node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Unnecessary null check for variable: %s", varName),
				BeginLine:      int(match.Captures[0].Node.StartPoint().Row) + 1,
				BeginColumn:    int(match.Captures[0].Node.StartPoint().Column),
				EndLine:        int(match.Captures[0].Node.EndPoint().Row) + 1,
				EndColumn:      int(match.Captures[0].Node.EndPoint().Column),
			})
		}
	}
	return issues
}

func isNonNullableVariable(varName string) bool {
	// Logic to detect non-nullable variables, possibly using variable declarations
	return false
}

type LongMethodRule struct {
	MaxLines uint32
}

func (r *LongMethodRule) Rule() string    { return "NcssCount" }
func (r *LongMethodRule) RuleSet() string { return "Structure" }
func (r *LongMethodRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *LongMethodRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (method_declaration
        (method_header
            (identifier) @method_name
        )
        (method_body
            (block) @method_body
        )
    )
    `
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		bodyNode := match.Captures[1].Node
		lineCount := bodyNode.EndPoint().Row - bodyNode.StartPoint().Row
		if lineCount > r.MaxLines {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Method exceeds maximum line count (%d)", lineCount),
				// Severity:    r.Severity(),
				// Line:        int(bodyNode.StartPoint().Row) + 1,
				// Column:      int(bodyNode.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Method exceeds maximum line count (%d)", lineCount),
				BeginLine:      int(bodyNode.StartPoint().Row) + 1,
				BeginColumn:    int(bodyNode.StartPoint().Column),
				EndLine:        int(bodyNode.EndPoint().Row) + 1,
				EndColumn:      int(bodyNode.EndPoint().Column),
			})
		}
	}
	return issues
}

type HardCoreInfoRule struct{}

func (r *HardCoreInfoRule) Rule() string    { return "HardCodedCryptoKey" }
func (r *HardCoreInfoRule) RuleSet() string { return "Vulnerability" }
func (r *HardCoreInfoRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (h *HardCoreInfoRule) Analyze(rawAST interface{}, souruce []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue
	query := `(string_literal)@credential`
	q, err := sitter.NewQuery([]byte(query), java.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return issues
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)
	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, r := range match.Captures {
			node := r.Node
			issues = append(issues, core.Issue{
				Rule:           h.Rule(),
				RuleSet:        h.RuleSet(),
				Classification: h.Classification(),
				Description:    "Hardcoded credentials detected.",
				BeginLine:      int(node.StartPoint().Row) + 1,
				BeginColumn:    int(node.StartPoint().Column) + 1,
				EndLine:        int(node.EndPoint().Row) + 1,
				EndColumn:      int(node.EndPoint().Column) + 1,
			})
		}
	}

	return issues

}

type CommentedOutCodeRule struct{}

func (r *CommentedOutCodeRule) Rule() string    { return "CommentedOutCode" }
func (r *CommentedOutCodeRule) RuleSet() string { return "Comments" }
func (r *CommentedOutCodeRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *CommentedOutCodeRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (comment
        (block_comment) @commented_code
    )
    `
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		comment := string(source[match.Captures[0].Node.StartByte():match.Captures[0].Node.EndByte()])
		if isCommentedOutCode(comment) {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Commented-out code detected: %s", comment),
				// Severity:    r.Severity(),
				// Line:        int(match.Captures[0].Node.StartPoint().Row) + 1,
				// Column:      int(match.Captures[0].Node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Commented-out code detected: %s", comment),
				BeginLine:      int(match.Captures[0].Node.StartPoint().Row) + 1,
				BeginColumn:    int(match.Captures[0].Node.StartPoint().Column),
				EndLine:        int(match.Captures[0].Node.EndPoint().Row) + 1,
				EndColumn:      int(match.Captures[0].Node.EndPoint().Column),
			})
		}
	}
	return issues
}

func isCommentedOutCode(comment string) bool {
	// Check for patterns like "/* ... */" or "//" followed by code-like syntax
	return strings.Contains(comment, "/*") || strings.Contains(comment, "//")
}

type ConsoleLogRule struct{}

func (r *ConsoleLogRule) Rule() string    { return "ConsoleLogRule" }
func (r *ConsoleLogRule) RuleSet() string { return "Conventions" }
func (r *ConsoleLogRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *ConsoleLogRule) Analyze(rawAST interface{}, source []byte, language core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	var issues []core.Issue

	query := `
    (method_invocation
        name: (identifier) @method_name
    )
`

	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		methodName := string(source[match.Captures[0].Node.StartByte():match.Captures[0].Node.EndByte()])
		if methodName == "System.out.println" || methodName == "logger" {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Console log detected: %s", methodName),
				// Severity:    r.Severity(),
				// Line:        int(match.Captures[0].Node.StartPoint().Row) + 1,
				// Column:      int(match.Captures[0].Node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Console log detected: %s", methodName),
				BeginLine:      int(match.Captures[0].Node.StartPoint().Row) + 1,
				BeginColumn:    int(match.Captures[0].Node.StartPoint().Column),
				EndLine:        int(match.Captures[0].Node.EndPoint().Row) + 1,
				EndColumn:      int(match.Captures[0].Node.EndPoint().Column),
			})
		}
	}
	return issues
}

type UninitializedVariableRule struct{}

func (r *UninitializedVariableRule) Rule() string    { return "UninitializedVariable" }
func (r *UninitializedVariableRule) RuleSet() string { return "Conventions" }
func (r *UninitializedVariableRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *UninitializedVariableRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query to find field declarations
	fieldQuery := `
	(field_declaration
	  (variable_declarator
	    name: (identifier) @field_name
	  )
	)
	`
	qFields, _ := sitter.NewQuery([]byte(fieldQuery), java.GetLanguage())
	cursorFields := sitter.NewQueryCursor()
	cursorFields.Exec(qFields, root)

	declaredFields := make(map[string]*sitter.Node)
	for {
		match, ok := cursorFields.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			if qFields.CaptureNameForId(cap.Index) == "field_name" {
				name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
				declaredFields[name] = cap.Node
			}
		}
	}

	// Find all identifier usages
	usedQuery := `(identifier) @used`
	qUsed, _ := sitter.NewQuery([]byte(usedQuery), java.GetLanguage())
	cursorUsed := sitter.NewQueryCursor()
	cursorUsed.Exec(qUsed, root)

	used := make(map[string]bool)
	for {
		match, ok := cursorUsed.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			if qUsed.CaptureNameForId(cap.Index) == "used" {
				name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
				used[name] = true
			}
		}
	}

	// Compare declared vs used fields
	for name, node := range declaredFields {
		if !used[name] {
			// pos := sitter.Point{
			// 	Row:    node.StartPoint().Row + 1,
			// 	Column: node.StartPoint().Column,
			// }
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Unused field: %s", name),
				// Severity:    r.Severity(),
				// Line:        int(pos.Row),
				// Column:      int(pos.Column),
				// FilePath:    "",
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Unused field: %s", name),
				BeginLine:      int(node.StartPoint().Row+1) + 1,
				BeginColumn:    int(node.StartPoint().Column),
				EndLine:        int(node.EndPoint().Row+1) + 1,
				EndColumn:      int(node.EndPoint().Column),
			})
		}
	}

	return issues
}

// 1. UninitializedVariableRule
// type UninitializedVariableRule struct{}

// func (r *UninitializedVariableRule) ID() string       { return "uninitialized_variable" }
// func (r *UninitializedVariableRule) Severity() string { return "warning" }

// func (r *UninitializedVariableRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
// 	tree := rawAST.(*sitter.Tree)
// 	root := tree.RootNode()
// 	var issues []core.Issue

// 	queryStr := `
// 	(variable_declarator
// 	  name: (identifier) @uninit_var
// 	  (#not-has-child? value)
// 	)`
// 	query, _ := sitter.NewQuery([]byte(queryStr), java.GetLanguage())
// 	cursor := sitter.NewQueryCursor()
// 	cursor.Exec(query, root)

// 	for {
// 		match, ok := cursor.NextMatch()
// 		if !ok {
// 			break
// 		}
// 		for _, cap := range match.Captures {
// 			if query.CaptureNameForId(cap.Index) == "uninit_var" {
// 				if cap.Node.ChildByFieldName("value") == nil {
// 					name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
// 					issues = append(issues, core.Issue{
// 						RuleID:   r.ID(),
// 						Message:  fmt.Sprintf("Uninitialized variable: %s", name),
// 						Severity: r.Severity(),
// 						Line:     int(cap.Node.StartPoint().Row + 1),
// 						Column:   int(cap.Node.StartPoint().Column),
// 					})
// 				}
// 			}
// 		}
// 	}
// 	return issues
// }

// 2. UnusedLocalVariableRule
type UnusedLocalVariableRule struct{}

func (r *UnusedLocalVariableRule) Rule() string    { return "UnusedLocalVariable" }
func (r *UnusedLocalVariableRule) RuleSet() string { return "Conventions" }
func (r *UnusedLocalVariableRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *UnusedLocalVariableRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	declQuery := `(local_variable_declaration (variable_declarator name: (identifier) @decl))`
	qDecl, _ := sitter.NewQuery([]byte(declQuery), java.GetLanguage())
	cursorDecl := sitter.NewQueryCursor()
	cursorDecl.Exec(qDecl, root)

	decls := make(map[string]*sitter.Node)
	for {
		match, ok := cursorDecl.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			decls[name] = cap.Node
		}
	}

	usedQuery := `(identifier) @used`
	qUsed, _ := sitter.NewQuery([]byte(usedQuery), java.GetLanguage())
	cursorUsed := sitter.NewQueryCursor()
	cursorUsed.Exec(qUsed, root)

	used := make(map[string]bool)
	for {
		match, ok := cursorUsed.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			used[name] = true
		}
	}

	for name, node := range decls {
		if !used[name] {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Unused local variable: %s", name),
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row + 1),
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Unused local variable: %s", name),
				BeginLine:      int(node.StartPoint().Row+1) + 1,
				BeginColumn:    int(node.StartPoint().Column),
				EndLine:        int(node.EndPoint().Row+1) + 1,
				EndColumn:      int(node.EndPoint().Column),
			})
		}
	}
	return issues
}

// 3. UnusedFieldRule
type UnusedFieldRule struct{}

func (r *UnusedFieldRule) Rule() string    { return "UnusedPrivateField" }
func (r *UnusedFieldRule) RuleSet() string { return "Conventions" }
func (r *UnusedFieldRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *UnusedFieldRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	fieldQuery := `(field_declaration (variable_declarator name: (identifier) @field))`
	qField, _ := sitter.NewQuery([]byte(fieldQuery), java.GetLanguage())
	cursorField := sitter.NewQueryCursor()
	cursorField.Exec(qField, root)

	fields := make(map[string]*sitter.Node)
	for {
		match, ok := cursorField.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			fields[name] = cap.Node
		}
	}

	usedQuery := `(identifier) @used`
	qUsed, _ := sitter.NewQuery([]byte(usedQuery), java.GetLanguage())
	cursorUsed := sitter.NewQueryCursor()
	cursorUsed.Exec(qUsed, root)

	used := make(map[string]bool)
	for {
		match, ok := cursorUsed.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			used[name] = true
		}
	}

	for name, node := range fields {
		if !used[name] {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Unused field: %s", name),
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row + 1),
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Unused field: %s", name),
				BeginLine:      int(node.StartPoint().Row+1) + 1,
				BeginColumn:    int(node.StartPoint().Column),
				EndLine:        int(node.EndPoint().Row+1) + 1,
				EndColumn:      int(node.EndPoint().Column),
			})
		}
	}

	return issues
}

// 4. EmptyCatchBlockRule
type EmptyCatchBlockRule struct{}

func (r *EmptyCatchBlockRule) Rule() string    { return "EmptyCatchBlock" }
func (r *EmptyCatchBlockRule) RuleSet() string { return "Stability" }
func (r *EmptyCatchBlockRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *EmptyCatchBlockRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(catch_clause body: (block) @catch_block)`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			block := cap.Node
			if block.ChildCount() == 2 { // Just `{` and `}`
				issues = append(issues, core.Issue{
					// RuleID:      r.ID(),
					// Message:     "Empty catch block",
					// Severity:    r.Severity(),
					// Line:        int(block.StartPoint().Row + 1),
					// Column:      int(block.StartPoint().Column),
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Empty catch block",
					BeginLine:      int(block.StartPoint().Row + 1),
					BeginColumn:    int(block.StartPoint().Column),
					EndLine:        int(block.StartPoint().Row + 1),
					EndColumn:      int(block.StartPoint().Column),
				})
			}
		}
	}

	return issues
}

// 5. MissingDefaultCaseRule
type MissingDefaultCaseRule struct{}

func (r *MissingDefaultCaseRule) Rule() string    { return "NonExhaustiveSwitch" }
func (r *MissingDefaultCaseRule) RuleSet() string { return "Conventions" }
func (r *MissingDefaultCaseRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *MissingDefaultCaseRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	switchQuery := `(switch_block (switch_label) @label)`
	q, _ := sitter.NewQuery([]byte(switchQuery), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	defaultFound := false
	var switchNode *sitter.Node

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			label := cap.Node
			switchNode = label.Parent().Parent() // reach switch block
			if label.ChildByFieldName("default") != nil || label.Content([]byte(source)) == "default" {
				defaultFound = true
			}
		}
	}

	if !defaultFound && switchNode != nil {
		issues = append(issues, core.Issue{
			// RuleID:      r.ID(),
			// Message:     "Switch statement missing default case",
			// Severity:    r.Severity(),
			// Line:        int(switchNode.StartPoint().Row + 1),
			// Column:      int(switchNode.StartPoint().Column),
			Rule:           r.Rule(),
			RuleSet:        r.RuleSet(),
			Classification: r.Classification(),
			Description:    "Switch statement missing default case",
			BeginLine:      int(switchNode.StartPoint().Row + 1),
			BeginColumn:    int(switchNode.StartPoint().Column),
			EndLine:        int(switchNode.StartPoint().Row + 1),
			EndColumn:      int(switchNode.StartPoint().Column),
		})
	}

	return issues
}

// 6. StringConcatInLoopRule
type StringConcatInLoopRule struct{}

func (r *StringConcatInLoopRule) Rule() string    { return "UseStringBufferForStringAppends" }
func (r *StringConcatInLoopRule) RuleSet() string { return "Efficiency" }
func (r *StringConcatInLoopRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *StringConcatInLoopRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(for_statement body: (_) @body)
	(while_statement body: (_) @body)
	(enhanced_for_statement body: (_) @body)
	`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			loopBody := cap.Node
			//loopStart := loopBody.StartPoint()

			// Search for binary expressions with + inside loop
			loopContent := loopBody.Content([]byte(source))
			if string(loopContent) == "" {
				continue
			}
			loopCursor := sitter.NewQueryCursor()
			innerQuery := `(binary_expression operator: "+" @concat)`
			innerQ, _ := sitter.NewQuery([]byte(innerQuery), java.GetLanguage())
			loopCursor.Exec(innerQ, loopBody)

			for {
				m, ok := loopCursor.NextMatch()
				if !ok {
					break
				}
				for _, c := range m.Captures {
					issues = append(issues, core.Issue{
						// RuleID:      r.ID(),
						// Message:     "String concatenation inside loop — use StringBuilder",
						// Severity:    r.Severity(),
						// Line:        int(c.Node.StartPoint().Row + 1),
						// Column:      int(c.Node.StartPoint().Column),
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Classification: r.Classification(),
						Description:    "String concatenation inside loop — use StringBuilder",
						BeginLine:      int(c.Node.StartPoint().Row + 1),
						BeginColumn:    int(c.Node.StartPoint().Column),
						EndLine:        int(c.Node.EndPoint().Row + 1),
						EndColumn:      int(c.Node.EndPoint().Column),
					})
				}
			}
		}
	}

	return issues
}

// 7. SystemOutPrintlnRule
type SystemOutPrintlnRule struct{}

func (r *SystemOutPrintlnRule) Rule() string    { return "SystemPrintln" }
func (r *SystemOutPrintlnRule) RuleSet() string { return "Conventions" }
func (r *SystemOutPrintlnRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *SystemOutPrintlnRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(method_invocation
	  object: (field_access
	    object: (identifier) @obj
	    field: (identifier) @field
	  )
	  name: (identifier) @method
	)`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var objName, fieldName, methodName string
		var node *sitter.Node

		for _, cap := range match.Captures {
			content := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			switch q.CaptureNameForId(cap.Index) {
			case "obj":
				objName = content
			case "field":
				fieldName = content
			case "method":
				methodName = content
				node = cap.Node
			}
		}

		if objName == "System" && fieldName == "out" && methodName == "println" {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     "Avoid using System.out.println in production code",
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row + 1),
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Avoid using System.out.println in production code",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column),
			})
		}
	}

	return issues
}

// 8. PublicFieldRule
type PublicFieldRule struct{}

func (r *PublicFieldRule) Rule() string    { return "PublicFieldRule" }
func (r *PublicFieldRule) RuleSet() string { return "Style" }
func (r *PublicFieldRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *PublicFieldRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(field_declaration
	  (modifiers (modifier) @mod)
	  (variable_declarator name: (identifier) @field)
	)`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		var modVal, fieldName string
		var node *sitter.Node

		for _, cap := range match.Captures {
			val := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			switch q.CaptureNameForId(cap.Index) {
			case "mod":
				if val == "public" {
					modVal = val
				}
			case "field":
				fieldName = val
				node = cap.Node
			}
		}
		if modVal == "public" {
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Avoid public field: %s", fieldName),
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row + 1),
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Avoid public field: %s", fieldName),
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column),
			})
		}
	}

	return issues
}

// 9. HardcodedPasswordRule
// type HardcodedPasswordRule struct{}

// func (r *HardcodedPasswordRule) ID() string       { return "hardcoded_password" }
// func (r *HardcodedPasswordRule) Severity() string { return "critical" }

// func (r *HardcodedPasswordRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
// 	tree := rawAST.(*sitter.Tree)
// 	root := tree.RootNode()
// 	var issues []core.Issue

// 	query := `
// 	(assignment_expression
// 	  left: (identifier) @lhs
// 	  right: (string_literal) @rhs
// 	)`
// 	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
// 	cursor := sitter.NewQueryCursor()
// 	cursor.Exec(q, root)

// 	for {
// 		match, ok := cursor.NextMatch()
// 		if !ok {
// 			break
// 		}

// 		var name string
// 		var value string
// 		var node *sitter.Node

// 		for _, cap := range match.Captures {
// 			switch q.CaptureNameForId(cap.Index) {
// 			case "lhs":
// 				name = string(source[cap.Node.StartByte():cap.Node.EndByte()])
// 			case "rhs":
// 				value = string(source[cap.Node.StartByte():cap.Node.EndByte()])
// 				node = cap.Node
// 			}
// 		}

// 		if name != "" && (containsIgnoreCase(name, "password") || containsIgnoreCase(name, "pwd")) {
// 			issues = append(issues, core.Issue{
// 				RuleID:   r.ID(),
// 				Message:  fmt.Sprintf("Hardcoded password detected: %s", name),
// 				Severity: r.Severity(),
// 				Line:     int(node.StartPoint().Row + 1),
// 				Column:   int(node.StartPoint().Column),
// 			})
// 		}
// 	}

// 	return issues
// }

// func containsIgnoreCase(s, substr string) bool {
// 	return strings.Contains(strings.ToLower(s), strings.ToLower(substr))
// }

// 10. MissingJavadocRule
type MissingJavadocRule struct{}

func (r *MissingJavadocRule) Rule() string    { return "MissingJavadocRule" }
func (r *MissingJavadocRule) RuleSet() string { return "Comments" }
func (r *MissingJavadocRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *MissingJavadocRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(method_declaration
	  modifiers: (modifiers (public))
	  name: (identifier) @method_name
	)`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, cap := range match.Captures {
			node := cap.Node
			// Check if there's a comment before the node
			prev := node.PrevSibling()
			if prev == nil || prev.Type() != "comment" {
				methodName := string(source[node.StartByte():node.EndByte()])
				issues = append(issues, core.Issue{
					// RuleID:      r.ID(),
					// Message:     fmt.Sprintf("Missing Javadoc for public method: %s", methodName),
					// Severity:    r.Severity(),
					// Line:        int(node.StartPoint().Row + 1),
					// Column:      int(node.StartPoint().Column),
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    fmt.Sprintf("Missing Javadoc for public method: %s", methodName),
					BeginLine:      int(node.StartPoint().Row + 1),
					BeginColumn:    int(node.StartPoint().Column),
					EndLine:        int(node.EndPoint().Row + 1),
					EndColumn:      int(node.EndPoint().Column),
				})
			}
		}
	}

	return issues
}

// 11. MultipleClassesRule
type MultipleClassesRule struct{}

func (r *MultipleClassesRule) Rule() string    { return "MultipleClasses" }
func (r *MultipleClassesRule) RuleSet() string { return "Style" }
func (r *MultipleClassesRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *MultipleClassesRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(class_declaration name: (identifier) @class_name)`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	var classNodes []*sitter.Node
	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			classNodes = append(classNodes, cap.Node)
		}
	}

	if len(classNodes) > 1 {
		for _, node := range classNodes[1:] {
			name := string(source[node.StartByte():node.EndByte()])
			issues = append(issues, core.Issue{
				// RuleID:      r.ID(),
				// Message:     fmt.Sprintf("Multiple top-level classes in file, found extra: %s", name),
				// Severity:    r.Severity(),
				// Line:        int(node.StartPoint().Row + 1),
				// Column:      int(node.StartPoint().Column),
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    fmt.Sprintf("Multiple top-level classes in file, found extra: %s", name),
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column),
			})
		}
	}

	return issues
}

// 12. ClassNameMismatchRule
type ClassNameMismatchRule struct {
	FileName string // Inject this from context
}

func (r *ClassNameMismatchRule) Rule() string    { return "ClassNameMismatch" }
func (r *ClassNameMismatchRule) RuleSet() string { return "Style" }
func (r *ClassNameMismatchRule) Classification() string {
	return ClassificationRuleSetJava(r.RuleSet())
}

func (r *ClassNameMismatchRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(class_declaration name: (identifier) @class_name)`
	q, _ := sitter.NewQuery([]byte(query), java.GetLanguage())
	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			className := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			expected := strings.TrimSuffix(filepath.Base(r.FileName), filepath.Ext(r.FileName))
			if className != expected {
				issues = append(issues, core.Issue{
					// RuleID:      r.ID(),
					// Message:     fmt.Sprintf("Class name '%s' does not match file name '%s'", className, expected),
					// Severity:    r.Severity(),
					// Line:        int(cap.Node.StartPoint().Row + 1),
					// Column:      int(cap.Node.StartPoint().Column),
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    fmt.Sprintf("Class name '%s' does not match file name '%s'", className, expected),
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column),
				})
			}
		}
	}

	return issues
}
