package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
)

type CA1802_Rule_Performance struct{}

func (r *CA1802_Rule_Performance) ID() string      { return "CA1802" }
func (r *CA1802_Rule_Performance) Severity() int   { return 4 }
func (r *CA1802_Rule_Performance) Rule() string    { return "Use literals where possible" }
func (r *CA1802_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1802_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1802_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1802, "Consider making fields const instead of static readonly when the value is a compile-time constant.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1805_Rule_Performance struct{}

func (r *CA1805_Rule_Performance) ID() string      { return "CA1805" }
func (r *CA1805_Rule_Performance) Severity() int   { return 4 }
func (r *CA1805_Rule_Performance) Rule() string    { return "Avoid unnecessary value assignments" }
func (r *CA1805_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1805_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1805_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1805, "Avoid assigning a variable to itself.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1806_Rule_Performance struct{}

func (r *CA1806_Rule_Performance) ID() string      { return "CA1806" }
func (r *CA1806_Rule_Performance) Severity() int   { return 4 }
func (r *CA1806_Rule_Performance) Rule() string    { return "Do not ignore method results" }
func (r *CA1806_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1806_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1806_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1806, "Use the return value of TryParse and other similar methods.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1810_Rule_Performance struct{}

func (r *CA1810_Rule_Performance) ID() string    { return "CA1810" }
func (r *CA1810_Rule_Performance) Severity() int { return 4 }
func (r *CA1810_Rule_Performance) Rule() string {
	return "Initialize reference type static fields inline"
}
func (r *CA1810_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1810_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1810_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1810, "Avoid explicit static constructors when not necessary to improve performance.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1812_Rule_Performance struct{}

func (r *CA1812_Rule_Performance) ID() string      { return "CA1812" }
func (r *CA1812_Rule_Performance) Severity() int   { return 4 }
func (r *CA1812_Rule_Performance) Rule() string    { return "Avoid uninstantiated internal classes" }
func (r *CA1812_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1812_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1812_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1812, "Avoid internal classes that are never instantiated to reduce unnecessary code.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1813_Rule_Performance struct{}

func (r *CA1813_Rule_Performance) ID() string      { return "CA1813" }
func (r *CA1813_Rule_Performance) Severity() int   { return 4 }
func (r *CA1813_Rule_Performance) Rule() string    { return "Avoid unsealed attributes" }
func (r *CA1813_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1813_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1813_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1813, "Seal custom attributes to avoid unnecessary searches through the inheritance hierarchy.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1814_Rule_Performance struct{}

func (r *CA1814_Rule_Performance) ID() string      { return "CA1814" }
func (r *CA1814_Rule_Performance) Severity() int   { return 4 }
func (r *CA1814_Rule_Performance) Rule() string    { return "Prefer jagged arrays over multidimensional" }
func (r *CA1814_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1814_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1814_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1814, "Jagged arrays can offer better memory and performance characteristics.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1815_Rule_Performance struct{}

func (r *CA1815_Rule_Performance) ID() string    { return "CA1815" }
func (r *CA1815_Rule_Performance) Severity() int { return 4 }
func (r *CA1815_Rule_Performance) Rule() string {
	return "Override equals and operator equals on value types"
}
func (r *CA1815_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1815_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1815_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1815, "Override Equals for value types to avoid expensive reflection-based comparison.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1816_Rule_Performance struct{}

func (r *CA1816_Rule_Performance) ID() string      { return "CA1816" }
func (r *CA1816_Rule_Performance) Severity() int   { return 4 }
func (r *CA1816_Rule_Performance) Rule() string    { return "Call GC.SuppressFinalize correctly" }
func (r *CA1816_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1816_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1816_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1816, "Ensure GC.SuppressFinalize is correctly used within Dispose implementations.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1819_Rule_Performance struct{}

func (r *CA1819_Rule_Performance) ID() string      { return "CA1819" }
func (r *CA1819_Rule_Performance) Severity() int   { return 4 }
func (r *CA1819_Rule_Performance) Rule() string    { return "Properties should not return arrays" }
func (r *CA1819_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1819_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1819_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1819, "Returning arrays from properties exposes internal state; use IEnumerable or IReadOnlyCollection instead.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1820_Rule_Performance struct{}

func (r *CA1820_Rule_Performance) ID() string      { return "CA1820" }
func (r *CA1820_Rule_Performance) Severity() int   { return 4 }
func (r *CA1820_Rule_Performance) Rule() string    { return "Test for empty strings using string length" }
func (r *CA1820_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1820_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1820_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1820, "Use string.Length == 0 instead of string == \"\" for performance.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1821_Rule_Performance struct{}

func (r *CA1821_Rule_Performance) ID() string      { return "CA1821" }
func (r *CA1821_Rule_Performance) Severity() int   { return 4 }
func (r *CA1821_Rule_Performance) Rule() string    { return "Remove empty finalizers" }
func (r *CA1821_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1821_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1821_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1821, "Empty finalizers introduce overhead. Remove them unless necessary.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1822_Rule_Performance struct{}

func (r *CA1822_Rule_Performance) ID() string      { return "CA1822" }
func (r *CA1822_Rule_Performance) Severity() int   { return 4 }
func (r *CA1822_Rule_Performance) Rule() string    { return "Mark members as static" }
func (r *CA1822_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1822_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1822_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1822, "Members that do not access instance data can be marked static for efficiency.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1823_Rule_Performance struct{}

func (r *CA1823_Rule_Performance) ID() string      { return "CA1823" }
func (r *CA1823_Rule_Performance) Severity() int   { return 4 }
func (r *CA1823_Rule_Performance) Rule() string    { return "Avoid unused private fields" }
func (r *CA1823_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1823_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1823_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1823, "Remove private fields that are never used to improve memory efficiency.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1824_Rule_Performance struct{}

func (r *CA1824_Rule_Performance) ID() string    { return "CA1824" }
func (r *CA1824_Rule_Performance) Severity() int { return 4 }
func (r *CA1824_Rule_Performance) Rule() string {
	return "Mark assemblies with NeutralResourcesLanguageAttribute"
}
func (r *CA1824_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1824_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1824_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1824, "Apply NeutralResourcesLanguage to avoid unnecessary fallback lookups.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1825_Rule_Performance struct{}

func (r *CA1825_Rule_Performance) ID() string      { return "CA1825" }
func (r *CA1825_Rule_Performance) Severity() int   { return 4 }
func (r *CA1825_Rule_Performance) Rule() string    { return "Avoid zero-length array allocations" }
func (r *CA1825_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1825_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1825_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1825, "Use Array.Empty<T>() instead of new T[0] for better performance.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1826_Rule_Performance struct{}

func (r *CA1826_Rule_Performance) ID() string    { return "CA1826" }
func (r *CA1826_Rule_Performance) Severity() int { return 4 }
func (r *CA1826_Rule_Performance) Rule() string {
	return "Do not use Enumerable methods on indexable collections"
}
func (r *CA1826_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1826_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1826_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1826, "Avoid using LINQ methods on collections that support direct indexing for better performance.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1827_Rule_Performance struct{}

func (r *CA1827_Rule_Performance) ID() string    { return "CA1827" }
func (r *CA1827_Rule_Performance) Severity() int { return 4 }
func (r *CA1827_Rule_Performance) Rule() string {
	return "Do not use Count() or LongCount() when Any() can be used"
}
func (r *CA1827_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1827_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1827_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1827, "Use Any() instead of Count() > 0 to avoid unnecessary enumeration.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1828_Rule_Performance struct{}

func (r *CA1828_Rule_Performance) ID() string    { return "CA1828" }
func (r *CA1828_Rule_Performance) Severity() int { return 4 }
func (r *CA1828_Rule_Performance) Rule() string {
	return "Do not use Count() or LongCount() when no results are needed"
}
func (r *CA1828_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1828_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1828_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1828, "Use Any() or FirstOrDefault() instead of Count() when result count is not required.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1829_Rule_Performance struct{}

func (r *CA1829_Rule_Performance) ID() string    { return "CA1829" }
func (r *CA1829_Rule_Performance) Severity() int { return 4 }
func (r *CA1829_Rule_Performance) Rule() string {
	return "Use Length/Count property instead of Count() method"
}
func (r *CA1829_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1829_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1829_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1829, "Count LINQ method was used on a type that supports an equivalent, more efficient Length or Count property.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1830_Rule_Performance struct{}

func (r *CA1830_Rule_Performance) ID() string    { return "CA1830" }
func (r *CA1830_Rule_Performance) Severity() int { return 4 }
func (r *CA1830_Rule_Performance) Rule() string {
	return "Prefer strongly-typed Append and Insert method overloads on StringBuilder"
}
func (r *CA1830_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1830_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1830_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1830, "Use strongly-typed StringBuilder methods for better performance.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1831_Rule_Performance struct{}

func (r *CA1831_Rule_Performance) ID() string      { return "CA1831" }
func (r *CA1831_Rule_Performance) Severity() int   { return 4 }
func (r *CA1831_Rule_Performance) Rule() string    { return "Use AsSpan or AsMemory instead of Substring" }
func (r *CA1831_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1831_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1831_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1831, "Use Span or Memory to avoid unnecessary allocations from Substring calls.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1832_Rule_Performance struct{}

func (r *CA1832_Rule_Performance) ID() string      { return "CA1832" }
func (r *CA1832_Rule_Performance) Severity() int   { return 4 }
func (r *CA1832_Rule_Performance) Rule() string    { return "Use AsSpan or AsMemory instead of IndexOf" }
func (r *CA1832_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1832_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1832_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1832, "Use Span/Memory with IndexOf for improved performance over string-based operations.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1833_Rule_Performance struct{}

func (r *CA1833_Rule_Performance) ID() string    { return "CA1833" }
func (r *CA1833_Rule_Performance) Severity() int { return 4 }
func (r *CA1833_Rule_Performance) Rule() string {
	return "Use StringComparison.Ordinal when comparing strings"
}
func (r *CA1833_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1833_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1833_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1833, "Specify StringComparison.Ordinal to avoid culture overhead in string comparisons.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1834_Rule_Performance struct{}

func (r *CA1834_Rule_Performance) ID() string    { return "CA1834" }
func (r *CA1834_Rule_Performance) Severity() int { return 4 }
func (r *CA1834_Rule_Performance) Rule() string {
	return "Use StringComparison.OrdinalIgnoreCase when comparing strings"
}
func (r *CA1834_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1834_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1834_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1834, "Use StringComparison.OrdinalIgnoreCase for case-insensitive comparisons without culture overhead.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1836_Rule_Performance struct{}

func (r *CA1836_Rule_Performance) ID() string    { return "CA1836" }
func (r *CA1836_Rule_Performance) Severity() int { return 4 }
func (r *CA1836_Rule_Performance) Rule() string {
	return "Prefer IsEmpty over Count when checking whether a collection is empty"
}
func (r *CA1836_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1836_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1836_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1836, "Use IsEmpty property instead of Count == 0 for better performance on collections.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1837_Rule_Performance struct{}

func (r *CA1837_Rule_Performance) ID() string    { return "CA1837" }
func (r *CA1837_Rule_Performance) Severity() int { return 4 }
func (r *CA1837_Rule_Performance) Rule() string {
	return "Use Environment.ProcessId instead of Process.GetCurrentProcess().Id"
}
func (r *CA1837_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1837_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1837_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(
		CA1837,
		"Environment.ProcessId is simpler and faster than Process.GetCurrentProcess().Id.",
		r.Rule(),
		r.RuleSet(),
		r.Severity(),
		rawAST.(*sitter.Tree),
	)
}

type CA1838_Rule_Performance struct{}

func (r *CA1838_Rule_Performance) ID() string    { return "CA1838" }
func (r *CA1838_Rule_Performance) Severity() int { return 4 }
func (r *CA1838_Rule_Performance) Rule() string {
	return "Avoid StringBuilder parameters for P/Invokes"
}
func (r *CA1838_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1838_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1838_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1838,
		"Marshalling of StringBuilder always creates a native buffer copy, resulting in multiple allocations for one marshalling operation.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1839_Rule_Performance struct{}

func (r *CA1839_Rule_Performance) ID() string    { return "CA1839" }
func (r *CA1839_Rule_Performance) Severity() int { return 4 }
func (r *CA1839_Rule_Performance) Rule() string {
	return "Use Environment.ProcessPath instead of Process.GetCurrentProcess().MainModule.FileName"
}
func (r *CA1839_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1839_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1839_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1839,
		"Environment.ProcessPath is simpler and faster than Process.GetCurrentProcess().MainModule.FileName.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1840_Rule_Performance struct{}

func (r *CA1840_Rule_Performance) ID() string    { return "CA1840" }
func (r *CA1840_Rule_Performance) Severity() int { return 4 }
func (r *CA1840_Rule_Performance) Rule() string {
	return "Use Environment.CurrentManagedThreadId instead of Thread.CurrentThread.ManagedThreadId"
}
func (r *CA1840_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1840_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1840_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1840,
		"Environment.CurrentManagedThreadId is more compact and efficient than Thread.CurrentThread.ManagedThreadId.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1841_Rule_Performance struct{}

func (r *CA1841_Rule_Performance) ID() string      { return "CA1841" }
func (r *CA1841_Rule_Performance) Severity() int   { return 4 }
func (r *CA1841_Rule_Performance) Rule() string    { return "Prefer Dictionary Contains methods" }
func (r *CA1841_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1841_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1841_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1841,
		"Calling Contains on the Keys or Values collection may be more expensive than calling ContainsKey or ContainsValue directly.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1842_Rule_Performance struct{}

func (r *CA1842_Rule_Performance) ID() string      { return "CA1842" }
func (r *CA1842_Rule_Performance) Severity() int   { return 4 }
func (r *CA1842_Rule_Performance) Rule() string    { return "Do not use 'WhenAll' with a single task" }
func (r *CA1842_Rule_Performance) RuleSet() string { return "Performance" }

// ClassificationRuleSetDotNet returns the classification for .NET rule sets.
func (r *CA1842_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1842_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1842,
		"Using WhenAll with a single task may result in performance loss. Await or return the task instead.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1843_Rule_Performance struct{}

func (r *CA1843_Rule_Performance) ID() string      { return "CA1843" }
func (r *CA1843_Rule_Performance) Severity() int   { return 4 }
func (r *CA1843_Rule_Performance) Rule() string    { return "Do not use 'WaitAll' with a single task" }
func (r *CA1843_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1843_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1843_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1843,
		"Using WaitAll with a single task may result in performance loss. Await or return the task instead.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1844_Rule_Performance struct{}

func (r *CA1844_Rule_Performance) ID() string    { return "CA1844" }
func (r *CA1844_Rule_Performance) Severity() int { return 4 }
func (r *CA1844_Rule_Performance) Rule() string {
	return "Provide memory-based overrides of async methods when subclassing 'Stream'"
}
func (r *CA1844_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1844_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1844_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1844,
		"To improve performance, override the memory-based async methods when subclassing 'Stream'.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1845_Rule_Performance struct{}

func (r *CA1845_Rule_Performance) ID() string      { return "CA1845" }
func (r *CA1845_Rule_Performance) Severity() int   { return 4 }
func (r *CA1845_Rule_Performance) Rule() string    { return "Use span-based 'string.Concat'" }
func (r *CA1845_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1845_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1845_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1845,
		"It is more efficient to use AsSpan and string.Concat, instead of Substring and a concatenation operator.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1846_Rule_Performance struct{}

func (r *CA1846_Rule_Performance) ID() string      { return "CA1846" }
func (r *CA1846_Rule_Performance) Severity() int   { return 4 }
func (r *CA1846_Rule_Performance) Rule() string    { return "Prefer AsSpan over Substring" }
func (r *CA1846_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1846_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1846_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1846,
		"AsSpan is more efficient than Substring. Substring performs an O(n) copy; AsSpan does not and has constant cost.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1847_Rule_Performance struct{}

func (r *CA1847_Rule_Performance) ID() string    { return "CA1847" }
func (r *CA1847_Rule_Performance) Severity() int { return 4 }
func (r *CA1847_Rule_Performance) Rule() string {
	return "Use char literal for a single character lookup"
}
func (r *CA1847_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1847_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1847_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1847,
		"Use String.Contains(char) instead of String.Contains(string) when searching for a single character.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1848_Rule_Performance struct{}

func (r *CA1848_Rule_Performance) ID() string      { return "CA1848" }
func (r *CA1848_Rule_Performance) Severity() int   { return 4 }
func (r *CA1848_Rule_Performance) Rule() string    { return "Use the LoggerMessage delegates" }
func (r *CA1848_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1848_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1848_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1848,
		"For improved performance, use the LoggerMessage delegates.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1849_Rule_Performance struct{}

func (r *CA1849_Rule_Performance) ID() string      { return "CA1849" }
func (r *CA1849_Rule_Performance) Severity() int   { return 4 }
func (r *CA1849_Rule_Performance) Rule() string    { return "Call async methods when in an async method" }
func (r *CA1849_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1849_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1849_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1849,
		"In a method which is already asynchronous, calls to other methods should be to their async versions, where they exist.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1850_Rule_Performance struct{}

func (r *CA1850_Rule_Performance) ID() string    { return "CA1850" }
func (r *CA1850_Rule_Performance) Severity() int { return 4 }
func (r *CA1850_Rule_Performance) Rule() string {
	return "Prefer static HashData method over ComputeHash"
}
func (r *CA1850_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1850_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1850_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1850,
		"It’s more efficient to use the static HashData method instead of managing a HashAlgorithm instance.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1851_Rule_Performance struct{}

func (r *CA1851_Rule_Performance) ID() string    { return "CA1851" }
func (r *CA1851_Rule_Performance) Severity() int { return 4 }
func (r *CA1851_Rule_Performance) Rule() string {
	return "Possible multiple enumerations of IEnumerable collection"
}
func (r *CA1851_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1851_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1851_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1851,
		"Multiple enumerations of IEnumerable can result in performance loss. Avoid or cache enumeration.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1852_Rule_Performance struct{}

func (r *CA1852_Rule_Performance) ID() string      { return "CA1852" }
func (r *CA1852_Rule_Performance) Severity() int   { return 4 }
func (r *CA1852_Rule_Performance) Rule() string    { return "Seal internal types" }
func (r *CA1852_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1852_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1852_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1852,
		"Sealing internal types prevents unnecessary subclassing and improves performance.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1854_Rule_Performance struct{}

func (r *CA1854_Rule_Performance) ID() string    { return "CA1854" }
func (r *CA1854_Rule_Performance) Severity() int { return 4 }
func (r *CA1854_Rule_Performance) Rule() string {
	return "Prefer the 'IDictionary.TryGetValue(TKey, out TValue)' method"
}
func (r *CA1854_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1854_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1854_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1854,
		"Use TryGetValue to avoid double lookup from ContainsKey and indexer.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1855_Rule_Performance struct{}

func (r *CA1855_Rule_Performance) ID() string    { return "CA1855" }
func (r *CA1855_Rule_Performance) Severity() int { return 4 }
func (r *CA1855_Rule_Performance) Rule() string {
	return "Use Span<T>.Clear() instead of Span<T>.Fill()"
}
func (r *CA1855_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1855_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1855_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1855,
		"Clear() is more efficient than Fill(default) for setting to default values.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1856_Rule_Performance struct{}

func (r *CA1856_Rule_Performance) ID() string    { return "CA1856" }
func (r *CA1856_Rule_Performance) Severity() int { return 4 }
func (r *CA1856_Rule_Performance) Rule() string {
	return "Incorrect usage of ConstantExpected attribute"
}
func (r *CA1856_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1856_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1856_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1856,
		"The ConstantExpectedAttribute attribute is not applied correctly on a parameter.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1858_Rule_Performance struct{}

func (r *CA1858_Rule_Performance) ID() string      { return "CA1858" }
func (r *CA1858_Rule_Performance) Severity() int   { return 4 }
func (r *CA1858_Rule_Performance) Rule() string    { return "Use StartsWith instead of IndexOf" }
func (r *CA1858_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1858_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1858_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1858,
		"It's more efficient to call String.StartsWith than to call String.IndexOf to check whether a string starts with a given prefix.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1859_Rule_Performance struct{}

func (r *CA1859_Rule_Performance) ID() string    { return "CA1859" }
func (r *CA1859_Rule_Performance) Severity() int { return 4 }
func (r *CA1859_Rule_Performance) Rule() string {
	return "Use concrete types when possible for improved performance"
}
func (r *CA1859_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1859_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1859_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1859,
		"Code uses interface types or abstract types, leading to unnecessary interface calls or virtual calls.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1860_Rule_Performance struct{}

func (r *CA1860_Rule_Performance) ID() string    { return "CA1860" }
func (r *CA1860_Rule_Performance) Severity() int { return 4 }
func (r *CA1860_Rule_Performance) Rule() string {
	return "Avoid using 'Enumerable.Any()' extension method"
}
func (r *CA1860_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1860_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1860_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1860,
		"It's more efficient and clearer to use Length, Count, or IsEmpty (if possible) than to call Enumerable.Any to determine whether a collection type has any elements.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1861_Rule_Performance struct{}

func (r *CA1861_Rule_Performance) ID() string      { return "CA1861" }
func (r *CA1861_Rule_Performance) Severity() int   { return 4 }
func (r *CA1861_Rule_Performance) Rule() string    { return "Avoid constant arrays as arguments" }
func (r *CA1861_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1861_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1861_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1861,
		"Constant arrays passed as arguments are not reused which implies a performance overhead. Consider extracting them to 'static readonly' fields to improve performance.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1862_Rule_Performance struct{}

func (r *CA1862_Rule_Performance) ID() string    { return "CA1862" }
func (r *CA1862_Rule_Performance) Severity() int { return 4 }
func (r *CA1862_Rule_Performance) Rule() string {
	return "Use the 'StringComparison' method overloads to perform case-insensitive string comparisons"
}
func (r *CA1862_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1862_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1862_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1862,
		"When code calls ToLower() or ToUpper() to perform a case-insensitive string comparison, an unnecessary allocation is performed.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1863_Rule_Performance struct{}

func (r *CA1863_Rule_Performance) ID() string      { return "CA1863" }
func (r *CA1863_Rule_Performance) Severity() int   { return 4 }
func (r *CA1863_Rule_Performance) Rule() string    { return "Use 'CompositeFormat'" }
func (r *CA1863_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1863_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1863_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1863,
		"To reduce the formatting cost, cache and use a CompositeFormat instance as the argument to String.Format or StringBuilder.AppendFormat.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1864_Rule_Performance struct{}

func (r *CA1864_Rule_Performance) ID() string    { return "CA1864" }
func (r *CA1864_Rule_Performance) Severity() int { return 4 }
func (r *CA1864_Rule_Performance) Rule() string {
	return "Prefer the 'IDictionary.TryAdd(TKey, TValue)' method"
}
func (r *CA1864_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1864_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1864_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1864,
		"Both Dictionary<TKey,TValue>.ContainsKey(TKey) and Dictionary<TKey,TValue>.Add perform a lookup, which is redundant. It's is more efficient to call Dictionary<TKey,TValue>.TryAdd, which returns a bool indicating if the value was added or not. TryAdd doesn't overwrite the key's value if the key is already present.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1865ToCA1867_Rule_Performance struct{}

func (r *CA1865ToCA1867_Rule_Performance) ID() string      { return "CA1865-CA1867" }
func (r *CA1865ToCA1867_Rule_Performance) Severity() int   { return 4 }
func (r *CA1865ToCA1867_Rule_Performance) Rule() string    { return "Use char overload" }
func (r *CA1865ToCA1867_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1865ToCA1867_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1865ToCA1867_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1865_CA1867,
		"The char overload is a better performing overload for a string with a single char.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1868_Rule_Performance struct{}

func (r *CA1868_Rule_Performance) ID() string      { return "CA1868" }
func (r *CA1868_Rule_Performance) Severity() int   { return 4 }
func (r *CA1868_Rule_Performance) Rule() string    { return "Unnecessary call to 'Contains' for sets" }
func (r *CA1868_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1868_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1868_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1868,
		"Both ISet<T>.Add(T) and ICollection<T>.Remove(T) perform a lookup, which makes it redundant to call ICollection<T>.Contains(T) beforehand. It's more efficient to call Add(T) or Remove(T) directly, which returns a Boolean value indicating whether the item was added or removed.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1869_Rule_Performance struct{}

func (r *CA1869_Rule_Performance) ID() string    { return "CA1869" }
func (r *CA1869_Rule_Performance) Severity() int { return 4 }
func (r *CA1869_Rule_Performance) Rule() string {
	return "Cache and reuse 'JsonSerializerOptions' instances"
}
func (r *CA1869_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1869_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1869_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1869,
		"Using a local instance of JsonSerializerOptions for serialization or deserialization can substantially degrade the performance of your application if your code executes multiple times, since System.Text.Json internally caches serialization-related metadata into the provided instance.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1870_Rule_Performance struct{}

func (r *CA1870_Rule_Performance) ID() string      { return "CA1870" }
func (r *CA1870_Rule_Performance) Severity() int   { return 4 }
func (r *CA1870_Rule_Performance) Rule() string    { return "Use a cached 'SearchValues' instance" }
func (r *CA1870_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1870_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1870_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1870,
		"Using a cached SearchValues<T> instance is more efficient than passing values to 'IndexOfAny' or 'ContainsAny' directly.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1871_Rule_Performance struct{}

func (r *CA1871_Rule_Performance) ID() string    { return "CA1871" }
func (r *CA1871_Rule_Performance) Severity() int { return 4 }
func (r *CA1871_Rule_Performance) Rule() string {
	return "Do not pass a nullable struct to 'ArgumentNullException.ThrowIfNull'"
}
func (r *CA1871_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1871_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1871_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1871,
		"ArgumentNullException.ThrowIfNull' accepts an 'object', so passing a nullable struct might cause the value to be boxed.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}

type CA1872_Rule_Performance struct{}

func (r *CA1872_Rule_Performance) ID() string    { return "CA1872" }
func (r *CA1872_Rule_Performance) Severity() int { return 3 }
func (r *CA1872_Rule_Performance) Rule() string {
	return "Prefer 'Convert.ToHexString' and 'Convert.ToHexStringLower' over call chains based on 'BitConverter.ToString'"
}
func (r *CA1872_Rule_Performance) RuleSet() string { return "Performance" }
func (r *CA1872_Rule_Performance) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1872_Rule_Performance) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1872,
		"Use Convert.ToHexString or Convert.ToHexStringLower when encoding bytes to a hexadecimal string representation. These methods are more efficient and allocation-friendly than using BitConverter.ToString in combination with String.Replace to replace dashes and String.ToLower.",
		r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree),
	)
}
