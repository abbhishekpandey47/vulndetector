package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
)

type CA1501_Rule_Maintainability struct{}

func (r *CA1501_Rule_Maintainability) ID() string      { return "CA1501" }
func (r *CA1501_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1501_Rule_Maintainability) Rule() string    { return "Avoid excessive inheritance" }
func (r *CA1501_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1501_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1501_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1501, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1502_Rule_Maintainability struct{}

func (r *CA1502_Rule_Maintainability) ID() string      { return "CA1502" }
func (r *CA1502_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1502_Rule_Maintainability) Rule() string    { return "Avoid excessive complexity" }
func (r *CA1502_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1502_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1502_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1502, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1506_Rule_Maintainability struct{}

func (r *CA1506_Rule_Maintainability) ID() string      { return "CA1506" }
func (r *CA1506_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1506_Rule_Maintainability) Rule() string    { return "Avoid excessive class coupling" }
func (r *CA1506_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1506_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1506_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1506, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1507_Rule_Maintainability struct{}

func (r *CA1507_Rule_Maintainability) ID() string      { return "CA1507" }
func (r *CA1507_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1507_Rule_Maintainability) Rule() string    { return "Use nameof in place of string literal" }
func (r *CA1507_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1507_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1507_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1507, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1508_Rule_Maintainability struct{}

func (r *CA1508_Rule_Maintainability) ID() string      { return "CA1508" }
func (r *CA1508_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1508_Rule_Maintainability) Rule() string    { return "Avoid dead conditional code" }
func (r *CA1508_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1508_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1508_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1508, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1510_Rule_Maintainability struct{}

func (r *CA1510_Rule_Maintainability) ID() string      { return "CA1510" }
func (r *CA1510_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1510_Rule_Maintainability) Rule() string    { return "Use ArgumentNullException throw helper" }
func (r *CA1510_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1510_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1510_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1510, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1511_Rule_Maintainability struct{}

func (r *CA1511_Rule_Maintainability) ID() string      { return "CA1511" }
func (r *CA1511_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1511_Rule_Maintainability) Rule() string    { return "Use ArgumentException throw helper" }
func (r *CA1511_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1511_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1511_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1511, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1512_Rule_Maintainability struct{}

func (r *CA1512_Rule_Maintainability) ID() string    { return "CA1512" }
func (r *CA1512_Rule_Maintainability) Severity() int { return 4 }
func (r *CA1512_Rule_Maintainability) Rule() string {
	return "Use ArgumentOutOfRangeException throw helper"
}
func (r *CA1512_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1512_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1512_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1512, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1513_Rule_Maintainability struct{}

func (r *CA1513_Rule_Maintainability) ID() string    { return "CA1513" }
func (r *CA1513_Rule_Maintainability) Severity() int { return 4 }
func (r *CA1513_Rule_Maintainability) Rule() string {
	return "Use ObjectDisposedException throw helper"
}
func (r *CA1513_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1513_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1513_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1513, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1514_Rule_Maintainability struct{}

func (r *CA1514_Rule_Maintainability) ID() string    { return "CA1514" }
func (r *CA1514_Rule_Maintainability) Severity() int { return 4 }
func (r *CA1514_Rule_Maintainability) Rule() string {
	return "Use InvalidOperationException throw helper"
}
func (r *CA1514_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1514_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1514_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1514, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1515_Rule_Maintainability struct{}

func (r *CA1515_Rule_Maintainability) ID() string      { return "CA1515" }
func (r *CA1515_Rule_Maintainability) Severity() int   { return 4 }
func (r *CA1515_Rule_Maintainability) Rule() string    { return "Make types internal by default" }
func (r *CA1515_Rule_Maintainability) RuleSet() string { return "Maintainability" }
func (r *CA1515_Rule_Maintainability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1515_Rule_Maintainability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1515, r.Rule(), r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}
