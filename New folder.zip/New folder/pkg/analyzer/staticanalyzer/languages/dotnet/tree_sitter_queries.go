package sca_csharp

const (

	// Design
	CA1032 = `(constructor_declaration) @ctor`
	CA1070 = `(event_declaration modifiers: (modifiers (virtual)) ) @event`

	// Reliability
	CA2000 = `(object_creation_expression type: (identifier) @created_type)`

	// issue : invalid node type 'this' at line 2 column 0
	CA2002 = `(lock_statement (identifier) @lock_var)
				(lock_statement (this) @lock_this)
				(lock_statement (invocation_expression (member_access_expression (identifier) @type_name)) @lock_typeof)
				`
	CA2007 = `(await_expression (identifier) @awaited)
				(await_expression (invocation_expression function: (identifier) @method_name))`

	// issue : invalid field 'object' at line 3 column 0 and invalid field 'object' at line 4 column 0
	CA2008 = `(invocation_expression
		(member_access_expression
			object: (member_access_expression
				object: (identifier) @task (#eq? @task "Task")
				name: (identifier) @factory (#eq? @factory "Factory"))
			name: (identifier) @method (#eq? @method "StartNew")))`
	CA2009 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method_name) (#eq? @method_name "ToImmutableArray"))`
	CA2011 = `(assignment_expression 
		left: (identifier) @left_name 
		right: (identifier) @right_name 
		(#eq? @left_name @right_name))`
	CA2012 = `(assignment_expression 
		right: (await_expression 
			(invocation_expression 
				(identifier) @method)))`
	CA2013 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method_name) (#eq? @method_name "ReferenceEquals"))`
	// issue : invalid unknown at line 4 column 0 (array_creation_expression) @alloc)))
	CA2014 = `(for_statement
		body: (block
			(expression_statement
				(array_creation_expression) @alloc)))`
	// issue : invalid node type 'base_type' at line 3 column 0
	CA2015 = `(class_declaration
		base_list: (base_list
			(base_type
				(generic_name
					name: (identifier) @base))) (#eq? @base "MemoryManager"))`
	CA2016 = `(invocation_expression 
		arguments: (argument_list 
			(_) @arg))`
	CA2017 = `(invocation_expression 
		(identifier) @logger (#match? @logger "^Log(Information|Warning|Error)$"))`
	// issue : invalid field 'object' at line 3 column 0
	CA2018 = `(invocation_expression
		(member_access_expression
			object: (identifier) @buffer (#eq? @buffer "Buffer")
			name: (identifier) @method (#eq? @method "BlockCopy")))`
	CA2019 = `(field_declaration 
		(attribute_list 
			(attribute 
				name: (identifier) @attr)) (#eq? @attr "ThreadStatic"))`
	CA2020 = `(binary_expression 
		left: (_) @left 
		right: (_) @right)`
	// issue : invalid syntax at line 4 column 1
	CA2021 = `(invocation_expression 
		(member_access_expression 
			name: (generic_name 
				name: (identifier) @method)) (#match? @method "^(Cast|OfType)$")`
	CA2022 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method_name) (#eq? @method_name "Read"))`
	CA2024 = `(member_access_expression 
		name: (identifier) @property (#eq? @property "EndOfStream"))`

	// Naming
	CA1700 = `(enum_member_declaration name: (identifier) @reserved_name (#eq? @reserved_name "Reserved"))`
	CA1707 = `(identifier) @underscore_id (#match? @underscore_id "_")`
	CA1710 = `(class_declaration name: (identifier) @class_name) (#not-match? @class_name "Collection$|Dictionary$")`
	CA1711 = `(class_declaration name: (identifier) @class_name) (#match? @class_name "(Stream|Event)$")`
	CA1713 = `(event_field_declaration declarator: (variable_declarator name: (identifier) @event_name)) (#match? @event_name "^(Before|After)")`
	CA1716 = `(identifier) @id (#match? @id "^(class|namespace|int|string|return|public)$")`
	CA1717 = `(enum_declaration name: (identifier) @enum_name) (#match? @enum_name "s$")`
	CA1720 = `(identifier) @id (#match? @id "Int32|Boolean|Double|Decimal|Byte")`
	CA1727 = `(interpolated_string_expression (interpolation (identifier) @placeholder)) (#not-match? @placeholder "^[A-Z][a-zA-Z0-9]*$")`
	CA1712 = `(enum_declaration
		name: (identifier) @enum_name
		(enum_member_declaration
			name: (identifier) @member_name
			(#match? @member_name (concat "^" @enum_name ".*"))
		))`
	CA1714 = `(attribute_list
		(attribute name: (identifier) @attr_name (#eq? @attr_name "Flags"))
	)
	(enum_declaration name: (identifier) @enum_name (#not-match? @enum_name "s$"))`
	CA1715 = `[
		(interface_declaration name: (identifier) @interface_name (#not-match? @interface_name "^I[A-Z]"))
		(type_parameter name: (identifier) @type_param (#not-match? @type_param "^T[A-Z]"))
	]`
	CA1724 = `(namespace_declaration name: (identifier) @ns_name)
		(class_declaration name: (identifier) @class_name (#eq? @class_name @ns_name))`

	CA1708 = ``
	CA1721 = ``
	CA1725 = ``

	// Single File / Publish
	IL3000 = `(invocation_expression (member_access_expression name: (identifier) @member (#eq? @member "Location")))`
	IL3001 = `(invocation_expression (member_access_expression name: (identifier) @member (#eq? @member "CodeBase")))`
	IL3002 = `(invocation_expression (identifier) @call (#has-attribute? "RequiresAssemblyFiles"))`
	IL3003 = `(class_declaration (attribute_list (attribute name: (identifier) @attr_name (#eq? @attr_name "RequiresAssemblyFiles"))))`
	IL3005 = `(method_declaration 
		(attribute_list (attribute name: (identifier) @attr_name (#eq? @attr_name "RequiresAssemblyFiles"))) 
		name: (identifier) @main (#eq? @main "Main"))`

	// Interoperability
	CA1401 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr_name (#eq? @attr_name "DllImport"))
		)
		modifiers: (modifiers (modifier) @visibility (#match? @visibility "public|protected"))
	)`

	CA1416 = `(attribute_list
		(attribute name: (identifier) @attr_name
			(#match? @attr_name "SupportedOSPlatform|UnsupportedOSPlatform")
		)
	)`

	CA1417 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr_name (#eq? @attr_name "DllImport"))
		)
		(parameter_list
			(parameter
				(attribute_list
					(attribute name: (identifier) @out_attr (#eq? @out_attr "Out"))
				)
				type: (predefined_type) @param_type (#eq? @param_type "string")
			)
		)
	)`

	CA1418 = `(attribute_list
		(attribute name: (identifier) @attr_name
			(#not-match? @attr_name "^(SupportedOSPlatform|UnsupportedOSPlatform|ObsoletedOSPlatform)$")
		)
	)`

	CA1419 = `(class_declaration
		(attribute_list
			(attribute name: (identifier) @attr_name (#eq? @attr_name "ComVisible"))
		)
		body: (declaration_list
			![
				(constructor_declaration parameter_list: (parameter_list (parameter)+))
			]
		)
	)`

	CA1420 = `(attribute_list
		(attribute name: (identifier) @attr_name
			(#eq? @attr_name "DisableRuntimeMarshalling")
		)
	)`

	CA1421 = `(invocation_expression
		function: (member_access_expression
			name: (identifier) @method_name
			(#match? @method_name "MarshalAs|Marshal.SizeOf|Marshal.AllocHGlobal|Marshal.FreeHGlobal")
		)
	)`

	CA1422 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr_name (#eq? @attr_name "DllImport"))
		)
		(parameter_list
			(parameter
				type: (identifier) @delegate_type
				(#match? @delegate_type ".*Callback|.*Handler|.*Delegate")
			)
		)
	)`

	// Maintainability
	CA1501 = `(class_declaration
		base_list: (base_list (identifier)+) @base_class
	)`

	CA1502 = `(method_declaration body: (block
		((if_statement) @complex
		| (switch_statement) @complex
		| (for_statement) @complex
		| (while_statement) @complex
		| (do_statement) @complex)+))`

	CA1505 = ``

	CA1506 = `(class_declaration body: (declaration_list
		(field_declaration (variable_declaration type: (identifier) @used_type)+)
	))`

	CA1507 = `(argument_list (string_literal) @str_arg (#match? @str_arg "\"[a-zA-Z0-9_]+\""))`

	CA1508 = `(if_statement condition: [(true_literal) (false_literal)] @dead_cond)`

	CA1509 = ``

	CA1510 = `(throw_statement (object_creation_expression type: (identifier) @ex_name
		(#eq? @ex_name "ArgumentNullException")))`

	CA1511 = `(throw_statement (object_creation_expression type: (identifier) @ex_name
		(#eq? @ex_name "ArgumentException")))`

	CA1512 = `(throw_statement (object_creation_expression type: (identifier) @ex_name
		(#eq? @ex_name "ArgumentOutOfRangeException")))`

	CA1513 = `(throw_statement (object_creation_expression type: (identifier) @ex_name
		(#eq? @ex_name "ObjectDisposedException")))`

	CA1514 = `(throw_statement (object_creation_expression type: (identifier) @ex_name
		(#eq? @ex_name "InvalidOperationException")))`

	CA1515 = `(class_declaration modifiers: (modifiers (modifier) @vis (#eq? @vis "public")))`

	// Documentation
	CA1200 = `(documentation_comment
		(xml_element
			name: (identifier) @tag_name
			(attribute
				name: (identifier) @attr_name (#eq? @attr_name "cref")
				value: (string_literal) @cref_val (#match? @cref_val "^\"[A-Z]:")
			)
		)
	)`

	// Performance
	CA1802 = `(field_declaration
		(modifiers (modifier) @mod (#match? @mod "static|readonly"))
		(variable_declaration (variable_declarator value: (_) @init))
	)`

	CA1805 = `(field_declaration
		(variable_declaration (variable_declarator value: (default_expression) @default))
	)`

	CA1806 = `(expression_statement
		(invocation_expression) @ignore
	)`

	CA1810 = `(class_declaration
		(constructor_declaration
			(modifiers (modifier) @mod (#eq? @mod "static"))
		) @ctor
	)`

	CA1812 = `(class_declaration
		(modifiers (modifier) @mod (#eq? @mod "internal"))
		name: (identifier) @name
	)`

	CA1813 = `(class_declaration
		name: (identifier) @name
		(attribute_list
			(attribute name: (identifier) @attr (#match? @attr ".*Attribute$"))
		)
		(modifiers (modifier) @mod (#ne? @mod "sealed"))
	)`

	CA1814 = `(array_creation_expression
		(array_type
			dimensions: (array_rank_specifier (number_literal) @rank (#gt? @rank "1"))
		)
	) @mdarray`

	CA1815 = `(struct_declaration name: (identifier) @struct
		(#not-match? @struct "(?s).*Equals.*|operator==")
	)`

	CA1816 = `(method_declaration
		name: (identifier) @name (#eq? @name "Dispose")
		body: (block) @body (#not-match? @body "SuppressFinalize")
	)`

	CA1819 = `(property_declaration
		type: (array_type) @atype
		accessors: (accessor_list
			(get_accessor_declaration
				(return_statement (identifier) @ret)
			)
		)
	)`

	CA1820 = `(invocation_expression
		method: (member_access_expression
			object: (_) @left
			name: (identifier) @m (#eq? @m "Equals")
		)
	)`

	CA1821 = `(destructor_declaration
		name: (identifier) @dtor
		body: (block) @blk (#eq? @blk "{}")
	)`

	CA1822 = `(
		(method_declaration) @m
		| (property_declaration) @p
	)`

	CA1823 = `(field_declaration
		(modifiers (modifier) @mod (#eq? @mod "private"))
	)`

	CA1824 = `(compilation_unit
		(attribute_list
			(attribute name: (identifier) @nrl (#eq? @nrl "NeutralResourcesLanguage"))
		)?
	)`

	CA1825 = `(array_creation_expression
		initializer: (array_initializer (number_literal) @sz (#eq? @sz "0"))
	)`

	CA1826 = `(invocation_expression
		method: (identifier) @linq (#match? @linq "(First|Last|Count)"))`

	CA1827 = `(invocation_expression method: (identifier) @cnt (#match? @cnt "(Count|LongCount)"))`

	CA1828 = `(invocation_expression method: (identifier) @cnt (#match? @cnt "(CountAsync|LongCountAsync)"))`

	CA1829 = `(invocation_expression method: (identifier) @cnt (#eq? @cnt "Count"))`

	CA1830 = `(invocation_expression
		method: (member_access_expression
			object: (identifier) @sb (#eq? @sb "StringBuilder")
			name: (identifier) @m (#match? @m "Append|Insert")
		)
		arguments: (argument_list
			(argument (invocation_expression method: (identifier) @tname (#eq? @tname "ToString")))
		)
	)`

	CA1831 = `(element_access_expression
		(identifier) @idx
	)`
	CA1832 = CA1831
	CA1833 = CA1831

	CA1834 = `(invocation_expression
		method: (member_access_expression
			object: (identifier) @sb (#eq? @sb "StringBuilder")
			name: (identifier) @m (#eq? @m "Append")
		)
		arguments: (argument_list
			(argument (string_literal) @lit (#match? @lit "^\".{1}\"$"))
		)
	)`

	CA1836 = `(invocation_expression method: (identifier) @any (#eq? @any "Any"))`

	CA1837 = `(member_access_expression
		object: (invocation_expression
			method: (member_access_expression
				object: (identifier) @p (#eq? @p "Process")
				name: (identifier) @g (#eq? @g "GetCurrentProcess")))
		name: (identifier) @id (#eq? @id "Id")
	)`

	CA1838 = `(parameter
		type: (qualified_name
			right: (identifier) @t (#eq? @t "StringBuilder"))
	)`

	CA1839 = `(member_access_expression
		object: (member_access_expression
			object: (invocation_expression
				method: (member_access_expression
					object: (identifier) @p (#eq? @p "Process")
					name: (identifier) @g (#eq? @g "GetCurrentProcess")))
			name: (identifier) @mm (#eq? @mm "MainModule"))
		name: (identifier) @fn (#eq? @fn "FileName")
	)`

	CA1840 = `(member_access_expression
		object: (member_access_expression
			object: (identifier) @t (#eq? @t "Thread")
			name: (identifier) @ct (#eq? @ct "CurrentThread"))
		name: (identifier) @mid (#eq? @mid "ManagedThreadId")
	)`

	CA1841 = `(invocation_expression
		method: (member_access_expression
			name: (identifier) @m (#eq? @m "Contains"))
	)`

	CA1842 = `(invocation_expression
		method: (identifier) @m (#eq? @m "WhenAll"))`

	CA1843 = `(invocation_expression
		method: (identifier) @m (#eq? @m "WaitAll"))`

	CA1844 = `(class_declaration
		name: (identifier) @cls
		(#not-match? @cls "ReadAsync|WriteAsync"))`

	CA1845 = `(invocation_expression
		method: (identifier) @concat (#eq? @concat "Concat")
	)`

	CA1846 = `(invocation_expression method: (identifier) @sub (#eq? @sub "Substring"))`

	CA1847 = `(invocation_expression
		method: (member_access_expression name: (identifier) @m (#eq? @m "Contains"))
		arguments: (argument_list (argument (string_literal) @lit (#match? @lit "^\".{1}\"$")))
	)`

	CA1848 = CA1838

	CA1849 = `(method_declaration
		modifiers: (modifiers (modifier) @mod (#eq? @mod "async"))
		body: (block
			(invocation_expression) @inv
		)
	)`

	CA1850 = `(invocation_expression method: (member_access_expression name: (identifier) @m (#eq? @m "ComputeHash"))
	)`

	CA1851 = `(invocation_expression
		method: (identifier) @m (#match? @m "(foreach|Count|Any|ToList)"))`

	CA1852 = `(class_declaration
		modifiers: (modifiers
			(modifier) @mod (#eq? @mod "internal")
			!(modifier) @s (#eq? @s "sealed"))
	)`

	CA1853 = `(invocation_expression method: (identifier) @m1 (#eq? @m1 "ContainsKey"))`

	CA1854 = CA1853

	CA1855 = `(invocation_expression method: (member_access_expression name: (identifier) @m (#eq? @m "Fill"))
	)`

	CA1856 = `(attribute
		name: (identifier) @attr (#eq? @attr "ConstantExpected"))`

	CA1857 = CA1856

	CA1858 = `(invocation_expression
		method: (member_access_expression name: (identifier) @m (#eq? @m "IndexOf"))
	)`

	CA1859 = `(class_declaration
		name: (identifier) @cls
	)`

	CA1860 = CA1836

	CA1861 = `(invocation_expression
		arguments: (argument_list
			(array_creation_expression) @arr
		)
	)`

	CA1862 = `(invocation_expression
		method: (member_access_expression name: (identifier) @m (#match? @m "ToLower|ToUpper"))
	)`

	CA1863 = `(invocation_expression method: (identifier) @f (#match? @f "Format|AppendFormat"))`

	CA1864 = CA1853

	CA1865_CA1867 = CA1834

	CA1868 = CA1841

	CA1869 = `(object_creation_expression type: (identifier) @js (#eq? @js "JsonSerializerOptions"))`

	CA1870 = `(object_creation_expression type: (identifier) @sv (#eq? @sv "SearchValues"))`

	CA1871 = `(invocation_expression
		method: (identifier) @throw (#eq? @throw "ThrowIfNull")
	)`

	CA1872 = `(invocation_expression
		method: (member_access_expression
			object: (invocation_expression method: (member_access_expression name: (identifier) @toStr (#eq? @toStr "ToString")))
			name: (identifier) @replace (#eq? @replace "Replace"))
	)`

	// Security Rules
	CA2300 = `(object_creation_expression type: (identifier) @type (#eq? @type "BinaryFormatter"))`

	CA2301 = `(invocation_expression
		(member_access_expression
			object: (identifier) @formatter (#eq? @formatter "BinaryFormatter")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2302 = `(invocation_expression
		(member_access_expression
			object: (identifier) @formatter (#eq? @formatter "BinaryFormatter")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2305 = `(object_creation_expression type: (identifier) @type (#eq? @type "LosFormatter"))`

	CA2310 = `(object_creation_expression type: (identifier) @type (#eq? @type "NetDataContractSerializer"))`

	CA2311 = `(invocation_expression
		(member_access_expression
			object: (identifier) @serializer (#eq? @serializer "NetDataContractSerializer")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2312 = `(invocation_expression
		(member_access_expression
			object: (identifier) @serializer (#eq? @serializer "NetDataContractSerializer")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2315 = `(object_creation_expression type: (identifier) @type (#eq? @type "ObjectStateFormatter"))`

	CA2321 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "JavaScriptSerializer")
		arguments: (argument_list 
			(argument 
				(object_creation_expression type: (identifier) @resolver (#eq? @resolver "SimpleTypeResolver")))))`

	CA2322 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "JavaScriptSerializer")
		arguments: (argument_list 
			(argument 
				(object_creation_expression type: (identifier) @resolver (#eq? @resolver "SimpleTypeResolver")))))`

	CA2326 = `(member_access_expression 
		name: (identifier) @property (#eq? @property "TypeNameHandling"))`

	CA2327 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "JsonSerializerSettings"))`

	CA2328 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "JsonSerializerSettings"))`

	CA2329 = `(invocation_expression
		(member_access_expression
			object: (identifier) @serializer (#eq? @serializer "JsonSerializer")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2330 = `(invocation_expression
		(member_access_expression
			object: (identifier) @serializer (#eq? @serializer "JsonSerializer")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2350 = `(invocation_expression
		(member_access_expression
			object: (identifier) @table (#eq? @table "DataTable")
			name: (identifier) @method (#eq? @method "ReadXml")))`

	CA2351 = `(invocation_expression
		(member_access_expression
			object: (identifier) @dataset (#eq? @dataset "DataSet")
			name: (identifier) @method (#eq? @method "ReadXml")))`

	CA2352 = `(class_declaration 
		(attribute_list 
			(attribute name: (identifier) @attr (#eq? @attr "Serializable")))
		(declaration_list 
			(field_declaration 
				(variable_declaration 
					type: (identifier) @type (#match? @type "DataSet|DataTable")))))`

	CA2353 = `(class_declaration 
		(attribute_list 
			(attribute name: (identifier) @attr (#match? @attr "XmlType|DataContract")))
		(declaration_list 
			(field_declaration 
				(variable_declaration 
					type: (identifier) @type (#match? @type "DataSet|DataTable")))))`

	CA2354 = `(invocation_expression
		(member_access_expression
			object: (identifier) @formatter (#match? @formatter ".*Formatter")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2355 = `(invocation_expression
		(member_access_expression
			object: (identifier) @formatter (#match? @formatter ".*Formatter")
			name: (identifier) @method (#eq? @method "Deserialize")))`

	CA2356 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr (#match? @attr "WebMethod|OperationContract")))
		(parameter_list
			(parameter
				type: (identifier) @type (#match? @type "DataSet|DataTable"))))`

	CA2361 = `(invocation_expression
		(member_access_expression
			object: (identifier) @dataset (#eq? @dataset "DataSet")
			name: (identifier) @method (#eq? @method "ReadXml")))`

	CA2362 = `(class_declaration 
		(attribute_list 
			(attribute name: (identifier) @attr (#eq? @attr "GeneratedCode")))
		(declaration_list 
			(field_declaration 
				(variable_declaration 
					type: (identifier) @type (#match? @type "DataSet|DataTable")))))`

	CA3001 = `(invocation_expression
		(member_access_expression
			object: (identifier) @cmd (#match? @cmd "SqlCommand|OleDbCommand|OdbcCommand")
			name: (identifier) @method (#eq? @method "Execute")))`

	CA3002 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Write|Response.Write|HtmlEncode")))`

	CA3003 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "File.Open|File.Create|File.Delete|Directory.Create|Directory.Delete")))`

	CA3004 = `(throw_statement 
		(identifier) @ex)`

	CA3006 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Start|Execute")))`

	CA3007 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#eq? @method "Redirect")))`

	CA3008 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Select|SelectNodes|SelectSingleNode")))`

	CA3009 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "LoadXml|Load")))`

	CA3010 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Load|Parse")))`

	CA3011 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Load|LoadFrom")))`

	CA3012 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "IsMatch|Match|Matches")))`

	CA3061 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#eq? @method "Add"))
		arguments: (argument_list 
			(argument (string_literal) @url)))`

	CA3075 = `(member_access_expression 
		name: (identifier) @property (#eq? @property "DtdProcessing"))`

	CA3076 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Load|Transform")))`

	CA3077 = `(class_declaration
		base_list: (base_list
			(base_type
				(identifier) @base (#match? @base "XmlDocument|XmlTextReader")))`

	CA3147 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr (#match? @attr "HttpPost|HttpPut|HttpDelete|HttpPatch")))
		!(attribute_list
			(attribute name: (identifier) @validate (#eq? @validate "ValidateAntiForgeryToken"))))`

	CA5350 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "TripleDES|SHA1|RIPEMD160")))`

	CA5351 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "MD5|DES|RC2")))`

	CA5358 = `(member_access_expression 
		name: (identifier) @mode (#match? @mode "ECB|CBC"))`

	CA5359 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "ServerCertificateValidationCallback"))
		right: (true_literal))`

	CA5360 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Deserialize|FromJson")))`

	CA5361 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "DontEnableSchUseStrongCrypto"))
		right: (true_literal))`

	CA5362 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Deserialize|FromJson")))`

	CA5363 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "ValidateRequest"))
		right: (false_literal))`

	CA5364 = `(member_access_expression 
		name: (identifier) @protocol (#match? @protocol "Ssl3|Tls|Tls11"))`

	CA5365 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "EnableHeaderChecking"))
		right: (false_literal))`

	CA5366 = `(invocation_expression
		(member_access_expression
			object: (identifier) @dataset (#eq? @dataset "DataSet")
			name: (identifier) @method (#eq? @method "ReadXml")))`

	CA5367 = `(class_declaration
		(attribute_list
			(attribute name: (identifier) @attr (#match? @attr "Serializable|DataContract")))
		(declaration_list
			(field_declaration
				type: (pointer_type) @ptr)))`

	CA5368 = `(class_declaration
		base_list: (base_list
			(base_type
				(identifier) @base (#eq? @base "Page")))
		!(declaration_list
			(property_declaration
				name: (identifier) @prop (#eq? @prop "ViewStateUserKey"))))`

	CA5369 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Deserialize|FromXml")))`

	CA5370 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Create|Validate")))`

	CA5371 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Read|Add")))`

	CA5372 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "XPathDocument"))`

	CA5373 = `(object_creation_expression 
		type: (identifier) @type (#match? @type "PasswordDeriveBytes|Rfc2898DeriveBytes"))`

	CA5374 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "XslTransform"))`

	CA5375 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "GetSharedAccessSignature")))`

	CA5376 = `(member_access_expression 
		name: (identifier) @protocol (#eq? @protocol "Http"))`

	CA5377 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "GetSharedAccessSignature")))`

	CA5378 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "DisableUsingServicePointManagerSecurityProtocols"))
		right: (true_literal))`

	CA5379 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "Rfc2898DeriveBytes"))`

	CA5380 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Add|Install")))`

	CA5381 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Add|Install")))`

	CA5382 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Append|Add")))`

	CA5383 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Append|Add")))`

	CA5384 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Create|SignData")))`

	CA5385 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "RSA"))`

	CA5386 = `(member_access_expression 
		name: (identifier) @protocol (#match? @protocol "Tls|Tls11"))`

	CA5387 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "Rfc2898DeriveBytes"))`

	CA5388 = `(object_creation_expression 
		type: (identifier) @type (#eq? @type "Rfc2898DeriveBytes"))`

	CA5389 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "ExtractToDirectory|ExtractToFile")))`

	CA5390 = `(field_declaration
		(variable_declaration 
			type: (identifier) @type (#match? @type "byte|string")
			(variable_declarator value: (string_literal) @key)))`

	CA5391 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr (#match? @attr "HttpPost|HttpPut|HttpDelete|HttpPatch")))
		!(attribute_list
			(attribute name: (identifier) @validate (#eq? @validate "ValidateAntiForgeryToken"))))`

	CA5392 = `(method_declaration
		(attribute_list
			(attribute name: (identifier) @attr (#eq? @attr "DllImport")))
		!(attribute_list
			(attribute name: (identifier) @search (#eq? @search "DefaultDllImportSearchPaths"))))`

	CA5393 = `(attribute_list
		(attribute name: (identifier) @attr (#eq? @attr "DefaultDllImportSearchPaths"))
		(attribute_argument_list
			(attribute_argument
				(identifier) @value (#match? @value "LegacyBehavior|AssemblyDirectory|UseDllDirectoryForDependencies"))))`

	CA5394 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#match? @method "Random|Next")))`

	CA5395 = `(method_declaration
		!(attribute_list
			(attribute name: (identifier) @attr (#match? @attr "HttpGet|HttpPost|HttpPut|HttpDelete|HttpPatch"))))`

	CA5396 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "HttpOnly"))
		right: (false_literal))`

	CA5397 = `(member_access_expression 
		name: (identifier) @protocol (#match? @protocol "Ssl3|Tls|Tls11"))`

	CA5398 = `(member_access_expression 
		name: (identifier) @protocol (#match? @protocol "Tls|Tls11|Tls12"))`

	CA5399 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "CheckCertificateRevocationList"))
		right: (false_literal))`

	CA5400 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#eq? @prop "CheckCertificateRevocationList"))
		right: (false_literal))`

	CA5401 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#eq? @method "CreateEncryptor")))`

	CA5402 = `(invocation_expression 
		(member_access_expression 
			name: (identifier) @method (#eq? @method "CreateEncryptor")))`

	CA5403 = `(object_creation_expression 
		type: (identifier) @type (#match? @type "X509Certificate|X509Certificate2"))`

	CA5404 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#match? @prop "ValidateIssuerSigningKey|ValidateIssuer|ValidateAudience|ValidateLifetime"))
		right: (false_literal))`

	CA5405 = `(assignment_expression
		left: (member_access_expression 
			name: (identifier) @prop (#match? @prop "AudienceValidator|LifetimeValidator"))
		right: (true_literal))`

	// CA2100: Review SQL queries for security vulnerabilities
	// Detects methods that set CommandText property using string arguments
	CA2100 = `
	(method_declaration
		body: (block
			(expression_statement
				(assignment_expression
					left: (member_access_expression
						object: (_)
						name: (identifier) @property_name
						(#eq? @property_name "CommandText"))
					right: (_) @command_text))))`

	// CA2109: Review visible event handlers
	// Detects public or protected event handler methods
	CA2109 = `
	(method_declaration
		modifiers: (modifier_list
			(modifier) @modifier
			(#match? @modifier "public|protected"))
		name: (identifier) @method_name
		(#match? @method_name ".*Handler$"))`

	// CA2119: Seal methods that satisfy private interfaces
	// Detects public types with overridable methods implementing internal interfaces
	CA2119 = `
	(class_declaration
		modifiers: (modifier_list
			(modifier) @class_modifier
			(#match? @class_modifier "public"))
		body: (declaration_list
			(method_declaration
				modifiers: (modifier_list
					(modifier) @method_modifier
					(#match? @method_modifier "virtual|override"))
				name: (identifier) @method_name)))`

	// CA2153: Avoid Handling Corrupted State Exceptions
	// Detects catch blocks handling CorruptedStateException
	CA2153 = `
	(catch_clause
		type: (identifier) @exception_type
		(#eq? @exception_type "CorruptedStateException"))`
)
