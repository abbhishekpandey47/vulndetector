package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
)

// --------------- SIngle File Rules ------------------ //

type IL3000_Rule_SingleFile struct{}

func (r *IL3000_Rule_SingleFile) ID() string    { return "IL3000" }
func (r *IL3000_Rule_SingleFile) Severity() int { return 4 }
func (r *IL3000_Rule_SingleFile) Rule() string {
	return "Avoid accessing Assembly file path when publishing as a single file"
}
func (r *IL3000_Rule_SingleFile) RuleSet() string { return "SingleFile/Publish" }
func (r *IL3000_Rule_SingleFile) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *IL3000_Rule_SingleFile) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(IL3000, "Avoid accessing Assembly file path when publishing as a single file", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type IL3001_Rule_SingleFile struct{}

func (r *IL3001_Rule_SingleFile) ID() string    { return "IL3001" }
func (r *IL3001_Rule_SingleFile) Severity() int { return 4 }
func (r *IL3001_Rule_SingleFile) Rule() string {
	return "Avoid accessing Assembly file path when publishing as a single file"
}
func (r *IL3001_Rule_SingleFile) RuleSet() string { return "SingleFile/Publish" }
func (r *IL3001_Rule_SingleFile) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(IL3001, "Avoid accessing Assembly file path when publishing as a single file", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type IL3002_Rule_SingleFile struct{}

func (r *IL3002_Rule_SingleFile) ID() string    { return "IL3002" }
func (r *IL3002_Rule_SingleFile) Severity() int { return 4 }
func (r *IL3002_Rule_SingleFile) Rule() string {
	return "Avoid calling members annotated with 'RequiresAssemblyFilesAttribute' when publishing as a single file"
}
func (r *IL3002_Rule_SingleFile) RuleSet() string { return "SingleFile/Publish" }
func (r *IL3002_Rule_SingleFile) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(IL3002, "Avoid calling members annotated with 'RequiresAssemblyFilesAttribute' when publishing as a single file", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type IL3003_Rule_SingleFile struct{}

func (r *IL3003_Rule_SingleFile) ID() string    { return "IL3003" }
func (r *IL3003_Rule_SingleFile) Severity() int { return 4 }
func (r *IL3003_Rule_SingleFile) Rule() string {
	return "'RequiresAssemblyFilesAttribute' annotations must match across all interface implementations or overrides"
}
func (r *IL3003_Rule_SingleFile) RuleSet() string { return "SingleFile/Publish" }
func (r *IL3003_Rule_SingleFile) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(IL3003, "'RequiresAssemblyFilesAttribute' annotations must match across all interface implementations or overrides", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type IL3005_Rule_SingleFile struct{}

func (r *IL3005_Rule_SingleFile) ID() string    { return "IL3005" }
func (r *IL3005_Rule_SingleFile) Severity() int { return 4 }
func (r *IL3005_Rule_SingleFile) Rule() string {
	return "RequiresAssemblyFilesAttribute cannot be placed directly on application entry point"
}
func (r *IL3005_Rule_SingleFile) RuleSet() string { return "SingleFile/Publish" }
func (r *IL3005_Rule_SingleFile) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(IL3005, "RequiresAssemblyFilesAttribute cannot be placed directly on application entry point", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}
