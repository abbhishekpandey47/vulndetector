package sca_csharp

import (
	"fmt"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/csharp"
)

type CA1032_Design_Rule struct{}

var CA1032_Rule = &CA1032_Design_Rule{}

func (r *CA1032_Design_Rule) Rule() string    { return "CA1032" }
func (r *CA1032_Design_Rule) RuleSet() string { return "Structure" }
func (r *CA1032_Design_Rule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1032_Design_Rule) Priority() int { return 4 }

func (r *CA1032_Design_Rule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query for constructors
	q, err := sitter.NewQuery([]byte(CA1032), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			// Check if exception constructors are standard
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Implement standard exception constructors.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1070 Rule
type CA1070_Design_Rule struct{}

var CA1070_Rule = &CA1070_Design_Rule{}

func (r *CA1070_Design_Rule) Rule() string    { return "CA1070" }
func (r *CA1070_Design_Rule) RuleSet() string { return "Structure" }
func (r *CA1070_Design_Rule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1070_Design_Rule) Priority() int { return 4 }

func (r *CA1070_Design_Rule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query for event fields declared as virtual
	q, err := sitter.NewQuery([]byte(CA1070), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			// Check if event field is declared as virtual
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Do not declare event fields as virtual.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1047 Rule
type CA1047_Design_Rule struct{}

var CA1047_Rule = &CA1047_Design_Rule{}

func (r *CA1047_Design_Rule) Rule() string    { return "CA1047" }
func (r *CA1047_Design_Rule) RuleSet() string { return "Structure" }
func (r *CA1047_Design_Rule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1047_Design_Rule) Priority() int { return 4 }

func (r *CA1047_Design_Rule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query for protected members in sealed types
	query := `(member_declaration modifiers: (modifiers (protected)) ) @member`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			// Check if protected member is declared in a sealed type
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Do not declare protected member in sealed type.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1000 Rule
type CA1000_Design_Rule struct{}

var CA1000_Rule = &CA1000_Design_Rule{}

func (r *CA1000_Design_Rule) Rule() string    { return "CA1000" }
func (r *CA1000_Design_Rule) RuleSet() string { return "Structure" }
func (r *CA1000_Design_Rule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1000_Design_Rule) Priority() int { return 4 }

func (r *CA1000_Design_Rule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query for static members in generic types
	query := `;; Capture classes that have fields of disposable types
		(class_declaration
		name: (identifier) @class_name
		(declaration_list
			(field_declaration
			(variable_declaration
				type: (identifier) @disposable_type
			)
			)
		)
		(#match? @disposable_type "^(SqlConnection|MemoryStream|FileStream|HttpClient|Stream)$")
		)
		`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			// Check if static members are declared in generic types
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Do not declare static members on generic types.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1001 Rule
type CA1001_Design_Rule struct{}

var CA1001_Rule = &CA1001_Design_Rule{}

func (r *CA1001_Design_Rule) Rule() string    { return "CA1001" }
func (r *CA1001_Design_Rule) RuleSet() string { return "Structure" }
func (r *CA1001_Design_Rule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1001_Design_Rule) Priority() int { return 4 }

func (r *CA1001_Design_Rule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query for types with disposable fields
	query := `(type_declaration) @type`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			// Check if types with disposable fields implement IDisposable
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Types that own disposable fields should be disposable.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1002 Rule
type CA1002_Design_Rule struct{}

var CA1002_Rule = &CA1002_Design_Rule{}

func (r *CA1002_Design_Rule) Rule() string    { return "CA1002" }
func (r *CA1002_Design_Rule) RuleSet() string { return "Structure" }
func (r *CA1002_Design_Rule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1002_Design_Rule) Priority() int { return 4 }

func (r *CA1002_Design_Rule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Query for generic lists exposure
	query := `(generic_list_declaration) @list`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			// Check if generic lists are exposed
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Priority:       r.Priority(),
				Description:    "Do not expose generic lists.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}
