package sca_csharp

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/csharp"
)

type CSharpLanguage struct{}

func (c *CSharpLanguage) Name() string                  { return "csharp" }
func (c *CSharpLanguage) SupportedExtensions() []string { return []string{".cs"} }
func (c *CSharpLanguage) Parse(filePath string) (interface{}, error) {
	code, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	parser := sitter.NewParser()
	parser.SetLanguage(csharp.GetLanguage())
	tree, err := parser.ParseCtx(context.Background(), nil, code)
	if err != nil {
		return nil, err
	}

	return tree, nil
}

func (c *CSharpLanguage) CollectDotNetStats(root *sitter.Tree, src []byte) staticanalyzer.DotNetStats {
	var stats staticanalyzer.DotNetStats
	visited := make(map[*sitter.Node]bool) // Prevent double counting

	var walk func(node *sitter.Node)
	walk = func(node *sitter.Node) {
		if node == nil || visited[node] {
			return
		}
		visited[node] = true

		switch node.Type() {
		case "class_declaration":
			stats.ClassCount++

		case "interface_declaration":
			stats.InterfaceCount++

		case "method_declaration":
			// Only count actual method declarations, not property accessors
			if !isPropertyAccessor(node) {
				stats.MethodCount++
			}

		case "constructor_declaration":
			stats.MethodCount++

		case "struct_declaration":
			stats.StructCount++

		case "enum_declaration":
			stats.EnumCount++

		case "field_declaration":
			// Count each field declarator in the field declaration
			stats.FieldCount += countFieldDeclarators(node)

		case "property_declaration":
			stats.PropertyCount++

		case "event_declaration", "event_field_declaration":
			stats.EventCount++

		case "namespace_declaration":
			stats.NamespaceCount++

		case "parameter":
			// Only count parameters that are direct children of parameter lists
			if node.Parent() != nil && node.Parent().Type() == "parameter_list" {
				stats.ParameterCount++
			}

		case "local_variable_declaration":
			// Count each variable declarator in local declarations
			stats.VariableCount += countVariableDeclarators(node)

		case "variable_declarator":
			// Only count variable declarators that are NOT within field declarations or already counted
			if !isWithinFieldDeclaration(node) && node.Parent() != nil && node.Parent().Type() != "local_variable_declaration" {
				stats.VariableCount++
			}

		case "string_literal":
			stats.StringLiteralCount++

		case "object_creation_expression", "array_creation_expression":
			stats.ObjectCount++
		}

		for i := 0; i < int(node.ChildCount()); i++ {
			walk(node.Child(i))
		}
	}

	walk(root.RootNode())

	// Set file count to 1 since this is per-file analysis
	stats.FileCount = 1

	// Calculate general total count as sum of all tracked metrics
	stats.General = stats.AssemblyCount + stats.ClassCount + stats.EnumCount +
		stats.EventCount + stats.FieldCount + stats.FileCount +
		stats.InterfaceCount + stats.MethodCount + stats.NamespaceCount +
		stats.ObjectCount + stats.ParameterCount + stats.PropertyCount +
		stats.ResourceCount + stats.StringLiteralCount + stats.StructCount +
		stats.VariableCount

	return stats
}

// Helper functions for more precise counting
func isPropertyAccessor(node *sitter.Node) bool {
	// Check if this method is actually a property getter/setter
	if node.Parent() != nil {
		parent := node.Parent()
		for parent != nil {
			if parent.Type() == "property_declaration" {
				return true
			}
			parent = parent.Parent()
		}
	}
	return false
}

func countFieldDeclarators(node *sitter.Node) int {
	count := 0
	var walkDeclarators func(*sitter.Node)
	walkDeclarators = func(n *sitter.Node) {
		if n == nil {
			return
		}
		if n.Type() == "variable_declaration" {
			// Count variable declarators within this field declaration
			for i := 0; i < int(n.ChildCount()); i++ {
				child := n.Child(i)
				if child.Type() == "variable_declarator" {
					count++
				}
			}
		}
		for i := 0; i < int(n.ChildCount()); i++ {
			walkDeclarators(n.Child(i))
		}
	}
	walkDeclarators(node)

	// If no declarators found, assume 1 field
	if count == 0 {
		count = 1
	}
	return count
}

func countVariableDeclarators(node *sitter.Node) int {
	count := 0
	for i := 0; i < int(node.ChildCount()); i++ {
		child := node.Child(i)
		if child.Type() == "variable_declarator" {
			count++
		}
	}
	// If no declarators found, assume 1 variable
	if count == 0 {
		count = 1
	}
	return count
}

// Helper function to check if a node is within a field declaration
func isWithinFieldDeclaration(node *sitter.Node) bool {
	for p := node.Parent(); p != nil; p = p.Parent() {
		if p.Type() == "field_declaration" {
			return true
		}
	}
	return false
}

// Debug function to understand AST structure
func (c *CSharpLanguage) DebugAST(root *sitter.Tree, src []byte) {
	nodeTypes := make(map[string]int)

	var walk func(node *sitter.Node)
	walk = func(node *sitter.Node) {
		if node == nil {
			return
		}
		nodeTypes[node.Type()]++

		for i := 0; i < int(node.ChildCount()); i++ {
			walk(node.Child(i))
		}
	}

	walk(root.RootNode())

	// Print all node types and their counts
	fmt.Println("=== AST NODE TYPES DEBUG ===")
	for nodeType, count := range nodeTypes {
		fmt.Printf("%s: %d\n", nodeType, count)
	}
	fmt.Println("============================")
}

func (j *CSharpLanguage) CollectStats(root *sitter.Tree, src []byte) staticanalyzer.Stats {
	var stats staticanalyzer.Stats

	var walk func(node *sitter.Node)
	walk = func(node *sitter.Node) {
		if node == nil {
			return
		}
		switch node.Type() {
		case "class_declaration":
			stats.ClassCount++
			if hasModifier(node, src, "abstract") {
				stats.AbstractClassCount++
			}
			if hasModifier(node, src, "final") {
				stats.FinalClassCount++
			}
			if hasTypeParameters(node) {
				stats.GenericClassCount++
			}
			if isEJBClass(node, src) {
				stats.EJBClassCount++
			}
			if isPackageProtected(node, src) {
				stats.PackageProtectedClassCount++
			}
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "interface_declaration":
			stats.InterfaceCount++
			if isEJBInterface(node, src) {
				stats.EJBInterfaceCount++
			}
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}
			stats.InterfaceMethodCount += countMethods(node)

		case "method_declaration":
			if hasModifier(node, src, "public") {
				stats.PublicMethodCount++
			} else if hasModifier(node, src, "private") {
				stats.PrivateMethodCount++
			}
			if hasModifier(node, src, "static") && hasModifier(node, src, "public") {
				stats.UtilityMethodCount++
			}
			if hasTypeParameters(node) {
				stats.GenericMethodCount++
			}
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "constructor_declaration":
			stats.ConstructorCount++
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "field_declaration":
			if isConstantField(node, src) {
				stats.ConstantCount++
				if hasModifier(node, src, "public") {
					stats.PublicConstantCount++
				} else if hasModifier(node, src, "private") {
					stats.PrivateConstantCount++
				}
			} else {
				stats.InstanceVariableCount++
			}
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "annotation_type_declaration":
			stats.AnnotationCount++
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "enum_declaration":
			stats.EnumCount++
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "record_declaration":
			stats.RecordCount++
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "local_variable_declaration":
			stats.LocalVariableCount++
			if hasGenericName(node, src) {
				stats.GenericNaming++
			}

		case "static_initializer":
			stats.StaticInitializerCount++
		}

		for i := 0; i < int(node.ChildCount()); i++ {
			walk(node.Child(i))
		}
	}

	walk(root.RootNode())

	// Calculate general total count as sum of all tracked metrics
	stats.General = stats.ClassCount + stats.AbstractClassCount + stats.GenericClassCount +
		stats.EJBInterfaceCount + stats.InterfaceCount + stats.InterfaceMethodCount +
		stats.FinalClassCount + stats.PackageProtectedClassCount + stats.PublicConstantCount +
		stats.PrivateConstantCount + stats.PublicMethodCount + stats.PrivateMethodCount +
		stats.UtilityMethodCount + stats.GenericMethodCount + stats.InstanceVariableCount +
		stats.AnnotationCount + stats.EnumCount + stats.ConstructorCount + stats.RecordCount +
		stats.ConstantCount + stats.StaticInitializerCount + stats.EJBClassCount +
		stats.LocalVariableCount + stats.GenericNaming

	return stats
}

//Collect Metrices

func (c *CSharpLanguage) CollectMetrics(root *sitter.Tree, src []byte) staticanalyzer.FileMetrics {
	var metrics staticanalyzer.FileMetrics
	visited := make(map[*sitter.Node]bool) // Prevent double counting

	cursor := sitter.NewTreeCursor(root.RootNode())
	defer cursor.Close()

	var walk func(n *sitter.Node)
	walk = func(n *sitter.Node) {
		if n == nil || visited[n] {
			return
		}
		visited[n] = true

		switch n.Type() {
		case "method_declaration":
			// Skip property accessors for method counting
			if !isPropertyAccessor(n) {
				if isPublicCS(n, src) {
					metrics.PublicMethodCount++
				} else if isPrivateCS(n, src) {
					metrics.PrivateMethodCount++
				}
				if isStaticCS(n, src) {
					metrics.UtilityMethodCount++
				}
			}

		case "constructor_declaration":
			// Count constructors as methods
			if isPublicCS(n, src) {
				metrics.PublicMethodCount++
			} else if isPrivateCS(n, src) {
				metrics.PrivateMethodCount++
			}

		case "field_declaration":
			fieldCount := countFieldDeclarators(n)

			if isConstantFieldCS(n, src) {
				if isPublicCS(n, src) {
					metrics.PublicConstantCount += fieldCount
				} else if isPrivateCS(n, src) {
					metrics.PrivateConstantCount += fieldCount
				}
			} else {
				// Count as instance variables only if not constants
				metrics.InstanceVariableCount += fieldCount
			}

		case "class_declaration":
			if isInnerClassCS(n) {
				metrics.InnerClassCount++
			}
		}

		for i := 0; i < int(n.ChildCount()); i++ {
			walk(n.Child(i))
		}
	}
	walk(root.RootNode())

	return metrics
}

// --- Helper functions ---

func hasTypeParameters(n *sitter.Node) bool {
	return n.ChildByFieldName("type_parameters") != nil
}

func hasGenericName(n *sitter.Node, src []byte) bool {
	name := n.ChildByFieldName("name")
	if name == nil {
		return false
	}
	nameText := string(name.Content(src))
	return strings.HasPrefix(nameText, "T") || strings.Contains(nameText, "Generic")
}

func isEJBClass(n *sitter.Node, src []byte) bool {
	return strings.HasPrefix(string(n.ChildByFieldName("name").Content(src)), "EJB")
}

func isEJBInterface(n *sitter.Node, src []byte) bool {
	return strings.HasPrefix(string(n.ChildByFieldName("name").Content(src)), "EJB")
}

func isPackageProtected(n *sitter.Node, src []byte) bool {
	return !hasModifier(n, src, "public") && !hasModifier(n, src, "private") && !hasModifier(n, src, "protected")
}

func hasModifier(n *sitter.Node, src []byte, keyword string) bool {
	mods := getModifiers(n)
	for _, mod := range mods {
		if string(mod.Content(src)) == keyword {
			return true
		}
	}
	return false
}

func getModifiers(n *sitter.Node) []*sitter.Node {
	for i := 0; i < int(n.ChildCount()); i++ {
		if n.Child(i).Type() == "modifiers" {
			return children(n.Child(i))
		}
	}
	return nil
}

func children(n *sitter.Node) []*sitter.Node {
	var result []*sitter.Node
	for i := 0; i < int(n.ChildCount()); i++ {
		result = append(result, n.Child(i))
	}
	return result
}

func isConstantField(n *sitter.Node, src []byte) bool {
	return hasModifier(n, src, "static") && hasModifier(n, src, "final")
}

func countMethods(n *sitter.Node) int {
	count := 0
	for i := 0; i < int(n.ChildCount()); i++ {
		if n.Child(i).Type() == "method_declaration" {
			count++
		}
	}
	return count
}

func (c *CSharpLanguage) GetRules() []staticanalyzer.Rule {
	return []staticanalyzer.Rule{
		EnumZeroValueRule,
		AttributeAccessorRule,
		AvoidOutParamsRule,
		EmptyInterfaceRule,
		OperatorOverloadEqualsRule,
		VisibleInstanceFieldsRule,
		StaticHolderShouldBeStaticRule,
		UriStringPropertyRule,
		EnumNoDuplicateValueRule,
		AvoidCrefPrefixRule,
		UseNameofRule,
		FlagsEnumPluralNameRule,
		EnumPluralNameWithoutFlagsRule,
		PascalCasePlaceholdersRule,
		AbstractPublicConstructorRule,
		NoUnnecessaryInitializationRule,
		IgnoreMethodResultRule,
		StaticConstructorRule,
		ArrayPropertyRule,

		&MethodRule{},
		&ConsoleWriteLineRule{},
		&CommentedOutCodeRule{},

		&CA1303_Rule_Globalization{},
		&CA1304_Rule_Globalization{},
		&CA1305_Rule_Globalization{},
		&CA1307_Rule_Globalization{},
		&CA1308_Rule_Globalization{},
		&CA1309_Rule_Globalization{},
		&CA1310_Rule_Globalization{},
		&CA1311_Rule_Globalization{},
		&CA1312_Rule_Globalization{},

		&CA2000_Rule_Reliability{},
		// &CA2002_Rule_Reliability{}, // issue : invalid node type 'this' at line 2 column 0
		&CA2007_Rule_Reliability{},
		// &CA2008_Rule_Reliability{}, // issue : invalid field 'object' at line 3 column 0 and invalid field 'object' at line 4 column 0
		&CA2009_Rule_Reliability{},
		&CA2011_Rule_Reliability{},
		&CA2012_Rule_Reliability{},
		&CA2013_Rule_Reliability{},
		// &CA2014_Rule_Reliability{}, // issue : invalid unknown at line 4 column 0 (array_creation_expression) @alloc)))
		// &CA2015_Rule_Reliability{}, // issue : invalid node type 'base_type' at line 3 column 0
		&CA2016_Rule_Reliability{},
		&CA2017_Rule_Reliability{},
		//&CA2018_Rule_Reliability{}, // issue : invalid field 'object' at line 3 column 0
		&CA2019_Rule_Reliability{},
		&CA2020_Rule_Reliability{},
		//&CA2021_Rule_Reliability{}, // issue : invalid syntax at line 4 column 1
		&CA2022_Rule_Reliability{},
		&CA2024_Rule_Reliability{},

		&CA1700_Rule_Naming{},
		&CA1707_Rule_Naming{},
		&CA1708_Rule_Naming{},
		&CA1710_Rule_Naming{},
		&CA1711_Rule_Naming{},
		&CA1712_Rule_Naming{},
		&CA1713_Rule_Naming{},
		&CA1714_Rule_Naming{},
		&CA1715_Rule_Naming{},
		&CA1716_Rule_Naming{},
		&CA1717_Rule_Naming{},
		&CA1720_Rule_Naming{},
		&CA1721_Rule_Naming{},
		&CA1724_Rule_Naming{},
		&CA1725_Rule_Naming{},
		&CA1727_Rule_Naming{},

		&IL3000_Rule_SingleFile{},
		&IL3001_Rule_SingleFile{},
		&IL3002_Rule_SingleFile{},
		&IL3003_Rule_SingleFile{},
		&IL3005_Rule_SingleFile{},

		&CA1401_Rule_Interop{},
		&CA1416_Rule_Interop{},
		&CA1417_Rule_Interop{},
		&CA1418_Rule_Interop{},
		&CA1419_Rule_Interop{},
		&CA1420_Rule_Interop{},
		&CA1421_Rule_Interop{},
		&CA1422_Rule_Interop{},

		&CA1501_Rule_Maintainability{},
		&CA1502_Rule_Maintainability{},
		&CA1506_Rule_Maintainability{},
		&CA1507_Rule_Maintainability{},
		&CA1508_Rule_Maintainability{},
		&CA1510_Rule_Maintainability{},
		&CA1511_Rule_Maintainability{},
		&CA1512_Rule_Maintainability{},
		&CA1513_Rule_Maintainability{},
		&CA1514_Rule_Maintainability{},
		&CA1515_Rule_Maintainability{},

		&CA1200_Rule_Documentation{},

		&CA1802_Rule_Performance{},
		&CA1805_Rule_Performance{},
		&CA1806_Rule_Performance{},
		&CA1810_Rule_Performance{},
		&CA1812_Rule_Performance{},
		&CA1813_Rule_Performance{},
		&CA1814_Rule_Performance{},
		&CA1815_Rule_Performance{},
		&CA1816_Rule_Performance{},
		&CA1819_Rule_Performance{},
		&CA1820_Rule_Performance{},
		&CA1821_Rule_Performance{},
		&CA1822_Rule_Performance{},
		&CA1823_Rule_Performance{},
		&CA1824_Rule_Performance{},
		&CA1825_Rule_Performance{},
		&CA1826_Rule_Performance{},
		&CA1827_Rule_Performance{},
		&CA1828_Rule_Performance{},
		&CA1829_Rule_Performance{},
		&CA1830_Rule_Performance{},
		&CA1831_Rule_Performance{},
		&CA1832_Rule_Performance{},
		&CA1833_Rule_Performance{},
		&CA1834_Rule_Performance{},
		&CA1836_Rule_Performance{},
		&CA1837_Rule_Performance{},
		&CA1838_Rule_Performance{},
		&CA1839_Rule_Performance{},
		&CA1840_Rule_Performance{},
		&CA1841_Rule_Performance{},
		&CA1842_Rule_Performance{},
		&CA1843_Rule_Performance{},
		&CA1844_Rule_Performance{},
		&CA1845_Rule_Performance{},
		&CA1846_Rule_Performance{},
		&CA1847_Rule_Performance{},
		&CA1848_Rule_Performance{},
		&CA1849_Rule_Performance{},
		&CA1850_Rule_Performance{},
		&CA1851_Rule_Performance{},
		&CA1852_Rule_Performance{},
		&CA1854_Rule_Performance{},
		&CA1855_Rule_Performance{},
		&CA1856_Rule_Performance{},
		&CA1858_Rule_Performance{},
		&CA1859_Rule_Performance{},
		&CA1860_Rule_Performance{},
		&CA1861_Rule_Performance{},
		&CA1862_Rule_Performance{},
		&CA1863_Rule_Performance{},
		&CA1864_Rule_Performance{},
		&CA1865ToCA1867_Rule_Performance{},
		&CA1868_Rule_Performance{},
		&CA1869_Rule_Performance{},
		&CA1870_Rule_Performance{},
		&CA1871_Rule_Performance{},
		&CA1872_Rule_Performance{},

		&CA2300_Rule_Security{},
		&CA2301_Rule_Security{},
		&CA2302_Rule_Security{},
		&CA2305_Rule_Security{},
		&CA2310_Rule_Security{},
		&CA2311_Rule_Security{},
		&CA2312_Rule_Security{},
		&CA2315_Rule_Security{},
		&CA2321_Rule_Security{},
		&CA2322_Rule_Security{},
		&CA2326_Rule_Security{},
		&CA2327_Rule_Security{},
		&CA2328_Rule_Security{},
		&CA2329_Rule_Security{},
		&CA2330_Rule_Security{},
		&CA2350_Rule_Security{},
		&CA2351_Rule_Security{},
		&CA2352_Rule_Security{},
		&CA2353_Rule_Security{},
		&CA2354_Rule_Security{},
		&CA2355_Rule_Security{},
		&CA2356_Rule_Security{},
		&CA2361_Rule_Security{},
		&CA2362_Rule_Security{},
		&CA3001_Rule_Security{},
		&CA3002_Rule_Security{},
		&CA3003_Rule_Security{},
		&CA3004_Rule_Security{},
		&CA3006_Rule_Security{},
		&CA3007_Rule_Security{},
		&CA3008_Rule_Security{},
		&CA3009_Rule_Security{},
		&CA3010_Rule_Security{},
		&CA3011_Rule_Security{},
		&CA3012_Rule_Security{},
		&CA3061_Rule_Security{},
		&CA3075_Rule_Security{},
		&CA3076_Rule_Security{},
		&CA3077_Rule_Security{},
		&CA3147_Rule_Security{},
		&CA5350_Rule_Security{},
		&CA5351_Rule_Security{},
		&CA5358_Rule_Security{},
		&CA5359_Rule_Security{},
		&CA5360_Rule_Security{},
		&CA5361_Rule_Security{},
		&CA5362_Rule_Security{},
		&CA5363_Rule_Security{},
		&CA5364_Rule_Security{},
		&CA5365_Rule_Security{},
		&CA5366_Rule_Security{},
		&CA5367_Rule_Security{},
		&CA5368_Rule_Security{},
		&CA5369_Rule_Security{},
		&CA5370_Rule_Security{},
		&CA5371_Rule_Security{},
		&CA5372_Rule_Security{},
		&CA5373_Rule_Security{},
		&CA5374_Rule_Security{},
		&CA5375_Rule_Security{},
		&CA5376_Rule_Security{},
		&CA5377_Rule_Security{},
		&CA5378_Rule_Security{},
		&CA5379_Rule_Security{},
		&CA5380_Rule_Security{},
		&CA5381_Rule_Security{},
		&CA5382_Rule_Security{},
		&CA5383_Rule_Security{},
		&CA5384_Rule_Security{},
		&CA5385_Rule_Security{},
		&CA5386_Rule_Security{},
		&CA5387_Rule_Security{},
		&CA5388_Rule_Security{},
		&CA5389_Rule_Security{},
		&CA5390_Rule_Security{},
		&CA5391_Rule_Security{},
		&CA5392_Rule_Security{},
		&CA5393_Rule_Security{},
		&CA5394_Rule_Security{},
		&CA5395_Rule_Security{},
		&CA5396_Rule_Security{},
		&CA5397_Rule_Security{},
		&CA5398_Rule_Security{},
		&CA5399_Rule_Security{},
		&CA5400_Rule_Security{},
		&CA5401_Rule_Security{},
		&CA5402_Rule_Security{},
		&CA5403_Rule_Security{},
		&CA5404_Rule_Security{},
		&CA5405_Rule_Security{},
		&CA2100_Rule_Security{},
		&CA2109_Rule_Security{},
		&CA2119_Rule_Security{},
		&CA2153_Rule_Security{},
	}
}

// --- Helper functions for C# specific syntax ---

func hasModifierCS(n *sitter.Node, src []byte, keyword string) bool {
	// Check for modifiers in the current node and its children
	var checkNode func(*sitter.Node) bool
	checkNode = func(node *sitter.Node) bool {
		if node == nil {
			return false
		}

		// Check if this node is a modifier
		if node.Type() == "modifier" || node.Type() == "public" || node.Type() == "private" ||
			node.Type() == "protected" || node.Type() == "static" || node.Type() == "const" ||
			node.Type() == "readonly" || node.Type() == "virtual" || node.Type() == "override" {
			nodeText := string(node.Content(src))
			if nodeText == keyword {
				return true
			}
		}

		// Check children
		for i := 0; i < int(node.ChildCount()); i++ {
			if checkNode(node.Child(i)) {
				return true
			}
		}
		return false
	}

	return checkNode(n)
}

func isPublicCS(n *sitter.Node, src []byte) bool {
	return hasModifierCS(n, src, "public")
}

func isPrivateCS(n *sitter.Node, src []byte) bool {
	return hasModifierCS(n, src, "private")
}

func isStaticCS(n *sitter.Node, src []byte) bool {
	return hasModifierCS(n, src, "static")
}

func isConstantFieldCS(n *sitter.Node, src []byte) bool {
	// In C#, constants are declared with 'const' keyword
	return hasModifierCS(n, src, "const")
}

func isInnerClassCS(n *sitter.Node) bool {
	// Check if this class is nested inside another class or struct
	for p := n.Parent(); p != nil; p = p.Parent() {
		if p.Type() == "class_declaration" || p.Type() == "struct_declaration" || p.Type() == "interface_declaration" {
			return true
		}
	}
	return false
}
