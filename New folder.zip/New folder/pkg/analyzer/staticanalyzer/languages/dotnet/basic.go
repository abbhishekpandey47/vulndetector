package sca_csharp

import (
	"fmt"
	"log"
	"regexp"
	"strconv"
	"strings"
	"unicode"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/csharp"
	cs "github.com/smacker/go-tree-sitter/csharp"
)

// Methods should have XML documentation
type MethodRule struct{}

func (r *MethodRule) Rule() string    { return "CSHARP-002" }
func (r *MethodRule) RuleSet() string { return "info" }
func (r *MethodRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *MethodRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := "(method_declaration name: (identifier) @method.name)"
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			prev := node.PrevSibling()
			if prev == nil || prev.Type() != "comment" {
				methodName := string(source[node.StartByte():node.EndByte()])
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    fmt.Sprintf("Method '%s' is missing XML documentation.", methodName),
					BeginLine:      int(node.StartPoint().Row + 1),
					BeginColumn:    int(node.StartPoint().Column + 1),
					EndLine:        int(node.EndPoint().Row + 1),
					EndColumn:      int(node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

// Console.WriteLine usage detection
type ConsoleWriteLineRule struct{}

func (r *ConsoleWriteLineRule) Rule() string    { return "CSHARP-016" }
func (r *ConsoleWriteLineRule) RuleSet() string { return "warning" }
func (r *ConsoleWriteLineRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *ConsoleWriteLineRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(invocation_expression
		function: (member_access_expression
			expression: (identifier) @class
			name: (identifier) @method
		)
	) @call
	`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var className, methodName string
		for _, cap := range match.Captures {
			captureName := q.CaptureNameForId(cap.Index)
			if captureName == "class" {
				className = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			}
			if captureName == "method" {
				methodName = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			}
		}

		if className == "Console" && methodName == "WriteLine" {
			callNode := match.Captures[0].Node
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Avoid using Console.WriteLine; use a proper logging framework instead.",
				BeginLine:      int(callNode.StartPoint().Row + 1),
				BeginColumn:    int(callNode.StartPoint().Column + 1),
				EndLine:        int(callNode.EndPoint().Row + 1),
				EndColumn:      int(callNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// Commented out code detection
type CommentedOutCodeRule struct{}

func (r *CommentedOutCodeRule) Rule() string    { return "CSHARP-019" }
func (r *CommentedOutCodeRule) RuleSet() string { return "info" }
func (r *CommentedOutCodeRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CommentedOutCodeRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(comment) @comment`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			commentText := string(source[cap.Node.StartByte():cap.Node.EndByte()])
			if looksLikeCode(commentText) {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Comment may contain commented-out code. Consider removing or cleaning it.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

func looksLikeCode(comment string) bool {
	return strings.Contains(comment, ";") || strings.Contains(comment, "{") || strings.Contains(comment, "}")
}

// CA1008: Enums should have zero value
type enumZeroValueRule struct{}

var EnumZeroValueRule = &enumZeroValueRule{}

func (r *enumZeroValueRule) Rule() string    { return "Enums should have zero value" }
func (r *enumZeroValueRule) RuleSet() string { return "Structure" }
func (r *enumZeroValueRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *enumZeroValueRule) Priority() int { return 3 }

func (r *enumZeroValueRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	queryStr := `
			(
			(enum_declaration
				name: (identifier) @enum_name
				(enum_member_declaration_list
					(enum_member_declaration
						name: (identifier) @member_name
						("=" (integer_literal) @member_value)?
					)*
				)
				(attribute_list
					(attribute
						name: (identifier) @attribute_name
					)
				)* @attribute_list
			) @enum_declaration
          )`

	q, err := sitter.NewQuery([]byte(queryStr), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var enumName string
		var isFlags bool
		var hasZeroValue bool
		var zeroValueMember string
		var enumNode *sitter.Node
		memberValues := make(map[string]string)

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)
			switch captureName {
			case "enum_name":
				enumName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
				enumNode = capture.Node.Parent()
			case "attribute_name":
				attrName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if attrName == "Flags" || attrName == "System.Flags" {
					isFlags = true
				}
			case "member_name":
				memberName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if memberName == "None" {
					zeroValueMember = memberName
				}
			case "member_value":
				value := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				memberValues[value] = string(source[capture.Node.Parent().Child(0).StartByte():capture.Node.Parent().Child(0).EndByte()])
				if value == "0" {
					hasZeroValue = true
					zeroValueMember = string(source[capture.Node.Parent().Child(0).StartByte():capture.Node.Parent().Child(0).EndByte()])
				}
			}
		}

		//Check for violations
		if !hasZeroValue {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Description:    "Enum '" + enumName + "' should have a zero-valued member",
				Classification: r.Classification(),
				Priority:       r.Priority(),
				BeginLine:      int(enumNode.StartPoint().Row + 1),
				BeginColumn:    int(enumNode.StartPoint().Column + 1),
				EndLine:        int(enumNode.EndPoint().Row + 1),
				EndColumn:      int(enumNode.EndPoint().Column + 1),
			})
		} else if isFlags {
			// For Flags enums, check if zero is named 'None' and is unique
			if zeroValueMember != "None" {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Description:    "Flags enum '" + enumName + "' should name its zero-values member 'None'",
					Classification: r.Classification(),
					Priority:       r.Priority(),
					BeginLine:      int(enumNode.StartPoint().Row + 1),
					BeginColumn:    int(enumNode.StartPoint().Column + 1),
					EndLine:        int(enumNode.EndPoint().Row + 1),
					EndColumn:      int(enumNode.EndPoint().Column + 1),
				})
			}

			// Check for multiple zero values (only if we have explicit values)
			if len(memberValues) > 0 {
				zeroCount := 0
				for val := range memberValues {
					if val == "0" {
						zeroCount++
						if zeroCount > 1 {
							issues = append(issues, core.Issue{
								Rule:           r.Rule(),
								RuleSet:        r.RuleSet(),
								Description:    "Flags enum '" + enumName + "' should have only one zero-valued member",
								Classification: r.Classification(),
								Priority:       r.Priority(),
								BeginLine:      int(enumNode.StartPoint().Row + 1),
								BeginColumn:    int(enumNode.StartPoint().Column + 1),
								EndLine:        int(enumNode.EndPoint().Row + 1),
								EndColumn:      int(enumNode.EndPoint().Column + 1),
							})
							break
						}
					}
				}
			}
		}
	}

	if len(issues) > 0 {
		log.Printf("Found %d CA1008 violations", len(issues))
	}

	return issues
}

// CA1012: Abstract types should not have public constructors
type abstractPublicConstructorRule struct{}

var AbstractPublicConstructorRule = &abstractPublicConstructorRule{}

func (r *abstractPublicConstructorRule) Rule() string {
	return "Abstract types should not have public constructors"
}
func (r *abstractPublicConstructorRule) RuleSet() string { return "Structure" }
func (r *abstractPublicConstructorRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *abstractPublicConstructorRule) Priority() int { return 4 }

func (r *abstractPublicConstructorRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	//Find Abstract Classes
	abstractClassQuery := `(
				class_declaration
					(modifier "abstract") @abstract_keyword
					name: (identifier) @class_name
				)@abstract_class`

	publicCtorQuery := `(
				(class_declaration
						body: (declaration_list
						(constructor_declaration
							(modifier "public") @public_modifier
							name: (identifier) @constructor_name
						) @public_ctor
					)
				)
			)`

	//find all abstract classes
	abstractClasses := make(map[string]struct{})
	q1, err := sitter.NewQuery([]byte(abstractClassQuery), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q1.Close()
	cursor1 := sitter.NewQueryCursor()
	defer cursor1.Close()
	cursor1.Exec(q1, root)

	for {
		match, ok := cursor1.NextMatch()
		if !ok {
			break
		}

		for _, capture := range match.Captures {
			if q1.CaptureNameForId(capture.Index) == "class_name" {
				className := strings.TrimSpace(string(source[capture.Node.StartByte():capture.Node.EndByte()]))
				abstractClasses[className] = struct{}{}
				break
			}
		}
	}

	//Find public constructors in abstract classes
	q2, err := sitter.NewQuery([]byte(publicCtorQuery), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q2.Close()
	cursor2 := sitter.NewQueryCursor()
	defer cursor2.Close()
	cursor2.Exec(q2, root)

	for {
		match, ok := cursor2.NextMatch()
		if !ok {
			break
		}

		var classNameForCtor string
		var ctorIdentifierNode *sitter.Node

		for _, capture := range match.Captures {
			if q2.CaptureNameForId(capture.Index) == "constructor_name" {
				ctorIdentifierNode = capture.Node
				classNameForCtor = strings.TrimSpace(string(source[capture.Node.StartByte():capture.Node.EndByte()]))
				break
			}
		}

		if classNameForCtor != "" && ctorIdentifierNode != nil {
			if _, isAbstract := abstractClasses[classNameForCtor]; isAbstract {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Description:    "Abstract types should not have public constructors",
					Classification: r.Classification(),
					Priority:       r.Priority(),
					BeginLine:      int(ctorIdentifierNode.StartPoint().Row + 1),
					BeginColumn:    int(ctorIdentifierNode.StartPoint().Column + 1),
					EndLine:        int(ctorIdentifierNode.EndPoint().Row + 1),
					EndColumn:      int(ctorIdentifierNode.EndPoint().Column + 1),
				})
			}
		}
	}
	return issues
}

// CA1019: Define accessors for attribute arguments
type attributeAccessorRule struct{}

var AttributeAccessorRule = &attributeAccessorRule{}

func (r *attributeAccessorRule) Rule() string {
	return "Define accessors for attribute arguments"
}
func (r *attributeAccessorRule) RuleSet() string { return "Structure" }
func (r *attributeAccessorRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *attributeAccessorRule) Priority() int { return 3 }

func (r *attributeAccessorRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	queryStr := `
		(
			(class_declaration
				(identifier) @class_name
				(base_list
				(identifier) @base_type
				)?
				(attribute_list)* @class_attributes
				body: (declaration_list
				(constructor_declaration
					(parameter_list
					(parameter
						type: (type) @param_type
						name: (identifier) @param_name
					)+
					) @constructor_params
				)+
				(property_declaration
				(identifier) @property_name
				)*
				) @class_body
			) @class_declaration
		)`

	q, err := sitter.NewQuery([]byte(queryStr), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var className string
		var isAttribute bool
		var constructorParams []string
		var properties []string
		var classNode *sitter.Node

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)
			switch captureName {
			case "class_name":
				className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
				classNode = capture.Node.Parent()
			case "base_type":
				baseType := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if baseType == "Attribute" || strings.HasSuffix(baseType, ".Attribute") {
					isAttribute = true
				}
			case "param_name":
				paramName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				constructorParams = append(constructorParams, paramName)
			case "property_name":
				propName := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				properties = append(properties, propName)
			}
		}

		if isAttribute {
			for _, param := range constructorParams {
				found := false
				expectedProp := toProperPascalCase(param)

				for _, prop := range properties {
					if strings.EqualFold(prop, param) || prop == expectedProp {
						found = true
						break
					}
				}

				if !found {
					issues = append(issues, core.Issue{
						Rule:           r.Rule(),
						RuleSet:        r.RuleSet(),
						Description:    "Attribute '" + className + "' is missing property accessor for constructor parameter '" + param + "' (expected '" + expectedProp + "')",
						Classification: r.Classification(),
						Priority:       r.Priority(),
						BeginLine:      int(classNode.StartPoint().Row + 1),
						BeginColumn:    int(classNode.StartPoint().Column + 1),
						EndLine:        int(classNode.EndPoint().Row + 1),
						EndColumn:      int(classNode.EndPoint().Column + 1),
					})
				}
			}
		}
	}

	if len(issues) > 0 {
		log.Printf("Found %d CA1019 violations", len(issues))
	}

	return issues
}

func toProperPascalCase(s string) string {
	if len(s) == 0 {
		return s
	}

	if strings.EqualFold(s, "id") {
		return "Id"
	}

	if strings.EqualFold(s, "url") {
		return "Url"
	}

	if strings.EqualFold(s, "ip") {
		return "Ip"
	}

	return strings.ToUpper(s[:1]) + s[1:]
}

// CA1021: Avoid out parameters.
type avoidOutParamsRule struct{}

var AvoidOutParamsRule = &avoidOutParamsRule{}

func (r *avoidOutParamsRule) Rule() string {
	return "Avoid out parameters"
}
func (r *avoidOutParamsRule) RuleSet() string { return "Structure" }
func (r *avoidOutParamsRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *avoidOutParamsRule) Priority() int { return 3 }

func (r *avoidOutParamsRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	queryStr := `
		(
			(method_declaration
				name: (identifier) @method_name
				(parameter_list
					(parameter
						(modifier) @param_modifier
						name: (identifier) @param_name
					)*
				)
			) @method
		)
	`

	q, err := sitter.NewQuery([]byte(queryStr), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var outParams []string
		var methodNode *sitter.Node
		var methodName string

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)

			switch captureName {
			case "method":
				methodNode = capture.Node

			case "method_name":
				methodName = string(source[capture.Node.StartByte():capture.Node.EndByte()])

			case "param_modifier":
				modifier := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				if modifier == "out" || modifier == "ref" {
					paramNode := capture.Node.Parent()
					paramName := ""
					if paramNode != nil {
						nameNode := paramNode.ChildByFieldName("name")
						if nameNode != nil {
							paramName = string(source[nameNode.StartByte():nameNode.EndByte()])
						}
					}
					outParams = append(outParams, modifier+" "+paramName)
				}
			}
		}

		if len(outParams) > 0 && methodNode != nil {
			message := fmt.Sprintf(
				"Method '%s' should avoid using out/ref parameters: %s",
				methodName, strings.Join(outParams, ", "),
			)

			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Description:    message,
				Classification: r.Classification(),
				Priority:       r.Priority(),
				BeginLine:      int(methodNode.StartPoint().Row + 1),
				BeginColumn:    int(methodNode.StartPoint().Column + 1),
				EndLine:        int(methodNode.EndPoint().Row + 1),
				EndColumn:      int(methodNode.EndPoint().Column + 1),
			})
		}
	}

	if len(issues) > 0 {
		log.Printf("Found %d CA1021 violations", len(issues))
	}

	return issues
}

// CA1040: Avoid empty interfaces.
type emptyInterfaceRule struct{}

var EmptyInterfaceRule = &emptyInterfaceRule{}

func (r *emptyInterfaceRule) Rule() string {
	return "Avoid empty interfaces"
}
func (r *emptyInterfaceRule) RuleSet() string { return "Structure" }
func (r *emptyInterfaceRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *emptyInterfaceRule) Priority() int { return 2 }

// Analyze identifies empty interfaces in the given AST.
func (r *emptyInterfaceRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	emptyInterfaceQuery := `(
		interface_declaration
			name: (identifier) @interface_name
			body: (declaration_list)? @body
	)`

	q, err := sitter.NewQuery([]byte(emptyInterfaceQuery), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var interfaceName string
		var bodyNode *sitter.Node

		for _, capture := range match.Captures {
			switch q.CaptureNameForId(capture.Index) {
			case "interface_name":
				interfaceName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "body":
				bodyNode = capture.Node
			}
		}

		// If bodyNode is nil or has no children (i.e., empty body)
		if bodyNode == nil || bodyNode.NamedChildCount() == 0 {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Description:    "Interface is empty," + interfaceName,
				Classification: r.Classification(),
				Priority:       r.Priority(),
				BeginLine:      int(bodyNode.StartPoint().Row + 1),
				BeginColumn:    int(bodyNode.StartPoint().Column + 1),
				EndLine:        int(bodyNode.EndPoint().Row + 1),
				EndColumn:      int(bodyNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1046: Do not overload operator == on reference types
type operatorOverloadEqualsRule struct{}

var OperatorOverloadEqualsRule = &operatorOverloadEqualsRule{}

func (r *operatorOverloadEqualsRule) Rule() string {
	return "Do not overload operator == on reference types"
}
func (r *operatorOverloadEqualsRule) RuleSet() string { return "Structure" }
func (r *operatorOverloadEqualsRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *operatorOverloadEqualsRule) Priority() int { return 3 }

func (r *operatorOverloadEqualsRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(
		class_declaration
			name: (identifier) @class_name
			body: (declaration_list
				(operator_declaration
					operator: "==" @eq_operator
				)
			)
	)
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return issues
	}

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var className string
		var operatorNode *sitter.Node

		for _, capture := range match.Captures {
			switch q.CaptureNameForId(capture.Index) {
			case "class_name":
				className = strings.TrimSpace(string(source[capture.Node.StartByte():capture.Node.EndByte()]))
			case "eq_operator":
				operatorNode = capture.Node
			}
		}

		if className != "" && operatorNode != nil {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Description:    "Do not overload operator == on reference types",
				Classification: r.Classification(),
				Priority:       r.Priority(),
				BeginLine:      int(operatorNode.StartPoint().Row + 1),
				BeginColumn:    int(operatorNode.StartPoint().Column + 1),
				EndLine:        int(operatorNode.EndPoint().Row + 1),
				EndColumn:      int(operatorNode.EndPoint().Column + 1),
			})
			log.Printf("CA1046 violation in class '%s' at line %d", className, operatorNode.StartPoint().Row+1)
		}
	}

	return issues
}

// CA1051: Do not declare visible instance fields
type visibleInstanceFieldsRule struct{}

var VisibleInstanceFieldsRule = &visibleInstanceFieldsRule{}

func (r *visibleInstanceFieldsRule) Rule() string {
	return "Do not declare visible instance fields"
}
func (r *visibleInstanceFieldsRule) RuleSet() string { return "Structure" }
func (r *visibleInstanceFieldsRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *visibleInstanceFieldsRule) Priority() int { return 3 }

func (r *visibleInstanceFieldsRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
		(field_declaration
			(modifier)* @modifiers
			(variable_declaration
				type: (_) 
				(variable_declarator (identifier) @field_name)
			)
		) @field_decl
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var fieldName string
		var isVisible bool
		var fieldNode *sitter.Node

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)
			switch captureName {
			case "modifiers":
				mod := strings.TrimSpace(string(source[capture.Node.StartByte():capture.Node.EndByte()]))
				if mod == "public" || mod == "protected" || mod == "protected internal" {
					isVisible = true
				}
			case "field_name":
				fieldName = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "field_decl":
				fieldNode = capture.Node
			}
		}

		if isVisible && fieldName != "" && fieldNode != nil {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Description:    "Instance field '" + fieldName + "' should not be public or protected",
				Classification: r.Classification(),
				Priority:       r.Priority(),
				BeginLine:      int(fieldNode.StartPoint().Row + 1),
				BeginColumn:    int(fieldNode.StartPoint().Column + 1),
				EndLine:        int(fieldNode.EndPoint().Row + 1),
				EndColumn:      int(fieldNode.EndPoint().Column + 1),
			})
		}
	}

	if len(issues) > 0 {
		log.Printf("Found %d CA1051 violations", len(issues))
	}

	return issues
}

// CA1052: Static holder types should be Static or NotInheritable
type staticHolderShouldBeStaticRule struct{}

var StaticHolderShouldBeStaticRule = &staticHolderShouldBeStaticRule{}

func (r *staticHolderShouldBeStaticRule) Rule() string {
	return "Static holder types should be Static or NotInheritable"
}
func (r *staticHolderShouldBeStaticRule) RuleSet() string { return "Structure" }
func (r *staticHolderShouldBeStaticRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *staticHolderShouldBeStaticRule) Priority() int { return 4 }

func (r *staticHolderShouldBeStaticRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(
	class_declaration
		(modifier)* @modifiers
		name: (identifier) @name
		(declaration_list)? @body
	) @class
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var (
			className  string
			bodyNode   *sitter.Node
			classNode  *sitter.Node
			isPublic   bool
			isStatic   bool
			isAbstract bool
		)

		for _, capture := range match.Captures {
			captureName := q.CaptureNameForId(capture.Index)
			switch captureName {
			case "name":
				className = string(source[capture.Node.StartByte():capture.Node.EndByte()])
			case "modifiers":
				mod := string(source[capture.Node.StartByte():capture.Node.EndByte()])
				switch mod {
				case "public", "protected":
					isPublic = true
				case "static":
					isStatic = true
				case "abstract":
					isAbstract = true
				}
			case "body":
				bodyNode = capture.Node
			}
			classNode = match.Captures[0].Node
		}

		// Skip abstract or static classes
		if isAbstract || isStatic || !isPublic {
			continue
		}

		// Check if all members are static (or constructors)
		hasNonStatic := false

		for i := 0; i < int(bodyNode.NamedChildCount()); i++ {
			member := bodyNode.NamedChild(i)
			if member == nil {
				continue
			}

			switch member.Type() {
			case "method_declaration", "property_declaration", "field_declaration", "event_field_declaration":
				isMemberStatic := false
				for j := 0; j < int(member.ChildCount()); j++ {
					child := member.Child(j)
					if child.Type() == "modifier" && string(source[child.StartByte():child.EndByte()]) == "static" {
						isMemberStatic = true
						break
					}
				}
				if !isMemberStatic {
					hasNonStatic = true
				}
			case "constructor_declaration":
				// allow default constructor
			default:
				// ignore nested types and others
			}
		}

		if !hasNonStatic {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Description:    "Class '" + className + "' contains only static members and should be marked static",
				Classification: r.Classification(),
				Priority:       r.Priority(),
				BeginLine:      int(classNode.StartPoint().Row + 1),
				BeginColumn:    int(classNode.StartPoint().Column + 1),
				EndLine:        int(classNode.EndPoint().Row + 1),
				EndColumn:      int(classNode.EndPoint().Column + 1),
			})
		}
	}

	if len(issues) > 0 {
		log.Printf("Found %d CA1052 violations", len(issues))
	}
	return issues
}

//CA1056: URI properties should not be strings

type uriStringPropertyRule struct{}

var UriStringPropertyRule = &uriStringPropertyRule{}

func (r *uriStringPropertyRule) Rule() string {
	return "URI properties should not be strings"
}
func (r *uriStringPropertyRule) RuleSet() string { return "Structure" }
func (r *uriStringPropertyRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *uriStringPropertyRule) Priority() int { return 3 }

func (r *uriStringPropertyRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `
	(
		(property_declaration
			(modifier)* @modifiers
			type: (predefined_type) @type
			name: (identifier) @prop_name
		)
	)
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	uriRegex := regexp.MustCompile(`(?i)\b(uri|url|urn)\b`)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var propType, propName string
		var modifiers []string
		var propNode *sitter.Node

		for _, capture := range match.Captures {
			text := string(source[capture.Node.StartByte():capture.Node.EndByte()])
			switch q.CaptureNameForId(capture.Index) {
			case "type":
				propType = text
			case "prop_name":
				propName = text
				propNode = capture.Node
			case "modifiers":
				modifiers = append(modifiers, text)
			}
		}

		isVisible := false
		for _, mod := range modifiers {
			if mod == "public" || mod == "protected" {
				isVisible = true
				break
			}
		}

		if isVisible && strings.EqualFold(propType, "string") && uriRegex.MatchString(splitPascalCase(propName)) {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Property '" + propName + "' appears to represent a URI and should not be of type string",
				Priority:       r.Priority(),
				BeginLine:      int(propNode.StartPoint().Row + 1),
				BeginColumn:    int(propNode.StartPoint().Column + 1),
				EndLine:        int(propNode.EndPoint().Row + 1),
				EndColumn:      int(propNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

func splitPascalCase(name string) string {
	// Converts "SomeUriProperty" -> "Some Uri Property"
	var result strings.Builder
	for i, r := range name {
		if i > 0 && r >= 'A' && r <= 'Z' {
			result.WriteRune(' ')
		}
		result.WriteRune(r)
	}
	return result.String()
}

// CA1069: Enums should not have duplicate values
type enumNoDuplicateValueRule struct{}

var EnumNoDuplicateValueRule = &enumNoDuplicateValueRule{}

func (r *enumNoDuplicateValueRule) Rule() string {
	return "URI properties should not be strings"
}
func (r *enumNoDuplicateValueRule) RuleSet() string { return "Structure" }
func (r *enumNoDuplicateValueRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *enumNoDuplicateValueRule) Priority() int { return 3 }

func (r *enumNoDuplicateValueRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	query := `
	(
	enum_declaration
		name: (identifier) @enum_name
		body: (enum_member_declaration_list
		(enum_member_declaration
			name: (identifier) @member_name
			"=" @equals
			value: (_) @value
		) @member_decl
		)
	)
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	type enumInfo struct {
		enumName   string
		seenValues map[string]string // map[value] -> memberName
	}

	enumMap := make(map[string]*enumInfo)
	var currentEnum string
	var issues []core.Issue

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var memberName, valueStr string
		//var valueNode *sitter.Node
		var memberNode *sitter.Node

		for _, cap := range match.Captures {
			name := q.CaptureNameForId(cap.Index)
			switch name {
			case "enum_name":
				currentEnum = string(source[cap.Node.StartByte():cap.Node.EndByte()])
				if _, exists := enumMap[currentEnum]; !exists {
					enumMap[currentEnum] = &enumInfo{
						enumName:   currentEnum,
						seenValues: make(map[string]string),
					}
				}
			case "member_name":
				memberName = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			case "value":
				valueStr = strings.TrimSpace(string(source[cap.Node.StartByte():cap.Node.EndByte()]))
				//valueNode = cap.Node
			case "member_decl":
				memberNode = cap.Node
			}
		}

		if valueStr == "" || memberName == "" || currentEnum == "" {
			continue
		}

		enum := enumMap[currentEnum]

		// If the value is a numeric constant
		if isNumeric(valueStr) {
			if prevMember, found := enum.seenValues[valueStr]; found {
				// If value was used explicitly again (not referencing other member), raise an issue
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    fmt.Sprintf("Enum member '%s' has the same constant value as '%s'. Consider referencing it instead.", memberName, prevMember),
					Priority:       r.Priority(),
					BeginLine:      int(memberNode.StartPoint().Row + 1),
					BeginColumn:    int(memberNode.StartPoint().Column + 1),
					EndLine:        int(memberNode.EndPoint().Row + 1),
					EndColumn:      int(memberNode.EndPoint().Column + 1),
				})
			} else {
				enum.seenValues[valueStr] = memberName
			}
		}
	}

	return issues
}

func isNumeric(val string) bool {
	_, err := strconv.Atoi(val)
	return err == nil
}

// CA1200: Avoid using cref tags with a prefix
type avoidCrefPrefixRule struct{}

var AvoidCrefPrefixRule = &avoidCrefPrefixRule{}

func (r *avoidCrefPrefixRule) Rule() string {
	return "Avoid using cref tags with a prefix"
}
func (r *avoidCrefPrefixRule) RuleSet() string { return "Comments" }
func (r *avoidCrefPrefixRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *avoidCrefPrefixRule) Priority() int { return 3 }

// Regex to match <see cref="X:Y" /> where X is a prefix like T, F, P, M, etc.
var crefPrefixPattern = regexp.MustCompile(`<see\s+cref="([A-Z]):([^"]+)"\s*/?>`)

func (r *avoidCrefPrefixRule) Analyze(_ interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue
	lines := strings.Split(string(source), "\n")

	for i, line := range lines {
		matches := crefPrefixPattern.FindAllStringSubmatchIndex(line, -1)
		for _, match := range matches {
			startCol := match[0]
			endCol := match[1]
			crefContent := line[match[2]:match[3]]
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Avoid using prefix '" + crefContent + "' in cref tag. Use unqualified references instead.",
				Priority:       r.Priority(),
				BeginLine:      i + 1,
				BeginColumn:    startCol + 1,
				EndLine:        i + 1,
				EndColumn:      endCol + 1,
			})
		}
	}

	return issues
}

// CA1507: Use nameof in place of string literal
type useNameofRule struct{}

var UseNameofRule = &useNameofRule{}

func (r *useNameofRule) Rule() string {
	return "Use nameof in place of string literal"
}
func (r *useNameofRule) RuleSet() string { return "Sustainability" }
func (r *useNameofRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *useNameofRule) Priority() int { return 3 }

// Regex to detect ArgumentNullException with string literals
var argNullPattern = regexp.MustCompile(`ArgumentNullException\(\s*"([a-zA-Z_][a-zA-Z0-9_]*)"`)

func (r *useNameofRule) Analyze(_rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	var issues []core.Issue
	lines := strings.Split(string(source), "\n")

	for i, line := range lines {
		matches := argNullPattern.FindAllStringSubmatch(line, -1)
		for _, match := range matches {
			if len(match) > 1 {
				paramName := match[1]
				beginCol := strings.Index(line, match[0])
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "String literal \"" + paramName + "\" used in ArgumentNullException. Use nameof(" + paramName + ") instead.",
					Priority:       r.Priority(),
					BeginLine:      i + 1,
					BeginColumn:    beginCol + 1,
					EndLine:        i + 1,
					EndColumn:      beginCol + len(match[0]) + 1,
				})
			}
		}
	}

	return issues
}

// CA1714: Flags enums should have plural names
type flagsEnumPluralNameRule struct{}

var FlagsEnumPluralNameRule = &flagsEnumPluralNameRule{}

func (r *flagsEnumPluralNameRule) Rule() string {
	return "Flags enums should have plural names"
}
func (r *flagsEnumPluralNameRule) RuleSet() string { return "Clarity" }
func (r *flagsEnumPluralNameRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *flagsEnumPluralNameRule) Priority() int { return 2 }

func (r *flagsEnumPluralNameRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	query := `
	(
	  (enum_declaration
		(attribute_list 
			(attribute
				name: (identifier) @attr_name
			)
		)+
		name: (identifier) @enum_name
	  ) @enum_decl
	)
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	var issues []core.Issue

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var enumName string
		var isFlags bool
		var enumNode *sitter.Node

		for _, cap := range match.Captures {
			name := q.CaptureNameForId(cap.Index)
			text := string(source[cap.Node.StartByte():cap.Node.EndByte()])

			switch name {
			case "enum_name":
				enumName = text
			case "attr_name":
				if text == "Flags" {
					isFlags = true
				}
			case "enum_decl":
				enumNode = cap.Node
			}
		}

		if isFlags && enumName != "" && !strings.HasSuffix(enumName, "s") {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Enum '" + enumName + "' has [Flags] attribute but its name is not plural. Consider renaming it to be plural.",
				Priority:       r.Priority(),
				BeginLine:      int(enumNode.StartPoint().Row + 1),
				BeginColumn:    int(enumNode.StartPoint().Column + 1),
				EndLine:        int(enumNode.EndPoint().Row + 1),
				EndColumn:      int(enumNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1717: Only FlagsAttribute enums should have plural names
type enumPluralNameWithoutFlagsRule struct{}

var EnumPluralNameWithoutFlagsRule = &enumPluralNameWithoutFlagsRule{}

func (r *enumPluralNameWithoutFlagsRule) Rule() string {
	return "Only FlagsAttribute enums should have plural names"
}
func (r *enumPluralNameWithoutFlagsRule) RuleSet() string { return "Clarity" }
func (r *enumPluralNameWithoutFlagsRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *enumPluralNameWithoutFlagsRule) Priority() int { return 2 }

func (r *enumPluralNameWithoutFlagsRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	query := `
	(
	(enum_declaration
		(attribute_list
		(attribute
			name: (identifier) @attribute_name
		)+
		)?
		name: (identifier) @enum_name
	) @enum
	)

	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	var issues []core.Issue
	var enumName string
	var hasFlags bool
	var enumNode *sitter.Node

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		enumName = ""
		hasFlags = false
		enumNode = nil

		for _, cap := range match.Captures {
			captureName := q.CaptureNameForId(cap.Index)
			text := string(source[cap.Node.StartByte():cap.Node.EndByte()])

			switch captureName {
			case "enum_name":
				enumName = text
				enumNode = cap.Node
			case "attribute_name":
				if strings.EqualFold(text, "Flags") || strings.EqualFold(text, "System.Flags") {
					hasFlags = true
				}
			}
		}

		if enumName != "" && !hasFlags && isPlural(enumName) {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Enum '" + enumName + "' has a plural name but is not marked with FlagsAttribute.",
				Priority:       r.Priority(),
				BeginLine:      int(enumNode.StartPoint().Row + 1),
				BeginColumn:    int(enumNode.StartPoint().Column + 1),
				EndLine:        int(enumNode.EndPoint().Row + 1),
				EndColumn:      int(enumNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// isPlural checks if the enum name ends in 's' and is not a known singular word.
func isPlural(name string) bool {
	if name == "" {
		return false
	}
	runes := []rune(name)
	lastChar := runes[len(runes)-1]
	return unicode.ToLower(lastChar) == 's'
}

// CA1727: Use PascalCase for named placeholders
type pascalCasePlaceholdersRule struct{}

var PascalCasePlaceholdersRule = &pascalCasePlaceholdersRule{}

func (r *pascalCasePlaceholdersRule) Rule() string {
	return "Use PascalCase for named placeholders"
}
func (r *pascalCasePlaceholdersRule) RuleSet() string { return "Clarity" }
func (r *pascalCasePlaceholdersRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *pascalCasePlaceholdersRule) Priority() int { return 2 }

func (r *pascalCasePlaceholdersRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	query := `
	(
		(invocation_expression
			(member_access_expression
				name: (identifier) @method_name
			)
			(argument_list
				(argument
					(string_literal) @message
				)
			)
		)
	)
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	var issues []core.Issue
	placeholderPattern := regexp.MustCompile(`\{([^{}]+)\}`)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var messageNode *sitter.Node
		for _, cap := range match.Captures {
			if q.CaptureNameForId(cap.Index) == "message" {
				messageNode = cap.Node
				break
			}
		}

		if messageNode == nil {
			continue
		}

		messageText := string(source[messageNode.StartByte():messageNode.EndByte()])
		// Remove surrounding quotes
		messageText = strings.Trim(messageText, `"`)

		matches := placeholderPattern.FindAllStringSubmatch(messageText, -1)
		for _, match := range matches {
			placeholder := match[1]
			if !isPascalCase(placeholder) {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Placeholder '" + placeholder + "' should use PascalCase in logger messages.",
					Priority:       r.Priority(),
					BeginLine:      int(messageNode.StartPoint().Row + 1),
					BeginColumn:    int(messageNode.StartPoint().Column + 1),
					EndLine:        int(messageNode.EndPoint().Row + 1),
					EndColumn:      int(messageNode.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

func isPascalCase(s string) bool {
	if s == "" {
		return false
	}
	runes := []rune(s)
	if !unicode.IsUpper(runes[0]) {
		return false
	}
	for _, r := range runes {
		if r == '_' {
			return false
		}
	}
	return true
}

// CA1805: Do not initialize unnecessarily
type noUnnecessaryInitializationRule struct{}

var NoUnnecessaryInitializationRule = &noUnnecessaryInitializationRule{}

func (r *noUnnecessaryInitializationRule) Rule() string {
	return "Do not initialize unnecessarily"
}
func (r *noUnnecessaryInitializationRule) RuleSet() string { return "Efficiency" }
func (r *noUnnecessaryInitializationRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *noUnnecessaryInitializationRule) Priority() int { return 3 }

func (r *noUnnecessaryInitializationRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	// Query to find field declarations with optional initializer
	query := `
	(
	field_declaration
		(_) @type
		(variable_declaration
		(variable_declarator
			name: (identifier) @field_name
			(_) @init_value
		) @var_decl
		)
	)
	`

	q, err := sitter.NewQuery([]byte(query), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	var issues []core.Issue

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var fieldName string
		var initValue string
		var typeName string
		var varDeclNode *sitter.Node

		for _, cap := range match.Captures {
			name := q.CaptureNameForId(cap.Index)
			switch name {
			case "field_name":
				fieldName = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			case "init_value":
				initValue = strings.TrimSpace(string(source[cap.Node.StartByte():cap.Node.EndByte()]))
			case "type":
				typeName = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			case "var_decl":
				varDeclNode = cap.Node
			}
		}

		if initValue == "" {
			continue // no explicit initializer, skip
		}

		// Check if initValue is default for the type
		if isDefaultValue(typeName, initValue) {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Field '" + fieldName + "' is explicitly initialized to its default value '" + initValue + "'. This initialization is unnecessary.",
				Priority:       r.Priority(),
				BeginLine:      int(varDeclNode.StartPoint().Row + 1),
				BeginColumn:    int(varDeclNode.StartPoint().Column + 1),
				EndLine:        int(varDeclNode.EndPoint().Row + 1),
				EndColumn:      int(varDeclNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// isDefaultValue returns true if the initializer is the default for the given type.
func isDefaultValue(typeName, initValue string) bool {
	switch typeName {
	case "int", "long", "short", "byte", "uint", "ulong", "ushort", "sbyte":
		return initValue == "0"
	case "bool":
		return initValue == "false"
	case "string":
		return initValue == "null"
	default:
		// Assume reference types default to null
		return initValue == "null"
	}
}

// CA1806: Do not ignore method results
type ignoreMethodResultRule struct{}

var IgnoreMethodResultRule = &ignoreMethodResultRule{}

func (r *ignoreMethodResultRule) Rule() string {
	return "Do not ignore method results."
}
func (r *ignoreMethodResultRule) RuleSet() string { return "Efficiency" }
func (r *ignoreMethodResultRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *ignoreMethodResultRule) Priority() int { return 4 }

// Analyze detects unused method or constructor results.
func (r *ignoreMethodResultRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	queryText := `
	(expression_statement
	(invocation_expression) @invocation
	)

	(expression_statement
	(object_creation_expression) @object_creation
	)
	`

	q, err := sitter.NewQuery([]byte(queryText), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(q, root)

	var issues []core.Issue

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		for _, cap := range match.Captures {
			node := cap.Node
			capName := q.CaptureNameForId(cap.Index)

			if capName == "invocation" {
				// Get method name text (optional, for better messages)
				methodName := getMethodName(node, source)

				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Method call result ignored. Consider assigning or using the return value of '" + methodName + "'.",
					Priority:       r.Priority(),
					BeginLine:      int(node.StartPoint().Row + 1),
					BeginColumn:    int(node.StartPoint().Column + 1),
					EndLine:        int(node.EndPoint().Row + 1),
					EndColumn:      int(node.EndPoint().Column + 1),
				})
			} else if capName == "object_creation" {
				// Get type name of the created object
				typeName := getObjectTypeName(node, source)

				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Created object of type '" + typeName + "' is discarded. Consider assigning it or using it.",
					Priority:       r.Priority(),
					BeginLine:      int(node.StartPoint().Row + 1),
					BeginColumn:    int(node.StartPoint().Column + 1),
					EndLine:        int(node.EndPoint().Row + 1),
					EndColumn:      int(node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

// getMethodName tries to extract the method name from invocation_expression node
func getMethodName(invocationNode *sitter.Node, source []byte) string {
	for i := 0; i < int(invocationNode.ChildCount()); i++ {
		child := invocationNode.Child(i)
		if child == nil {
			continue
		}
		if child.Type() == "member_access_expression" || child.Type() == "identifier" {
			return string(source[child.StartByte():child.EndByte()])
		}
	}
	return "method"
}

// getObjectTypeName extracts the type name from object_creation_expression node
func getObjectTypeName(objectCreationNode *sitter.Node, source []byte) string {
	for i := 0; i < int(objectCreationNode.ChildCount()); i++ {
		child := objectCreationNode.Child(i)
		if child == nil {
			continue
		}
		if child.Type() == "identifier" {
			return string(source[child.StartByte():child.EndByte()])
		}
	}
	return "type"
}

// CA1810: Initialize reference type static fields inline
type staticConstructorRule struct{}

var StaticConstructorRule = &staticConstructorRule{}

func (r *staticConstructorRule) Rule() string {
	return "Initialize reference type static fields inline."
}
func (r *staticConstructorRule) RuleSet() string { return "Efficiency" }
func (r *staticConstructorRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *staticConstructorRule) Priority() int { return 3 }

func (r *staticConstructorRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	queryText := `
	(
	constructor_declaration
		(modifier)? @mods
		name: (identifier) @name
		body: (block)
	) @constructor
	`

	query, err := sitter.NewQuery([]byte(queryText), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, root)

	var issues []core.Issue

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var isStatic bool
		var constructorName string
		var constructorNode *sitter.Node

		for _, cap := range match.Captures {
			switch query.CaptureNameForId(cap.Index) {
			case "mods":
				if strings.Contains(string(source[cap.Node.StartByte():cap.Node.EndByte()]), "static") {
					isStatic = true
				}
			case "name":
				constructorName = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			case "constructor":
				constructorNode = cap.Node
			}
		}

		if isStatic && constructorNode != nil {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Avoid explicit static constructor '" + constructorName + "()'. Inline-initialize static fields instead.",
				Priority:       r.Priority(),
				BeginLine:      int(constructorNode.StartPoint().Row + 1),
				BeginColumn:    int(constructorNode.StartPoint().Column + 1),
				EndLine:        int(constructorNode.EndPoint().Row + 1),
				EndColumn:      int(constructorNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// CA1819: Properties should not return arrays
type arrayPropertyRule struct{}

var ArrayPropertyRule = &arrayPropertyRule{}

func (r *arrayPropertyRule) Rule() string {
	return "Properties should not return arrays.."
}
func (r *arrayPropertyRule) RuleSet() string { return "Efficiency" }
func (r *arrayPropertyRule) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *arrayPropertyRule) Priority() int { return 4 }

func (r *arrayPropertyRule) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()

	queryText := `
	(
		property_declaration
			type: (_) @type
			name: (identifier) @name
	) @property
	`

	query, err := sitter.NewQuery([]byte(queryText), cs.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}

	cursor := sitter.NewQueryCursor()
	cursor.Exec(query, root)

	var issues []core.Issue

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}

		var returnType, name string
		var propertyNode *sitter.Node

		for _, cap := range match.Captures {
			switch query.CaptureNameForId(cap.Index) {
			case "type":
				returnType = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			case "name":
				name = string(source[cap.Node.StartByte():cap.Node.EndByte()])
			case "property":
				propertyNode = cap.Node
			}
		}

		if propertyNode != nil && strings.HasSuffix(returnType, "[]") {
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Property '" + name + "' returns an array. Consider returning a method or collection instead.",
				Priority:       r.Priority(),
				BeginLine:      int(propertyNode.StartPoint().Row + 1),
				BeginColumn:    int(propertyNode.StartPoint().Column + 1),
				EndLine:        int(propertyNode.EndPoint().Row + 1),
				EndColumn:      int(propertyNode.EndPoint().Column + 1),
			})
		}
	}

	return issues
}
