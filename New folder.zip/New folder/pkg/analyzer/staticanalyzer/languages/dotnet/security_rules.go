package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
)

// --------------- Security Rules ------------------ //

type CA2300_Rule_Security struct{}

func (r *CA2300_Rule_Security) ID() string    { return "CA2300" }
func (r *CA2300_Rule_Security) Severity() int { return 5 }
func (r *CA2300_Rule_Security) Rule() string {
	return "Do not use insecure deserializer BinaryFormatter"
}
func (r *CA2300_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2300_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2300_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2300, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2301_Rule_Security struct{}

func (r *CA2301_Rule_Security) ID() string    { return "CA2301" }
func (r *CA2301_Rule_Security) Severity() int { return 5 }
func (r *CA2301_Rule_Security) Rule() string {
	return "Do not call BinaryFormatter.Deserialize without first setting BinaryFormatter.Binder"
}
func (r *CA2301_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2301_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2301_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2301, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2302_Rule_Security struct{}

func (r *CA2302_Rule_Security) ID() string    { return "CA2302" }
func (r *CA2302_Rule_Security) Severity() int { return 5 }
func (r *CA2302_Rule_Security) Rule() string {
	return "Ensure BinaryFormatter.Binder is set before calling BinaryFormatter.Deserialize"
}
func (r *CA2302_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2302_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2302_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2302, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2305_Rule_Security struct{}

func (r *CA2305_Rule_Security) ID() string      { return "CA2305" }
func (r *CA2305_Rule_Security) Severity() int   { return 5 }
func (r *CA2305_Rule_Security) Rule() string    { return "Do not use insecure deserializer LosFormatter" }
func (r *CA2305_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2305_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2305_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2305, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2310_Rule_Security struct{}

func (r *CA2310_Rule_Security) ID() string    { return "CA2310" }
func (r *CA2310_Rule_Security) Severity() int { return 5 }
func (r *CA2310_Rule_Security) Rule() string {
	return "Do not use insecure deserializer NetDataContractSerializer"
}
func (r *CA2310_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2310_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2310_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2310, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2311_Rule_Security struct{}

func (r *CA2311_Rule_Security) ID() string    { return "CA2311" }
func (r *CA2311_Rule_Security) Severity() int { return 5 }
func (r *CA2311_Rule_Security) Rule() string {
	return "Do not deserialize without first setting NetDataContractSerializer.Binder"
}
func (r *CA2311_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2311_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2311_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2311, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2312_Rule_Security struct{}

func (r *CA2312_Rule_Security) ID() string    { return "CA2312" }
func (r *CA2312_Rule_Security) Severity() int { return 5 }
func (r *CA2312_Rule_Security) Rule() string {
	return "Ensure NetDataContractSerializer.Binder is set before deserializing"
}
func (r *CA2312_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2312_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2312_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2312, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2315_Rule_Security struct{}

func (r *CA2315_Rule_Security) ID() string    { return "CA2315" }
func (r *CA2315_Rule_Security) Severity() int { return 5 }
func (r *CA2315_Rule_Security) Rule() string {
	return "Do not use insecure deserializer ObjectStateFormatter"
}
func (r *CA2315_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2315_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2315_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2315, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2321_Rule_Security struct{}

func (r *CA2321_Rule_Security) ID() string    { return "CA2321" }
func (r *CA2321_Rule_Security) Severity() int { return 5 }
func (r *CA2321_Rule_Security) Rule() string {
	return "Do not deserialize with JavaScriptSerializer using a SimpleTypeResolver"
}
func (r *CA2321_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2321_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2321_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2321, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2322_Rule_Security struct{}

func (r *CA2322_Rule_Security) ID() string    { return "CA2322" }
func (r *CA2322_Rule_Security) Severity() int { return 5 }
func (r *CA2322_Rule_Security) Rule() string {
	return "Ensure JavaScriptSerializer is not initialized with SimpleTypeResolver before deserializing"
}
func (r *CA2322_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2322_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2322_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2322, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2326_Rule_Security struct{}

func (r *CA2326_Rule_Security) ID() string    { return "CA2326" }
func (r *CA2326_Rule_Security) Severity() int { return 5 }
func (r *CA2326_Rule_Security) Rule() string {
	return "Do not use TypeNameHandling values other than None"
}
func (r *CA2326_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2326_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2326_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2326, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2327_Rule_Security struct{}

func (r *CA2327_Rule_Security) ID() string      { return "CA2327" }
func (r *CA2327_Rule_Security) Severity() int   { return 5 }
func (r *CA2327_Rule_Security) Rule() string    { return "Do not use insecure JsonSerializerSettings" }
func (r *CA2327_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2327_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2327_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2327, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2328_Rule_Security struct{}

func (r *CA2328_Rule_Security) ID() string      { return "CA2328" }
func (r *CA2328_Rule_Security) Severity() int   { return 5 }
func (r *CA2328_Rule_Security) Rule() string    { return "Ensure that JsonSerializerSettings are secure" }
func (r *CA2328_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2328_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2328_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2328, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2329_Rule_Security struct{}

func (r *CA2329_Rule_Security) ID() string    { return "CA2329" }
func (r *CA2329_Rule_Security) Severity() int { return 5 }
func (r *CA2329_Rule_Security) Rule() string {
	return "Do not deserialize with JsonSerializer using an insecure configuration"
}
func (r *CA2329_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2329_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2329_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2329, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2330_Rule_Security struct{}

func (r *CA2330_Rule_Security) ID() string    { return "CA2330" }
func (r *CA2330_Rule_Security) Severity() int { return 5 }
func (r *CA2330_Rule_Security) Rule() string {
	return "Ensure that JsonSerializer has a secure configuration when deserializing"
}
func (r *CA2330_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2330_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2330_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2330, "Insecure deserializers are vulnerable when deserializing untrusted data. An attacker could modify the serialized data to include unexpected types to inject objects with malicious side effects.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2350_Rule_Security struct{}

func (r *CA2350_Rule_Security) ID() string      { return "CA2350" }
func (r *CA2350_Rule_Security) Severity() int   { return 5 }
func (r *CA2350_Rule_Security) Rule() string    { return "Ensure DataTable.ReadXml()'s input is trusted" }
func (r *CA2350_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2350_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2350_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2350, "When deserializing a DataTable with untrusted input, an attacker can craft malicious input to perform a denial of service attack. There may be unknown remote code execution vulnerabilities.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2351_Rule_Security struct{}

func (r *CA2351_Rule_Security) ID() string      { return "CA2351" }
func (r *CA2351_Rule_Security) Severity() int   { return 5 }
func (r *CA2351_Rule_Security) Rule() string    { return "Ensure DataSet.ReadXml()'s input is trusted" }
func (r *CA2351_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2351_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2351_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2351, "When deserializing a DataSet with untrusted input, an attacker can craft malicious input to perform a denial of service attack. There may be unknown remote code execution vulnerabilities.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2352_Rule_Security struct{}

func (r *CA2352_Rule_Security) ID() string    { return "CA2352" }
func (r *CA2352_Rule_Security) Severity() int { return 5 }
func (r *CA2352_Rule_Security) Rule() string {
	return "Unsafe DataSet or DataTable in serializable type can be vulnerable to remote code execution attacks"
}
func (r *CA2352_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2352_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2352_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2352, "A class or struct marked with SerializableAttribute contains a DataSet or DataTable field or property, and doesn't have a GeneratedCodeAttribute.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2353_Rule_Security struct{}

func (r *CA2353_Rule_Security) ID() string    { return "CA2353" }
func (r *CA2353_Rule_Security) Severity() int { return 5 }
func (r *CA2353_Rule_Security) Rule() string {
	return "Unsafe DataSet or DataTable in serializable type"
}
func (r *CA2353_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2353_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2353_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2353, "A class or struct marked with an XML serialization attribute or a data contract attribute contains a DataSet or DataTable field or property.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2354_Rule_Security struct{}

func (r *CA2354_Rule_Security) ID() string    { return "CA2354" }
func (r *CA2354_Rule_Security) Severity() int { return 5 }
func (r *CA2354_Rule_Security) Rule() string {
	return "Unsafe DataSet or DataTable in deserialized object graph can be vulnerable to remote code execution attack"
}
func (r *CA2354_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2354_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2354_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2354, "Deserializing with an System.Runtime.Serialization.IFormatter serialized, and the casted type's object graph can include a DataSet or DataTable.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2355_Rule_Security struct{}

func (r *CA2355_Rule_Security) ID() string    { return "CA2355" }
func (r *CA2355_Rule_Security) Severity() int { return 5 }
func (r *CA2355_Rule_Security) Rule() string {
	return "Unsafe DataSet or DataTable in deserialized object graph"
}
func (r *CA2355_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2355_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2355_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2355, "Deserializing when the casted or specified type's object graph can include a DataSet or DataTable.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2356_Rule_Security struct{}

func (r *CA2356_Rule_Security) ID() string    { return "CA2356" }
func (r *CA2356_Rule_Security) Severity() int { return 5 }
func (r *CA2356_Rule_Security) Rule() string {
	return "Unsafe DataSet or DataTable in web deserialized object graph"
}
func (r *CA2356_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2356_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2356_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2356, "A method with a System.Web.Services.WebMethodAttribute or System.ServiceModel.OperationContractAttribute has a parameter that may reference a DataSet or DataTable.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2361_Rule_Security struct{}

func (r *CA2361_Rule_Security) ID() string    { return "CA2361" }
func (r *CA2361_Rule_Security) Severity() int { return 5 }
func (r *CA2361_Rule_Security) Rule() string {
	return "Ensure autogenerated class containing DataSet.ReadXml() is not used with untrusted data"
}
func (r *CA2361_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2361_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2361_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2361, "When deserializing a DataSet with untrusted input, an attacker can craft malicious input to perform a denial of service attack. There may be unknown remote code execution vulnerabilities.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA2362_Rule_Security struct{}

func (r *CA2362_Rule_Security) ID() string    { return "CA2362" }
func (r *CA2362_Rule_Security) Severity() int { return 5 }
func (r *CA2362_Rule_Security) Rule() string {
	return "Unsafe DataSet or DataTable in autogenerated serializable type can be vulnerable to remote code execution attacks"
}
func (r *CA2362_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2362_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2362_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2362, "When deserializing untrusted input with BinaryFormatter and the deserialized object graph contains a DataSet or DataTable, an attacker can craft a malicious payload to perform a remote code execution attack.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3001_Rule_Security struct{}

func (r *CA3001_Rule_Security) ID() string      { return "CA3001" }
func (r *CA3001_Rule_Security) Severity() int   { return 5 }
func (r *CA3001_Rule_Security) Rule() string    { return "Review code for SQL injection vulnerabilities" }
func (r *CA3001_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3001_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3001_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3001, "When working with untrusted input and SQL commands, be mindful of SQL injection attacks. An SQL injection attack can execute malicious SQL commands, compromising the security and integrity of your application.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3002_Rule_Security struct{}

func (r *CA3002_Rule_Security) ID() string      { return "CA3002" }
func (r *CA3002_Rule_Security) Severity() int   { return 5 }
func (r *CA3002_Rule_Security) Rule() string    { return "Review code for XSS vulnerabilities" }
func (r *CA3002_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3002_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3002_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3002, "When working with untrusted input from web requests, be mindful of cross-site scripting (XSS) attacks. An XSS attack injects untrusted input into raw HTML output, allowing the attacker to execute malicious scripts or maliciously modify content in your web page.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3003_Rule_Security struct{}

func (r *CA3003_Rule_Security) ID() string    { return "CA3003" }
func (r *CA3003_Rule_Security) Severity() int { return 5 }
func (r *CA3003_Rule_Security) Rule() string {
	return "Review code for file path injection vulnerabilities"
}
func (r *CA3003_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3003_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3003_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3003, "When working with untrusted input from web requests, be mindful of using user-controlled input when specifying paths to files.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3004_Rule_Security struct{}

func (r *CA3004_Rule_Security) ID() string    { return "CA3004" }
func (r *CA3004_Rule_Security) Severity() int { return 5 }
func (r *CA3004_Rule_Security) Rule() string {
	return "Review code for information disclosure vulnerabilities"
}
func (r *CA3004_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3004_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3004_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3004, "Disclosing exception information gives attackers insight into the internals of your application, which can help attackers find other vulnerabilities to exploit.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3006_Rule_Security struct{}

func (r *CA3006_Rule_Security) ID() string    { return "CA3006" }
func (r *CA3006_Rule_Security) Severity() int { return 5 }
func (r *CA3006_Rule_Security) Rule() string {
	return "Review code for process command injection vulnerabilities"
}
func (r *CA3006_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3006_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3006_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3006, "When working with untrusted input, be mindful of command injection attacks. A command injection attack can execute malicious commands on the underlying operating system, compromising the security and integrity of your server.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3007_Rule_Security struct{}

func (r *CA3007_Rule_Security) ID() string      { return "CA3007" }
func (r *CA3007_Rule_Security) Severity() int   { return 5 }
func (r *CA3007_Rule_Security) Rule() string    { return "Review code for open redirect vulnerabilities" }
func (r *CA3007_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3007_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3007_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3007, "When working with untrusted input, be mindful of open redirect vulnerabilities. An attacker can exploit an open redirect vulnerability to use your website to give the appearance of a legitimate URL, but redirect an unsuspecting visitor to a phishing or other malicious webpage.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3008_Rule_Security struct{}

func (r *CA3008_Rule_Security) ID() string    { return "CA3008" }
func (r *CA3008_Rule_Security) Severity() int { return 5 }
func (r *CA3008_Rule_Security) Rule() string {
	return "Review code for XPath injection vulnerabilities"
}
func (r *CA3008_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3008_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3008_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3008, "When working with untrusted input, be mindful of XPath injection attacks. Using untrusted input in XPath queries may allow attackers to maliciously manipulate the query to return an unintended result, and possibly disclose the contents of the queried XML.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3009_Rule_Security struct{}

func (r *CA3009_Rule_Security) ID() string      { return "CA3009" }
func (r *CA3009_Rule_Security) Severity() int   { return 5 }
func (r *CA3009_Rule_Security) Rule() string    { return "Review code for XML injection vulnerabilities" }
func (r *CA3009_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3009_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3009_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3009, "When working with untrusted input, be mindful of XML injection attacks. Using untrusted input in XML may allow attackers to inject arbitrary XML, which could allow them to modify the XML structure and data.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3010_Rule_Security struct{}

func (r *CA3010_Rule_Security) ID() string      { return "CA3010" }
func (r *CA3010_Rule_Security) Severity() int   { return 5 }
func (r *CA3010_Rule_Security) Rule() string    { return "Review code for XAML injection vulnerabilities" }
func (r *CA3010_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3010_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3010_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3010, "When working with untrusted input, be mindful of XAML injection attacks. XAML is a markup language that directly represents object instantiation and execution. This means elements created in XAML can interact with system resources (network access, file system IO, etc.).", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3011_Rule_Security struct{}

func (r *CA3011_Rule_Security) ID() string      { return "CA3011" }
func (r *CA3011_Rule_Security) Severity() int   { return 5 }
func (r *CA3011_Rule_Security) Rule() string    { return "Review code for DLL injection vulnerabilities" }
func (r *CA3011_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3011_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3011_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3011, "When working with untrusted input, be mindful of loading untrusted DLLs. If your web application loads an untrusted DLL, an attacker might be able to execute malicious code on your server.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3012_Rule_Security struct{}

func (r *CA3012_Rule_Security) ID() string    { return "CA3012" }
func (r *CA3012_Rule_Security) Severity() int { return 5 }
func (r *CA3012_Rule_Security) Rule() string {
	return "Review code for regex injection vulnerabilities"
}
func (r *CA3012_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3012_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3012_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3012, "When working with untrusted input, be mindful of regex injection attacks. An attacker can use regex injection to maliciously modify a regular expression, to make the regex match unintended results, or to make the regex consume excessive CPU resulting in a Denial of Service.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3061_Rule_Security struct{}

func (r *CA3061_Rule_Security) ID() string      { return "CA3061" }
func (r *CA3061_Rule_Security) Severity() int   { return 5 }
func (r *CA3061_Rule_Security) Rule() string    { return "Do not add schema by URL" }
func (r *CA3061_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3061_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3061_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3061, "Do not use overload that takes a URL as an argument for XmlSchemaCollection.Add method because it will fetch from external sources.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3075_Rule_Security struct{}

func (r *CA3075_Rule_Security) ID() string      { return "CA3075" }
func (r *CA3075_Rule_Security) Severity() int   { return 5 }
func (r *CA3075_Rule_Security) Rule() string    { return "Insecure DTD Processing" }
func (r *CA3075_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3075_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3075_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3075, "If you use DtdProcessing.Enable or load the source of a DTD, the processor may be vulnerable to XML External Entity (XXE) attacks. Use XmlReader with a secure resolver or set DtdProcessing to Prohibit.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3076_Rule_Security struct{}

func (r *CA3076_Rule_Security) ID() string      { return "CA3076" }
func (r *CA3076_Rule_Security) Severity() int   { return 5 }
func (r *CA3076_Rule_Security) Rule() string    { return "Insecure XSLT Script Execution" }
func (r *CA3076_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3076_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3076_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3076, "If you use XslCompiledTransform.Transform() with insecure settings, the processor may be vulnerable to malicious code execution. Use XslCompiledTransform.Transform() with secure settings or disable script execution.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3077_Rule_Security struct{}

func (r *CA3077_Rule_Security) ID() string    { return "CA3077" }
func (r *CA3077_Rule_Security) Severity() int { return 5 }
func (r *CA3077_Rule_Security) Rule() string {
	return "Insecure Processing in API Design, XML Document and XML Text Reader"
}
func (r *CA3077_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3077_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3077_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3077, "When designing an API based on XmlDocument and XmlTextReader, be mindful of DtdProcessing. Using XmlTextReader or XmlTextReader derived types with insecure DTD processing may lead to information disclosure.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA3147_Rule_Security struct{}

func (r *CA3147_Rule_Security) ID() string    { return "CA3147" }
func (r *CA3147_Rule_Security) Severity() int { return 5 }
func (r *CA3147_Rule_Security) Rule() string {
	return "Mark verb handlers with ValidateAntiForgeryToken"
}
func (r *CA3147_Rule_Security) RuleSet() string { return "Security" }
func (r *CA3147_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA3147_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA3147, "When building a web application that's based on ASP.NET MVC, you should use anti-forgery tokens to prevent cross-site request forgery attacks.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5350_Rule_Security struct{}

func (r *CA5350_Rule_Security) ID() string      { return "CA5350" }
func (r *CA5350_Rule_Security) Severity() int   { return 5 }
func (r *CA5350_Rule_Security) Rule() string    { return "Do Not Use Weak Cryptographic Algorithms" }
func (r *CA5350_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5350_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5350_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5350, "Weak encryption algorithms and hashing functions are used today for a number of reasons, but they are not considered secure enough to guarantee the protection of the data they encrypt.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5351_Rule_Security struct{}

func (r *CA5351_Rule_Security) ID() string      { return "CA5351" }
func (r *CA5351_Rule_Security) Severity() int   { return 5 }
func (r *CA5351_Rule_Security) Rule() string    { return "Do Not Use Broken Cryptographic Algorithms" }
func (r *CA5351_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5351_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5351_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5351, "Broken cryptographic algorithms are not considered secure, and their use should be discouraged. The MD5 hash algorithm is susceptible to known collision attacks, though the specific vulnerability will vary based on the context of use.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5358_Rule_Security struct{}

func (r *CA5358_Rule_Security) ID() string      { return "CA5358" }
func (r *CA5358_Rule_Security) Severity() int   { return 5 }
func (r *CA5358_Rule_Security) Rule() string    { return "Do Not Use Unsafe Cipher Modes" }
func (r *CA5358_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5358_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5358_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5358, "Encryption algorithms should use authenticated encryption modes.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5359_Rule_Security struct{}

func (r *CA5359_Rule_Security) ID() string      { return "CA5359" }
func (r *CA5359_Rule_Security) Severity() int   { return 5 }
func (r *CA5359_Rule_Security) Rule() string    { return "Do not disable certificate validation" }
func (r *CA5359_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5359_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5359_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5359, "Disabling certificate validation in production code is equivalent to not having any validation.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5360_Rule_Security struct{}

func (r *CA5360_Rule_Security) ID() string    { return "CA5360" }
func (r *CA5360_Rule_Security) Severity() int { return 5 }
func (r *CA5360_Rule_Security) Rule() string {
	return "Do not call dangerous methods in deserialization"
}
func (r *CA5360_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5360_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5360_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5360, "Insecure deserialization is vulnerable when the deserialized object contains a method that gets automatically called as part of the deserialization process.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5361_Rule_Security struct{}

func (r *CA5361_Rule_Security) ID() string      { return "CA5361" }
func (r *CA5361_Rule_Security) Severity() int   { return 5 }
func (r *CA5361_Rule_Security) Rule() string    { return "Do not disable SChannel use of strong crypto" }
func (r *CA5361_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5361_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5361_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5361, "Setting Switch.System.Net.DontEnableSchUseStrongCrypto to true weakens the cryptography used in outgoing TLS connections.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5362_Rule_Security struct{}

func (r *CA5362_Rule_Security) ID() string    { return "CA5362" }
func (r *CA5362_Rule_Security) Severity() int { return 5 }
func (r *CA5362_Rule_Security) Rule() string {
	return "Potential reference cycle in deserialized object graph"
}
func (r *CA5362_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5362_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5362_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5362, "Deserializing untrusted data with DataContractSerializer is vulnerable to reference cycle attacks. A malicious payload containing a reference cycle in the object graph being deserialized can result in a denial of service attack.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5363_Rule_Security struct{}

func (r *CA5363_Rule_Security) ID() string      { return "CA5363" }
func (r *CA5363_Rule_Security) Severity() int   { return 5 }
func (r *CA5363_Rule_Security) Rule() string    { return "Do not disable request validation" }
func (r *CA5363_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5363_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5363_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5363, "Request validation is a feature in ASP.NET that examines HTTP requests and determines whether they contain potentially dangerous content that could lead to injection attacks, including cross-site-scripting.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5364_Rule_Security struct{}

func (r *CA5364_Rule_Security) ID() string      { return "CA5364" }
func (r *CA5364_Rule_Security) Severity() int   { return 5 }
func (r *CA5364_Rule_Security) Rule() string    { return "Do not use deprecated security protocols" }
func (r *CA5364_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5364_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5364_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5364, "Using a deprecated security protocol such as Secure Sockets Layer (SSL) when connecting to a remote host is dangerous, as it may allow the use of weak ciphers or obsolete algorithms.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5365_Rule_Security struct{}

func (r *CA5365_Rule_Security) ID() string      { return "CA5365" }
func (r *CA5365_Rule_Security) Severity() int   { return 5 }
func (r *CA5365_Rule_Security) Rule() string    { return "Do Not Disable HTTP Header Checking" }
func (r *CA5365_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5365_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5365_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5365, "HTTP header checking enables encoding of the carriage return and newline characters, \r and \n, that are found in response headers. This encoding can help to avoid injection attacks that exploit an application that echoes untrusted data contained in the header.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5366_Rule_Security struct{}

func (r *CA5366_Rule_Security) ID() string      { return "CA5366" }
func (r *CA5366_Rule_Security) Severity() int   { return 5 }
func (r *CA5366_Rule_Security) Rule() string    { return "Use XmlReader For DataSet Read XML" }
func (r *CA5366_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5366_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5366_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5366, "Using a DataSet to read XML with untrusted data may load dangerous external references, which should be restricted by using an XmlReader with a secure resolver or with DTD processing disabled.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5367_Rule_Security struct{}

func (r *CA5367_Rule_Security) ID() string      { return "CA5367" }
func (r *CA5367_Rule_Security) Severity() int   { return 5 }
func (r *CA5367_Rule_Security) Rule() string    { return "Do Not Serialize Types With Pointer Fields" }
func (r *CA5367_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5367_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5367_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5367, "Serialization is the process of converting an object into a form that can be readily persisted or transported. For example, serializing an object and transporting it over the Internet using HTTP between sites.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5368_Rule_Security struct{}

func (r *CA5368_Rule_Security) ID() string    { return "CA5368" }
func (r *CA5368_Rule_Security) Severity() int { return 5 }
func (r *CA5368_Rule_Security) Rule() string {
	return "Set ViewStateUserKey For Classes Derived From Page"
}
func (r *CA5368_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5368_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5368_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5368, "Setting the ViewStateUserKey property can help prevent one-click attacks by making it harder for an attacker to generate a valid view state for the page. When this property is set, the view state is signed with a unique identifier for each user.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5369_Rule_Security struct{}

func (r *CA5369_Rule_Security) ID() string      { return "CA5369" }
func (r *CA5369_Rule_Security) Severity() int   { return 5 }
func (r *CA5369_Rule_Security) Rule() string    { return "Use XmlReader for Deserialize" }
func (r *CA5369_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5369_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5369_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5369, "Processing untrusted DTD and XML schema with XmlReader with unsafe settings or resolving URIs may lead to dangerous external references in XML, which should be restricted by using an XmlReader with a secure resolver or with DTD and XML inline schema processing disabled.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5370_Rule_Security struct{}

func (r *CA5370_Rule_Security) ID() string      { return "CA5370" }
func (r *CA5370_Rule_Security) Severity() int   { return 5 }
func (r *CA5370_Rule_Security) Rule() string    { return "Use XmlReader for validating reader" }
func (r *CA5370_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5370_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5370_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5370, "Processing untrusted DTD and XML schema with XmlReader with unsafe settings or resolving URIs may lead to dangerous external references in XML, which should be restricted by using an XmlReader with a secure resolver or with DTD and XML inline schema processing disabled.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5371_Rule_Security struct{}

func (r *CA5371_Rule_Security) ID() string      { return "CA5371" }
func (r *CA5371_Rule_Security) Severity() int   { return 5 }
func (r *CA5371_Rule_Security) Rule() string    { return "Use XmlReader for schema read" }
func (r *CA5371_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5371_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5371_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5371, "Processing untrusted DTD and XML schema with XmlReader with unsafe settings or resolving URIs may lead to dangerous external references in XML, which should be restricted by using an XmlReader with a secure resolver or with DTD and XML inline schema processing disabled.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5372_Rule_Security struct{}

func (r *CA5372_Rule_Security) ID() string      { return "CA5372" }
func (r *CA5372_Rule_Security) Severity() int   { return 5 }
func (r *CA5372_Rule_Security) Rule() string    { return "Use XmlReader for XPathDocument" }
func (r *CA5372_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5372_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5372_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5372, "Processing untrusted DTD and XML schema with XmlReader with unsafe settings or resolving URIs may lead to dangerous external references in XML, which should be restricted by using an XmlReader with a secure resolver or with DTD and XML inline schema processing disabled.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5373_Rule_Security struct{}

func (r *CA5373_Rule_Security) ID() string      { return "CA5373" }
func (r *CA5373_Rule_Security) Severity() int   { return 5 }
func (r *CA5373_Rule_Security) Rule() string    { return "Do not use obsolete key derivation function" }
func (r *CA5373_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5373_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5373_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5373, "This rule detects the invocation of weak key derivation method System.Security.Cryptography.PasswordDeriveBytes and System.Security.Cryptography.Rfc2898DeriveBytes.CryptDeriveKey.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5374_Rule_Security struct{}

func (r *CA5374_Rule_Security) ID() string      { return "CA5374" }
func (r *CA5374_Rule_Security) Severity() int   { return 5 }
func (r *CA5374_Rule_Security) Rule() string    { return "Do not use XslTransform" }
func (r *CA5374_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5374_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5374_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5374, "XslTransform is obsolete and has known security vulnerabilities. Use XslCompiledTransform instead.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5375_Rule_Security struct{}

func (r *CA5375_Rule_Security) ID() string      { return "CA5375" }
func (r *CA5375_Rule_Security) Severity() int   { return 5 }
func (r *CA5375_Rule_Security) Rule() string    { return "Do not use account shared access signature" }
func (r *CA5375_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5375_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5375_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5375, "An account shared access signature (SAS) can delegate access to read, write, and delete operations on blob containers, tables, queues, and file shares that are not permitted with a service SAS. However, it provides account-level access and can do more than what might be intended.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5376_Rule_Security struct{}

func (r *CA5376_Rule_Security) ID() string      { return "CA5376" }
func (r *CA5376_Rule_Security) Severity() int   { return 5 }
func (r *CA5376_Rule_Security) Rule() string    { return "Use SharedAccessProtocol HttpsOnly" }
func (r *CA5376_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5376_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5376_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5376, "HTTPS encrypts network traffic. Use HttpsOnly, rather than HttpOrHttps, to ensure network traffic is always encrypted to help prevent disclosure of sensitive data.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5377_Rule_Security struct{}

func (r *CA5377_Rule_Security) ID() string      { return "CA5377" }
func (r *CA5377_Rule_Security) Severity() int   { return 5 }
func (r *CA5377_Rule_Security) Rule() string    { return "Use container level access policy" }
func (r *CA5377_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5377_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5377_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5377, "A container-level access policy can be modified or revoked at any time. It provides greater flexibility and control over the permissions that are granted.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5378_Rule_Security struct{}

func (r *CA5378_Rule_Security) ID() string    { return "CA5378" }
func (r *CA5378_Rule_Security) Severity() int { return 5 }
func (r *CA5378_Rule_Security) Rule() string {
	return "Do not disable ServicePointManagerSecurityProtocols"
}
func (r *CA5378_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5378_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5378_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5378, "Limiting Transport Layer Security (TLS) connections to only secure protocol versions can help ensure connections between your application and servers are as secure as possible.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5379_Rule_Security struct{}

func (r *CA5379_Rule_Security) ID() string    { return "CA5379" }
func (r *CA5379_Rule_Security) Severity() int { return 5 }
func (r *CA5379_Rule_Security) Rule() string {
	return "Ensure key derivation function algorithm is sufficiently strong"
}
func (r *CA5379_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5379_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5379_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5379, "When deriving cryptographic keys from user-provided passwords, use a sufficiently strong key derivation function with appropriate work factor (iteration count) to resist brute force attacks.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5380_Rule_Security struct{}

func (r *CA5380_Rule_Security) ID() string      { return "CA5380" }
func (r *CA5380_Rule_Security) Severity() int   { return 5 }
func (r *CA5380_Rule_Security) Rule() string    { return "Do not add certificates to root store" }
func (r *CA5380_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5380_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5380_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5380, "Adding certificates to the operating system's trusted root certificates increases the risk of legitimizing untrusted certificates.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5381_Rule_Security struct{}

func (r *CA5381_Rule_Security) ID() string    { return "CA5381" }
func (r *CA5381_Rule_Security) Severity() int { return 5 }
func (r *CA5381_Rule_Security) Rule() string {
	return "Ensure certificates are not added to root store"
}
func (r *CA5381_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5381_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5381_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5381, "Adding certificates to the operating system's trusted root certificates increases the risk of legitimizing untrusted certificates.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5382_Rule_Security struct{}

func (r *CA5382_Rule_Security) ID() string      { return "CA5382" }
func (r *CA5382_Rule_Security) Severity() int   { return 5 }
func (r *CA5382_Rule_Security) Rule() string    { return "Use secure cookies in ASP.NET Core" }
func (r *CA5382_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5382_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5382_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5382, "When an application is available over HTTPS, cookies should be marked as secure to prevent them from being sent over unencrypted connections.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5383_Rule_Security struct{}

func (r *CA5383_Rule_Security) ID() string      { return "CA5383" }
func (r *CA5383_Rule_Security) Severity() int   { return 5 }
func (r *CA5383_Rule_Security) Rule() string    { return "Ensure use of secure cookies in ASP.NET Core" }
func (r *CA5383_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5383_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5383_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5383, "When an application is available over HTTPS, cookies should be marked as secure to prevent them from being sent over unencrypted connections.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5384_Rule_Security struct{}

func (r *CA5384_Rule_Security) ID() string      { return "CA5384" }
func (r *CA5384_Rule_Security) Severity() int   { return 5 }
func (r *CA5384_Rule_Security) Rule() string    { return "Do not use digital signature algorithm (DSA)" }
func (r *CA5384_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5384_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5384_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5384, "The Digital Signature Algorithm (DSA) is weak. Use a more secure algorithm like RSA or ECDSA.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5385_Rule_Security struct{}

func (r *CA5385_Rule_Security) ID() string    { return "CA5385" }
func (r *CA5385_Rule_Security) Severity() int { return 5 }
func (r *CA5385_Rule_Security) Rule() string {
	return "Use Rivest-Shamir-Adleman (RSA) algorithm with sufficient key size"
}
func (r *CA5385_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5385_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5385_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5385, "Encryption keys should be at least 2048 bits for adequate security when using RSA algorithm.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5386_Rule_Security struct{}

func (r *CA5386_Rule_Security) ID() string      { return "CA5386" }
func (r *CA5386_Rule_Security) Severity() int   { return 5 }
func (r *CA5386_Rule_Security) Rule() string    { return "Avoid hardcoding SecurityProtocolType value" }
func (r *CA5386_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5386_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5386_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5386, "Hard-coding SecurityProtocolType values may prevent your application from adapting to updated security protocols in the future.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5387_Rule_Security struct{}

func (r *CA5387_Rule_Security) ID() string    { return "CA5387" }
func (r *CA5387_Rule_Security) Severity() int { return 5 }
func (r *CA5387_Rule_Security) Rule() string {
	return "Do not use weak key derivation function with insufficient iteration count"
}
func (r *CA5387_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5387_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5387_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5387, "When deriving cryptographic keys from user-provided passwords, use a sufficiently high iteration count to resist brute force attacks.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5388_Rule_Security struct{}

func (r *CA5388_Rule_Security) ID() string    { return "CA5388" }
func (r *CA5388_Rule_Security) Severity() int { return 5 }
func (r *CA5388_Rule_Security) Rule() string {
	return "Ensure sufficient iteration count when using weak key derivation function"
}
func (r *CA5388_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5388_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5388_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5388, "When deriving cryptographic keys from user-provided passwords, use a sufficiently high iteration count to resist brute force attacks.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5389_Rule_Security struct{}

func (r *CA5389_Rule_Security) ID() string    { return "CA5389" }
func (r *CA5389_Rule_Security) Severity() int { return 5 }
func (r *CA5389_Rule_Security) Rule() string {
	return "Do not add archive item's path to the target file system path"
}
func (r *CA5389_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5389_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5389_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5389, "Archive item path can be relative and can escape the expected file system target, leading to potential overwriting of files outside the expected directory structure.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5390_Rule_Security struct{}

func (r *CA5390_Rule_Security) ID() string      { return "CA5390" }
func (r *CA5390_Rule_Security) Severity() int   { return 5 }
func (r *CA5390_Rule_Security) Rule() string    { return "Do not hard-code encryption key" }
func (r *CA5390_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5390_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5390_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5390, "Hard-coded encryption keys can be easily discovered by attackers and compromise the security of encrypted data.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5391_Rule_Security struct{}

func (r *CA5391_Rule_Security) ID() string    { return "CA5391" }
func (r *CA5391_Rule_Security) Severity() int { return 5 }
func (r *CA5391_Rule_Security) Rule() string {
	return "Use antiforgery tokens in ASP.NET Core MVC controllers"
}
func (r *CA5391_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5391_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5391_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5391, "Controllers handling POST, PUT, PATCH, or DELETE requests should use antiforgery tokens to prevent cross-site request forgery attacks.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5392_Rule_Security struct{}

func (r *CA5392_Rule_Security) ID() string    { return "CA5392" }
func (r *CA5392_Rule_Security) Severity() int { return 5 }
func (r *CA5392_Rule_Security) Rule() string {
	return "Use DefaultDllImportSearchPaths attribute for P/Invokes"
}
func (r *CA5392_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5392_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5392_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5392, "By default, P/Invoke functions using DllImportAttribute probe a number of directories, including the current working directory for the library to load. This can be a security issue for certain applications, leading to DLL hijacking.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5393_Rule_Security struct{}

func (r *CA5393_Rule_Security) ID() string      { return "CA5393" }
func (r *CA5393_Rule_Security) Severity() int   { return 5 }
func (r *CA5393_Rule_Security) Rule() string    { return "Do not use unsafe DllImportSearchPath value" }
func (r *CA5393_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5393_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5393_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5393, "There could be a malicious DLL in the default DLL search directories. Or, depending on where your application is run from, there could be a malicious DLL in the application's directory.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5394_Rule_Security struct{}

func (r *CA5394_Rule_Security) ID() string      { return "CA5394" }
func (r *CA5394_Rule_Security) Severity() int   { return 5 }
func (r *CA5394_Rule_Security) Rule() string    { return "Do not use insecure randomness" }
func (r *CA5394_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5394_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5394_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5394, "System.Random is not cryptographically secure. Use System.Security.Cryptography.RandomNumberGenerator for cryptographic purposes.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5395_Rule_Security struct{}

func (r *CA5395_Rule_Security) ID() string      { return "CA5395" }
func (r *CA5395_Rule_Security) Severity() int   { return 5 }
func (r *CA5395_Rule_Security) Rule() string    { return "Miss HttpVerb attribute for action methods" }
func (r *CA5395_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5395_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5395_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5395, "Action methods should specify which HTTP verbs they accept to prevent unintended functionality from being accessible via different HTTP methods.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5396_Rule_Security struct{}

func (r *CA5396_Rule_Security) ID() string      { return "CA5396" }
func (r *CA5396_Rule_Security) Severity() int   { return 5 }
func (r *CA5396_Rule_Security) Rule() string    { return "Set HttpOnly to true for HttpCookies" }
func (r *CA5396_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5396_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5396_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5396, "As a defense in depth measure, ensure security sensitive HTTP cookies are marked as HttpOnly. This indicates web browsers should disallow scripts from accessing the cookies.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5397_Rule_Security struct{}

func (r *CA5397_Rule_Security) ID() string      { return "CA5397" }
func (r *CA5397_Rule_Security) Severity() int   { return 5 }
func (r *CA5397_Rule_Security) Rule() string    { return "Do not use deprecated SslProtocols values" }
func (r *CA5397_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5397_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5397_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5397, "SSL 3.0 and TLS 1.0 protocols are obsolete and considered insecure. Use TLS 1.2 or higher.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5398_Rule_Security struct{}

func (r *CA5398_Rule_Security) ID() string      { return "CA5398" }
func (r *CA5398_Rule_Security) Severity() int   { return 5 }
func (r *CA5398_Rule_Security) Rule() string    { return "Avoid hardcoded SslProtocols values" }
func (r *CA5398_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5398_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5398_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5398, "Hard-coding SslProtocols values may prevent your application from adapting to updated security protocols in the future.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5399_Rule_Security struct{}

func (r *CA5399_Rule_Security) ID() string      { return "CA5399" }
func (r *CA5399_Rule_Security) Severity() int   { return 5 }
func (r *CA5399_Rule_Security) Rule() string    { return "Enable HttpsRedirection for aspnetcore project" }
func (r *CA5399_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5399_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5399_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5399, "HTTP requests should be redirected to HTTPS to ensure communication is encrypted and secure.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5400_Rule_Security struct{}

func (r *CA5400_Rule_Security) ID() string    { return "CA5400" }
func (r *CA5400_Rule_Security) Severity() int { return 5 }
func (r *CA5400_Rule_Security) Rule() string {
	return "Ensure HttpRequestMessage.GetOwinContext is not called"
}
func (r *CA5400_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5400_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5400_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5400, "The HttpRequestMessage.GetOwinContext extension method and the OwinContext class are intended for use with Microsoft OWIN framework and should not be used in ASP.NET Core applications.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5401_Rule_Security struct{}

func (r *CA5401_Rule_Security) ID() string      { return "CA5401" }
func (r *CA5401_Rule_Security) Severity() int   { return 5 }
func (r *CA5401_Rule_Security) Rule() string    { return "Do not use CreateEncryptor with non-default IV" }
func (r *CA5401_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5401_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5401_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5401, "Using the same initialization vector (IV) with symmetric encryption can allow an attacker to see patterns in the encrypted data.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5402_Rule_Security struct{}

func (r *CA5402_Rule_Security) ID() string      { return "CA5402" }
func (r *CA5402_Rule_Security) Severity() int   { return 5 }
func (r *CA5402_Rule_Security) Rule() string    { return "Use CreateDecryptor with the default IV" }
func (r *CA5402_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5402_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5402_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5402, "Using the same initialization vector (IV) with symmetric encryption can allow an attacker to see patterns in the encrypted data.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5403_Rule_Security struct{}

func (r *CA5403_Rule_Security) ID() string      { return "CA5403" }
func (r *CA5403_Rule_Security) Severity() int   { return 5 }
func (r *CA5403_Rule_Security) Rule() string    { return "Do not hard-code certificate" }
func (r *CA5403_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5403_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5403_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5403, "Hard-coded certificates in source code can be easily discovered by attackers and may lead to security vulnerabilities.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5404_Rule_Security struct{}

func (r *CA5404_Rule_Security) ID() string      { return "CA5404" }
func (r *CA5404_Rule_Security) Severity() int   { return 5 }
func (r *CA5404_Rule_Security) Rule() string    { return "Do not disable token validation checks" }
func (r *CA5404_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5404_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5404_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5404, "Disabling token validation checks can lead to security vulnerabilities. Ensure that all token validation parameters are properly configured and not disabled.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA5405_Rule_Security struct{}

func (r *CA5405_Rule_Security) ID() string    { return "CA5405" }
func (r *CA5405_Rule_Security) Severity() int { return 5 }
func (r *CA5405_Rule_Security) Rule() string {
	return "Do not always skip token validation in delegates"
}
func (r *CA5405_Rule_Security) RuleSet() string { return "Security" }
func (r *CA5405_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA5405_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA5405, "Always skipping token validation in delegates can lead to security vulnerabilities. Ensure that token validation is performed appropriately in delegate methods.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

// CA2100: Review SQL queries for security vulnerabilities
type CA2100_Rule_Security struct{}

func (r *CA2100_Rule_Security) ID() string    { return "CA2100" }
func (r *CA2100_Rule_Security) Severity() int { return 5 }
func (r *CA2100_Rule_Security) Rule() string {
	return "Review SQL queries for security vulnerabilities"
}
func (r *CA2100_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2100_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2100_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2100, "Review SQL queries for security vulnerabilities", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

// CA2109: Review visible event handlers
type CA2109_Rule_Security struct{}

func (r *CA2109_Rule_Security) ID() string      { return "CA2109" }
func (r *CA2109_Rule_Security) Severity() int   { return 4 }
func (r *CA2109_Rule_Security) Rule() string    { return "Review visible event handlers" }
func (r *CA2109_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2109_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2109_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2109, "Review visible event handlers", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

// CA2119: Seal methods that satisfy private interfaces
type CA2119_Rule_Security struct{}

func (r *CA2119_Rule_Security) ID() string      { return "CA2119" }
func (r *CA2119_Rule_Security) Severity() int   { return 4 }
func (r *CA2119_Rule_Security) Rule() string    { return "Seal methods that satisfy private interfaces" }
func (r *CA2119_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2119_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2119_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2119, "Seal methods that satisfy private interfaces", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

// CA2153: Avoid Handling Corrupted State Exceptions
type CA2153_Rule_Security struct{}

func (r *CA2153_Rule_Security) ID() string      { return "CA2153" }
func (r *CA2153_Rule_Security) Severity() int   { return 4 }
func (r *CA2153_Rule_Security) Rule() string    { return "Avoid Handling Corrupted State Exceptions" }
func (r *CA2153_Rule_Security) RuleSet() string { return "Security" }
func (r *CA2153_Rule_Security) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2153_Rule_Security) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA2153, "Avoid Handling Corrupted State Exceptions", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}
