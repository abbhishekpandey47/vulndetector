package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
)

// --------------- Interoperability Rules ------------------

type CA1401_Rule_Interop struct{}

func (r *CA1401_Rule_Interop) ID() string      { return "CA1401" }
func (r *CA1401_Rule_Interop) Severity() int   { return 4 }
func (r *CA1401_Rule_Interop) Rule() string    { return "P/Invoke method should not be visible" }
func (r *CA1401_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1401_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1401_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1401, "P/Invoke methods should be internal or private to avoid misuse.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1416_Rule_Interop struct{}

func (r *CA1416_Rule_Interop) ID() string      { return "CA1416" }
func (r *CA1416_Rule_Interop) Severity() int   { return 4 }
func (r *CA1416_Rule_Interop) Rule() string    { return "Validate platform compatibility" }
func (r *CA1416_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1416_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1416_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1416, "Ensure platform-specific APIs (e.g., Windows-only) are used only on compatible platforms.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1417_Rule_Interop struct{}

func (r *CA1417_Rule_Interop) ID() string    { return "CA1417" }
func (r *CA1417_Rule_Interop) Severity() int { return 4 }
func (r *CA1417_Rule_Interop) Rule() string {
	return "Do not use OutAttribute on string parameters for P/Invokes"
}
func (r *CA1417_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1417_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1417_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1417, "Avoid OutAttribute on string parameters in P/Invoke to prevent marshaling errors.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1418_Rule_Interop struct{}

func (r *CA1418_Rule_Interop) ID() string      { return "CA1418" }
func (r *CA1418_Rule_Interop) Severity() int   { return 4 }
func (r *CA1418_Rule_Interop) Rule() string    { return "Use valid platform compatibility attributes" }
func (r *CA1418_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1418_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1418_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1418, "Use correct PlatformCompatibility attributes for platform-specific code.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1419_Rule_Interop struct{}

func (r *CA1419_Rule_Interop) ID() string    { return "CA1419" }
func (r *CA1419_Rule_Interop) Severity() int { return 4 }
func (r *CA1419_Rule_Interop) Rule() string {
	return "Provide a parameterless constructor for COM interop"
}
func (r *CA1419_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1419_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1419_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1419, "Provide a parameterless constructor for types exposed to COM.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1420_Rule_Interop struct{}

func (r *CA1420_Rule_Interop) ID() string      { return "CA1420" }
func (r *CA1420_Rule_Interop) Severity() int   { return 4 }
func (r *CA1420_Rule_Interop) Rule() string    { return "Runtime marshalling disabled" }
func (r *CA1420_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1420_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1420_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1420, "Ensure runtime marshalling is enabled for P/Invoke or COM interop.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1421_Rule_Interop struct{}

func (r *CA1421_Rule_Interop) ID() string      { return "CA1421" }
func (r *CA1421_Rule_Interop) Severity() int   { return 4 }
func (r *CA1421_Rule_Interop) Rule() string    { return "Avoid deprecated runtime marshalling APIs" }
func (r *CA1421_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1421_Rule_Interop) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA1421_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1421, "Use modern marshalling APIs instead of deprecated ones.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}

type CA1422_Rule_Interop struct{}

func (r *CA1422_Rule_Interop) ID() string      { return "CA1422" }
func (r *CA1422_Rule_Interop) Severity() int   { return 4 }
func (r *CA1422_Rule_Interop) Rule() string    { return "Validate marshalling of delegate parameters" }
func (r *CA1422_Rule_Interop) RuleSet() string { return "Interoperability" }
func (r *CA1422_Rule_Interop) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1422, "Ensure delegate parameters in P/Invoke are marshalled correctly.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}
