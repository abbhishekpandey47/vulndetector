package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	cs "github.com/smacker/go-tree-sitter/csharp"
)

func ClassificationRuleSetDotNet(ruleSet string) string {
	switch ruleSet {
	case "Structure":
		return "Maintainability"
	case "Comments":
		return "Compliance"
	case "Localization":
		return "Compliance"
	case "Integration":
		return "Compliance"
	case "Sustainability":
		return "Maintainability"
	case "Clarity":
		return "Maintainability"
	case "Efficiency":
		return "Performance"
	case "Stability":
		return "Maintainability"
	case "Vulnerability":
		return "Security"
	case "Deployment":
		return "Compliance"
	case "Correctness":
		return "Maintainability"
	default:
		return ""
	}
}

// Base Function template
func analyzeRule(queryStr string, desc string, rule string, ruleset string, severity int, tree *sitter.Tree) []core.Issue {
	if tree == nil {
		return nil
	}

	root := tree.RootNode()
	if root == nil {
		return nil
	}

	var issues []core.Issue
	q, err := sitter.NewQuery([]byte(queryStr), cs.GetLanguage())
	if err != nil {
		// Log the error and return empty issues
		return nil
	}

	cursor := sitter.NewQueryCursor()
	if cursor == nil {
		return nil
	}
	defer cursor.Close()
	cursor.Exec(q, root)
	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        rule,
				RuleSet:     ruleset,
				Description: desc,
				Priority:    severity,
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}
	return issues
}
