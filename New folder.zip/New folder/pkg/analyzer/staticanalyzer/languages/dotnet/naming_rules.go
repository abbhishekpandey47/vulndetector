package sca_csharp

 import (
 	core "github.com/scanner/pkg/analyzer/staticanalyzer"
 	sitter "github.com/smacker/go-tree-sitter"
 )

 type CA1700_Rule_Naming struct{}

 var CA1700_Rule = &CA1700_Rule_Naming{}

 func (r *CA1700_Rule_Naming) ID() string      { return "CA1700" }
 func (r *CA1700_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1700_Rule_Naming) Rule() string    { return "Do not name enum values 'Reserved'" }
 func (r *CA1700_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1700_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1700_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1700, "Avoid naming enum values 'Reserved' to prevent conflicts in COM interop.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1707_Rule_Naming struct{}

 var CA1707_Rule = &CA1707_Rule_Naming{}

 func (r *CA1707_Rule_Naming) ID() string      { return "CA1707" }
 func (r *CA1707_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1707_Rule_Naming) Rule() string    { return "Identifiers should not contain underscores" }
 func (r *CA1707_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1707_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1707_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1707, "Avoid underscores in identifiers for consistency with .NET naming conventions.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1708_Rule_Naming struct{}

 var CA1708_Rule = &CA1708_Rule_Naming{}

 func (r *CA1708_Rule_Naming) ID() string      { return "CA1708" }
 func (r *CA1708_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1708_Rule_Naming) Rule() string    { return "Identifiers should differ by more than case" }
 func (r *CA1708_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1708_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1708_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1708, "Ensure identifiers differ by more than case to avoid confusion.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1710_Rule_Naming struct{}

 var CA1710_Rule = &CA1710_Rule_Naming{}

 func (r *CA1710_Rule_Naming) ID() string      { return "CA1710" }
 func (r *CA1710_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1710_Rule_Naming) Rule() string    { return "Identifiers should have correct suffix" }
 func (r *CA1710_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1710_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1710_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1710, "Use suffixes like 'Collection' or 'Dictionary' for collection types.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1711_Rule_Naming struct{}

 var CA1711_Rule = &CA1711_Rule_Naming{}

 func (r *CA1711_Rule_Naming) ID() string      { return "CA1711" }
 func (r *CA1711_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1711_Rule_Naming) Rule() string    { return "Identifiers should not have incorrect suffix" }
 func (r *CA1711_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1711_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1711_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1711, "Avoid misleading suffixes like 'Stream' or 'Event' on non-standard types.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1712_Rule_Naming struct{}

 var CA1712_Rule = &CA1712_Rule_Naming{}

 func (r *CA1712_Rule_Naming) ID() string      { return "CA1712" }
 func (r *CA1712_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1712_Rule_Naming) Rule() string    { return "Do not prefix enum values with type name" }
 func (r *CA1712_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1712_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1712_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1712, "Avoid prefixing enum values with the enum type name for clarity.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1713_Rule_Naming struct{}

 var CA1713_Rule = &CA1713_Rule_Naming{}

 func (r *CA1713_Rule_Naming) ID() string      { return "CA1713" }
 func (r *CA1713_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1713_Rule_Naming) Rule() string    { return "Events should not have before or after prefix" }
 func (r *CA1713_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1713_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1713_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1713, "Avoid 'Before' or 'After' prefixes in event names for simplicity.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1714_Rule_Naming struct{}

 var CA1714_Rule = &CA1714_Rule_Naming{}

 func (r *CA1714_Rule_Naming) ID() string      { return "CA1714" }
 func (r *CA1714_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1714_Rule_Naming) Rule() string    { return "Flags enums should have plural names" }
 func (r *CA1714_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1714_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1714_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1714, "Use plural names for enums with FlagsAttribute to indicate multiple values.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1715_Rule_Naming struct{}

 var CA1715_Rule = &CA1715_Rule_Naming{}

 func (r *CA1715_Rule_Naming) ID() string    { return "CA1715" }
 func (r *CA1715_Rule_Naming) Severity() int { return 4 }
 func (r *CA1715_Rule_Naming) Rule() string {
 	return "Identifiers should have correct prefix (interfaces)"
 }
 func (r *CA1715_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1715_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1715_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1715, "Use 'I' for interfaces to follow conventions.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1716_Rule_Naming struct{}

 var CA1716_Rule = &CA1716_Rule_Naming{}

 func (r *CA1716_Rule_Naming) ID() string      { return "CA1716" }
 func (r *CA1716_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1716_Rule_Naming) Rule() string    { return "Identifiers should not match keywords" }
 func (r *CA1716_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1716_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1716_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1716, "Avoid using language keywords as identifiers to prevent confusion.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1717_Rule_Naming struct{}

 var CA1717_Rule = &CA1717_Rule_Naming{}

 func (r *CA1717_Rule_Naming) ID() string    { return "CA1717" }
 func (r *CA1717_Rule_Naming) Severity() int { return 4 }
 func (r *CA1717_Rule_Naming) Rule() string {
 	return "Only FlagsAttribute enums should have plural names"
 }
 func (r *CA1717_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1717_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1717_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1717, "Use singular names for non-Flags enums to follow conventions.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1720_Rule_Naming struct{}

 var CA1720_Rule = &CA1720_Rule_Naming{}

 func (r *CA1720_Rule_Naming) ID() string      { return "CA1720" }
 func (r *CA1720_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1720_Rule_Naming) Rule() string    { return "Identifiers should not contain type names" }
 func (r *CA1720_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1720_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1720_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1720, "Avoid type names (e.g., 'Int32') in identifiers to improve clarity.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1721_Rule_Naming struct{}

 var CA1721_Rule = &CA1721_Rule_Naming{}

 func (r *CA1721_Rule_Naming) ID() string      { return "CA1721" }
 func (r *CA1721_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1721_Rule_Naming) Rule() string    { return "Property names should not match get methods" }
 func (r *CA1721_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1721_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1721_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1721, "Avoid property names that match get method names to prevent confusion.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1724_Rule_Naming struct{}

 var CA1724_Rule = &CA1724_Rule_Naming{}

 func (r *CA1724_Rule_Naming) ID() string      { return "CA1724" }
 func (r *CA1724_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1724_Rule_Naming) Rule() string    { return "Type names should not match namespaces" }
 func (r *CA1724_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1724_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1724_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1724, "Avoid type names that conflict with common namespaces for clarity.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1725_Rule_Naming struct{}

 var CA1725_Rule = &CA1725_Rule_Naming{}

 func (r *CA1725_Rule_Naming) ID() string      { return "CA1725" }
 func (r *CA1725_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1725_Rule_Naming) Rule() string    { return "Parameter names should match base declaration" }
 func (r *CA1725_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1725_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1725_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1725, "Ensure parameter names in overrides match the base declaration.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }

 type CA1727_Rule_Naming struct{}

 var CA1727_Rule = &CA1727_Rule_Naming{}

 func (r *CA1727_Rule_Naming) ID() string      { return "CA1727" }
 func (r *CA1727_Rule_Naming) Severity() int   { return 4 }
 func (r *CA1727_Rule_Naming) Rule() string    { return "Use PascalCase for named placeholders" }
 func (r *CA1727_Rule_Naming) RuleSet() string { return "Naming" }
 func (r *CA1727_Rule_Naming) Classification() string {
 	return ClassificationRuleSetDotNet(r.RuleSet())
 }
 func (r *CA1727_Rule_Naming) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
 	return analyzeRule(CA1727, "Use PascalCase for named placeholders in strings for consistency.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
 }
