package sca_csharp

import (
	"fmt"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	"github.com/smacker/go-tree-sitter/csharp"
)

type CA2000_Rule_Reliability struct{}

func (r *CA2000_Rule_Reliability) ID() string      { return "CA2000" }
func (r *CA2000_Rule_Reliability) Severity() int   { return 5 }
func (r *CA2000_Rule_Reliability) Rule() string    { return "Dispose objects before losing scope" }
func (r *CA2000_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2000_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2000_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2000), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Priority:    r.Severity(),
				Description: "Dispose objects before losing scope. Because an exceptional event might occur that will prevent the finalizer of an object from running, the object should be explicitly disposed before all references to it are out of scope.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// issue : invalid node type 'this' at line 2 column 0
type CA2002_Rule_Reliability struct{}

func (r *CA2002_Rule_Reliability) ID() string    { return "CA2002" }
func (r *CA2002_Rule_Reliability) Severity() int { return 4 }
func (r *CA2002_Rule_Reliability) Rule() string {
	return "Do not lock on objects with weak identity"
}

func (r *CA2002_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2002_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2002_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2002), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not lock on objects with weak identity. An object is said to have a weak identity when it can be directly accessed across application domain boundaries. A thread that tries to acquire a lock on an object that has a weak identity can be blocked by a second thread in a different application domain that has a lock on the same object.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2007_Rule_Reliability struct{}

func (r *CA2007_Rule_Reliability) ID() string    { return "CA2007" }
func (r *CA2007_Rule_Reliability) Severity() int { return 4 }

func (r *CA2007_Rule_Reliability) Rule() string {
	return "Do not directly await a Task"
}

func (r *CA2007_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2007_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2007_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2007), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not directly await a Task. An asynchronous method awaits a Task directly.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// issue : invalid field 'object' at line 3 column 0 and invalid field 'object' at line 4 column 0
type CA2008_Rule_Reliability struct{}

func (r *CA2008_Rule_Reliability) ID() string    { return "CA2008" }
func (r *CA2008_Rule_Reliability) Severity() int { return 4 }

func (r *CA2008_Rule_Reliability) Rule() string {
	return "Do not create tasks without passing a TaskScheduler"
}

func (r *CA2008_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2008_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2008_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2008), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not create tasks without passing a TaskScheduler. A task creation or continuation operation uses a method overload that does not specify a TaskScheduler parameter.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2009_Rule_Reliability struct{}

func (r *CA2009_Rule_Reliability) ID() string    { return "CA2009" }
func (r *CA2009_Rule_Reliability) Severity() int { return 4 }

func (r *CA2009_Rule_Reliability) Rule() string {
	return "Do not call ToImmutableCollection on an ImmutableCollection value"
}

func (r *CA2009_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2009_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2009_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2009), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not call ToImmutableCollection on an ImmutableCollection value. ToImmutable method was unnecessarily called on an immutable collection from System.Collections.Immutable namespace.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2011_Rule_Reliability struct{}

func (r *CA2011_Rule_Reliability) ID() string    { return "CA2011" }
func (r *CA2011_Rule_Reliability) Severity() int { return 4 }

func (r *CA2011_Rule_Reliability) Rule() string {
	return "Do not assign property within its setter"
}

func (r *CA2011_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2011_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2011_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2011), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not assign property within its setter. A property was accidentally assigned a value within its own set accessor.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2012_Rule_Reliability struct{}

func (r *CA2012_Rule_Reliability) ID() string    { return "CA2012" }
func (r *CA2012_Rule_Reliability) Severity() int { return 5 }

func (r *CA2012_Rule_Reliability) Rule() string {
	return "Use ValueTasks correctly"
}

func (r *CA2012_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2012_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2012_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2012), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Use ValueTasks correctly. ValueTasks returned from member invocations are intended to be directly awaited. Attempts to consume a ValueTask multiple times or to directly access one's result before it's known to be completed may result in an exception or corruption. Ignoring such a ValueTask is likely an indication of a functional bug and may degrade performance.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2013_Rule_Reliability struct{}

func (r *CA2013_Rule_Reliability) ID() string    { return "CA2013" }
func (r *CA2013_Rule_Reliability) Severity() int { return 4 }

func (r *CA2013_Rule_Reliability) Rule() string {
	return "Do not use ReferenceEquals with value types"
}

func (r *CA2013_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2013_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2013_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2013), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not use ReferenceEquals with value types. When comparing values using System.Object.ReferenceEquals, if objA and objB are value types, they are boxed before they are passed to the ReferenceEquals method.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// issue : invalid unknown at line 4 column 0 (array_creation_expression) @alloc)))
type CA2014_Rule_Reliability struct{}

func (r *CA2014_Rule_Reliability) ID() string    { return "CA2014" }
func (r *CA2014_Rule_Reliability) Severity() int { return 5 }

func (r *CA2014_Rule_Reliability) Rule() string {
	return "Do not use stackalloc in loops"
}

func (r *CA2014_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2014_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2014_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2014), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not use stackalloc in loops. Stack space allocated by a stackalloc is only released at the end of the current method's invocation. Using it in a loop can result in unbounded stack growth and eventual stack overflow conditions.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// issue : invalid node type 'base_type' at line 3 column 0

type CA2015_Rule_Reliability struct{}

func (r *CA2015_Rule_Reliability) ID() string    { return "CA2015" }
func (r *CA2015_Rule_Reliability) Severity() int { return 5 }

func (r *CA2015_Rule_Reliability) Rule() string {
	return "Do not define finalizers for types derived from MemoryManager<T>"
}

func (r *CA2015_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2015_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2015_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2015), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not define finalizers for types derived from MemoryManager<T>. Adding a finalizer to a type derived from MemoryManager<T> may permit memory to be freed while it is still in use by a Span<T>.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2016_Rule_Reliability struct{}

func (r *CA2016_Rule_Reliability) ID() string    { return "CA2016" }
func (r *CA2016_Rule_Reliability) Severity() int { return 4 }

func (r *CA2016_Rule_Reliability) Rule() string {
	return "Forward the CancellationToken parameter to methods that take one"
}

func (r *CA2016_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2016_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2016_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2016), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Forward the CancellationToken parameter to methods that take one. Forwarding the CancellationToken ensures operation cancellation notifications are properly propagated.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2017_Rule_Reliability struct{}

func (r *CA2017_Rule_Reliability) ID() string    { return "CA2017" }
func (r *CA2017_Rule_Reliability) Severity() int { return 4 }

func (r *CA2017_Rule_Reliability) Rule() string {
	return "Parameter count mismatch"
}

func (r *CA2017_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2017_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2017_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2017), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Parameter count mismatch. Number of parameters supplied in the logging message template do not match the number of named placeholders.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// issue : invalid field 'object' at line 3 column 0
type CA2018_Rule_Reliability struct{}

func (r *CA2018_Rule_Reliability) ID() string    { return "CA2018" }
func (r *CA2018_Rule_Reliability) Severity() int { return 4 }

func (r *CA2018_Rule_Reliability) Rule() string {
	return "The count argument to Buffer.BlockCopy should specify the number of bytes to copy"
}

func (r *CA2018_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2018_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2018_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2018), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "The count argument to Buffer.BlockCopy should specify the number of bytes to copy. You should only use Array.Length for the count argument on arrays whose elements are exactly one byte in size.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2019_Rule_Reliability struct{}

func (r *CA2019_Rule_Reliability) ID() string    { return "CA2019" }
func (r *CA2019_Rule_Reliability) Severity() int { return 4 }

func (r *CA2019_Rule_Reliability) Rule() string {
	return "ThreadStatic fields should not use inline initialization"
}

func (r *CA2019_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2019_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2019_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2019), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "ThreadStatic fields should not use inline initialization. A field that's annotated with ThreadStaticAttribute is initialized inline or explicitly in a static constructor.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2020_Rule_Reliability struct{}

func (r *CA2020_Rule_Reliability) ID() string    { return "CA2020" }
func (r *CA2020_Rule_Reliability) Severity() int { return 4 }

func (r *CA2020_Rule_Reliability) Rule() string {
	return "Prevent behavioral change caused by built-in operators of IntPtr/UIntPtr"
}

func (r *CA2020_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2020_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2020_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2020), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Prevent behavioral change caused by built-in operators of IntPtr/UIntPtr. Some built-in operators added in .NET 7 behave differently than the user-defined operators in .NET 6 and earlier versions.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

// issue : invalid syntax at line 4 column 1
type CA2021_Rule_Reliability struct{}

func (r *CA2021_Rule_Reliability) ID() string    { return "CA2021" }
func (r *CA2021_Rule_Reliability) Severity() int { return 4 }

func (r *CA2021_Rule_Reliability) Rule() string {
	return "Don't call Enumerable.Cast<T> or Enumerable.OfType<T> with incompatible types"
}

func (r *CA2021_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2021_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2021_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2021), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Don't call Enumerable.Cast<T> or Enumerable.OfType<T> with incompatible types. The type parameter specified is incompatible with the type of the input collection.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2022_Rule_Reliability struct{}

func (r *CA2022_Rule_Reliability) ID() string    { return "CA2022" }
func (r *CA2022_Rule_Reliability) Severity() int { return 5 }

func (r *CA2022_Rule_Reliability) Rule() string {
	return "Avoid inexact read with Stream.Read"
}

func (r *CA2022_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2022_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2022_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2022), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Avoid inexact read with Stream.Read. A call to Stream.Read might return fewer bytes than requested, resulting in unreliable code if the return value isn't checked.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA2024_Rule_Reliability struct{}

func (r *CA2024_Rule_Reliability) ID() string    { return "CA2024" }
func (r *CA2024_Rule_Reliability) Severity() int { return 4 }

func (r *CA2024_Rule_Reliability) Rule() string {
	return "Do not use StreamReader.EndOfStream in async methods"
}

func (r *CA2024_Rule_Reliability) RuleSet() string { return "Reliability" }
func (r *CA2024_Rule_Reliability) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}
func (r *CA2024_Rule_Reliability) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	q, err := sitter.NewQuery([]byte(CA2024), csharp.GetLanguage())
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer q.Close()

	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:        r.Rule(),
				RuleSet:     r.RuleSet(),
				Description: "Do not use StreamReader.EndOfStream in async methods. It can cause unintended synchronous blocking when no data is buffered. Use StreamReader.ReadLineAsync() instead.",
				BeginLine:   int(node.StartPoint().Row + 1),
				BeginColumn: int(node.StartPoint().Column + 1),
				EndLine:     int(node.EndPoint().Row + 1),
				EndColumn:   int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}
