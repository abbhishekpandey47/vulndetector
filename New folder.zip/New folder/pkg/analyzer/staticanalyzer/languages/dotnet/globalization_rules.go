package sca_csharp

import (
	"strings"

	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
	csharp "github.com/smacker/go-tree-sitter/csharp"
)

// --------------- Globalization Rules ------------------

type CA1303_Rule_Globalization struct{}

func (r *CA1303_Rule_Globalization) Rule() string    { return "CA1303" }
func (r *CA1303_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1303_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1303_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(argument_list (string_literal) @literal)`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			node := cap.Node
			issues = append(issues, core.Issue{
				Rule:           r.Rule(),
				RuleSet:        r.RuleSet(),
				Classification: r.Classification(),
				Description:    "Use resource strings instead of literals for localized text to support internationalization.",
				BeginLine:      int(node.StartPoint().Row + 1),
				BeginColumn:    int(node.StartPoint().Column + 1),
				EndLine:        int(node.EndPoint().Row + 1),
				EndColumn:      int(node.EndPoint().Column + 1),
			})
		}
	}

	return issues
}

type CA1304_Rule_Globalization struct{}

func (r *CA1304_Rule_Globalization) Rule() string    { return "CA1304" }
func (r *CA1304_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1304_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1304_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	// Check for methods like ToLower without CultureInfo
	query := `(invocation_expression
 				member_access_expression
 				(name: (identifier) @method_name))`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			if string(cap.Node.Content(source)) == "ToLower" {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Specify CultureInfo for culture-sensitive string operations (e.g., ToLower) to ensure consistent behavior.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1305_Rule_Globalization struct{}

func (r *CA1305_Rule_Globalization) Rule() string    { return "CA1305" }
func (r *CA1305_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1305_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1305_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression
 				member_access_expression
 				(name: (identifier) @method_name))`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := string(cap.Node.Content(source))
			if name == "Parse" || name == "ToString" || name == "Format" {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Use IFormatProvider for culture-sensitive formatting (e.g., int.Parse) to avoid locale-specific errors.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1307_Rule_Globalization struct{}

func (r *CA1307_Rule_Globalization) Rule() string    { return "CA1307" }
func (r *CA1307_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1307_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1307_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression
 				member_access_expression
 				(name: (identifier) @method_name))`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			name := string(cap.Node.Content(source))
			if name == "Equals" || name == "IndexOf" || name == "StartsWith" || name == "EndsWith" {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Use StringComparison overloads for culture-sensitive string operations to improve clarity.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1308_Rule_Globalization struct{}

func (r *CA1308_Rule_Globalization) Rule() string    { return "CA1308" }
func (r *CA1308_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1308_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1308_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression
 				member_access_expression
 				(name: (identifier) @method_name))`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			if string(cap.Node.Content(source)) == "ToLower" {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Normalize strings to uppercase for consistency in culture-sensitive operations.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1309_Rule_Globalization struct{}

func (r *CA1309_Rule_Globalization) Rule() string    { return "CA1309" }
func (r *CA1309_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1309_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1309_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression
 				(argument_list) @args)`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			argText := string(cap.Node.Content(source))
			if !strings.Contains(argText, "StringComparison.Ordinal") {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Use ordinal StringComparison for non-linguistic string comparisons to ensure performance and correctness.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1310_Rule_Globalization struct{}

func (r *CA1310_Rule_Globalization) Rule() string    { return "CA1310" }
func (r *CA1310_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1310_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1310_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression (argument_list) @args)`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			argText := string(cap.Node.Content(source))
			if strings.Contains(argText, "StringComparison") && !strings.Contains(argText, "CultureInfo") {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Specify CultureInfo with StringComparison for culture-aware string comparisons.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1311_Rule_Globalization struct{}

func (r *CA1311_Rule_Globalization) Rule() string    { return "CA1311" }
func (r *CA1311_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1311_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1311_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression (argument_list) @args)`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			argText := string(cap.Node.Content(source))
			if !strings.Contains(argText, "StringComparison") && !strings.Contains(argText, "CultureInfo") {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Use CultureInfo in overloads lacking StringComparison to ensure culture-aware behavior.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}

type CA1312_Rule_Globalization struct{}

func (r *CA1312_Rule_Globalization) Rule() string    { return "CA1312" }
func (r *CA1312_Rule_Globalization) RuleSet() string { return "Localization" }
func (r *CA1312_Rule_Globalization) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1312_Rule_Globalization) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	tree := rawAST.(*sitter.Tree)
	root := tree.RootNode()
	var issues []core.Issue

	query := `(invocation_expression
 				(member_access_expression (identifier) @method_name))`
	q, err := sitter.NewQuery([]byte(query), csharp.GetLanguage())
	if err != nil {
		return issues
	}
	defer q.Close()
	cursor := sitter.NewQueryCursor()
	defer cursor.Close()
	cursor.Exec(q, root)

	for {
		match, ok := cursor.NextMatch()
		if !ok {
			break
		}
		for _, cap := range match.Captures {
			method := string(cap.Node.Content(source))
			if method == "Parse" || method == "ToString" || method == "Format" {
				issues = append(issues, core.Issue{
					Rule:           r.Rule(),
					RuleSet:        r.RuleSet(),
					Classification: r.Classification(),
					Description:    "Use culture-aware API overloads (e.g., with CultureInfo) for consistent localization.",
					BeginLine:      int(cap.Node.StartPoint().Row + 1),
					BeginColumn:    int(cap.Node.StartPoint().Column + 1),
					EndLine:        int(cap.Node.EndPoint().Row + 1),
					EndColumn:      int(cap.Node.EndPoint().Column + 1),
				})
			}
		}
	}

	return issues
}
