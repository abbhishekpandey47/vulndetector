package sca_csharp

import (
	core "github.com/scanner/pkg/analyzer/staticanalyzer"
	sitter "github.com/smacker/go-tree-sitter"
)

// --------------- Documentation Rules ------------------ //

type CA1200_Rule_Documentation struct{}

func (r *CA1200_Rule_Documentation) ID() string      { return "CA1200" }
func (r *CA1200_Rule_Documentation) Severity() int   { return 4 }
func (r *CA1200_Rule_Documentation) Rule() string    { return "Avoid using cref tags with a prefix" }
func (r *CA1200_Rule_Documentation) RuleSet() string { return "Documentation" }
func (r *CA1200_Rule_Documentation) Classification() string {
	return ClassificationRuleSetDotNet(r.RuleSet())
}

func (r *CA1200_Rule_Documentation) Analyze(rawAST interface{}, source []byte, _ core.Language) []core.Issue {
	return analyzeRule(CA1200, "Avoid prefixes like 'T:', 'M:' in cref tags for clarity.", r.Rule(), r.RuleSet(), r.Severity(), rawAST.(*sitter.Tree))
}
