package staticanalyzer

import (
	"github.com/scanner/models"
	sitter "github.com/smacker/go-tree-sitter"
)

// Language defines a programming language plugin
type Language interface {
	SupportedExtensions() []string
	Parse(filename string) (interface{}, error)
	GetRules() []Rule
	CollectMetrics(node *sitter.Tree, src []byte) FileMetrics
}

// Rule defines a static analysis rule
type Rule interface {
	//ID() string
	Analyze(ast interface{}, source []byte, lang Language) []Issue
	//Severity() string // "error", "warning", "info"
}

// Issue represents a detected problem
type Issue struct {
	BeginLine      int    `json:"beginline"`
	BeginColumn    int    `json:"begincolumn"`
	EndLine        int    `json:"endline"`
	EndColumn      int    `json:"endcolumn"`
	Description    string `json:"description"`
	Rule           string `json:"rule"`
	RuleSet        string `json:"ruleset"`
	Classification string `json:"classification"`
	Priority       int    `json:"priority"`
	//FilePath       string `json:"file_path"`
}

type FileMetrics struct {
	PublicConstantCount   int `json:"public_constant_count,omitempty"`
	PrivateConstantCount  int `json:"private_constant_count,omitempty"`
	PublicMethodCount     int `json:"public_method_count,omitempty"`
	PrivateMethodCount    int `json:"private_method_count,omitempty"`
	UtilityMethodCount    int `json:"utility_method_count,omitempty"`
	InstanceVariableCount int `json:"instance_variable_count,omitempty"`
	InnerClassCount       int `json:"inner_class_count,omitempty"`
}

type FileResult struct {
	Filename              string  `json:"filename"`
	PublicConstantCount   int     `json:"public_constant_count"`
	PrivateConstantCount  int     `json:"private_constant_count"`
	PublicMethodCount     int     `json:"public_method_count"`
	PrivateMethodCount    int     `json:"private_method_count"`
	UtilityMethodCount    int     `json:"utility_method_count"`
	InstanceVariableCount int     `json:"instance_variable_count"`
	InnerClassCount       int     `json:"inner_class_count"`
	Violations            []Issue `json:"violations"`
}

type Stats struct {
	ClassCount                 int `json:"class_count"`
	AbstractClassCount         int `json:"abstract_class_count"`
	GenericClassCount          int `json:"generic_class_count"`
	EJBInterfaceCount          int `json:"ejb_interface_count"`
	InterfaceCount             int `json:"interface_count"`
	InterfaceMethodCount       int `json:"interface_method_count"`
	FinalClassCount            int `json:"final_class_count"`
	PackageProtectedClassCount int `json:"package_protected_class_count"`
	PublicConstantCount        int `json:"public_constant_count"`
	PrivateConstantCount       int `json:"private_constant_count"`
	PublicMethodCount          int `json:"public_method_count"`
	PrivateMethodCount         int `json:"private_method_count"`
	UtilityMethodCount         int `json:"utility_method_count"`
	GenericMethodCount         int `json:"generic_method_count"`
	InstanceVariableCount      int `json:"instance_variable_count"`
	AnnotationCount            int `json:"annotation_count"`
	EnumCount                  int `json:"enum_count"`
	ConstructorCount           int `json:"constructor_count"`
	RecordCount                int `json:"record_count"`
	ConstantCount              int `json:"constant_count"`
	StaticInitializerCount     int `json:"static_initializer_count"`
	EJBClassCount              int `json:"ejb_class_count"`
	LocalVariableCount         int `json:"local_variable_count"`
	GenericNaming              int `json:"generic_naming"`
	General                    int `json:"general"`
}

type DotNetStats struct {
	AssemblyCount      int `json:"assembly_count"`
	ClassCount         int `json:"class_count"`
	EnumCount          int `json:"enum_count"`
	EventCount         int `json:"event_count"`
	FieldCount         int `json:"field_count"`
	FileCount          int `json:"file_count"`
	InterfaceCount     int `json:"interface_count"`
	MethodCount        int `json:"method_count"`
	NamespaceCount     int `json:"namespace_count"`
	ObjectCount        int `json:"object_count"`
	ParameterCount     int `json:"parameter_count"`
	PropertyCount      int `json:"property_count"`
	ResourceCount      int `json:"resource_count"`
	StringLiteralCount int `json:"string_literal_count"`
	StructCount        int `json:"struct_count"`
	VariableCount      int `json:"variable_count"`
	General            int `json:"general"`
}

type ResultSet struct {
	FormatVersion int `json:"formatVersion"`
	//PmdVersion    string       `json:"pmdVersion"`
	Timestamp string       `json:"timestamp"`
	Files     []FileResult `json:"files"`
	Stats     interface{}  `json:"project_stats"`
}

type ScanResultsWrapper struct {
	ScanRequest models.ScanRequest `json:"scan_request"`
	TechStack   string             `json:"tech_stack"`
	ScanType    string             `json:"scan_type"`
	ScanResults struct {
		Results []ResultSet `json:"Results"`
	} `json:"scan_results"`
}
