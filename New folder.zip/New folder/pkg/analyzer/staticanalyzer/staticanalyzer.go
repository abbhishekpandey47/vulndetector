package staticanalyzer

import (
	"errors"
	"os"
	"path/filepath"

	sitter "github.com/smacker/go-tree-sitter"
)

// Analyzer coordinates parsing and analysis
type Analyzer struct {
	languages map[string]Language
	rules     []Rule
}

func NewAnalyzer() *Analyzer {
	return &Analyzer{
		languages: make(map[string]Language),
		rules:     []Rule{},
	}
}

func (a *Analyzer) RegisterLanguage(lang Language) {
	for _, ext := range lang.SupportedExtensions() {
		a.languages[ext] = lang
	}
}

// For 250 files its taking around 20 mins. Need to optimize it
// Optimized version with parallel processing and early termination
func (a *Analyzer) ProcessFile(filePath string) ([]Issue, FileMetrics, *sitter.Tree, []byte, error) {
	ext := filepath.Ext(filePath)
	lang, exists := a.languages[ext]
	if !exists {
		return nil, FileMetrics{}, nil, nil, nil
	}

	sourceCode, err := os.ReadFile(filePath)
	if err != nil {
		return nil, FileMetrics{}, nil, nil, err
	}

	ast, err := lang.Parse(filePath)
	if err != nil {
		return nil, FileMetrics{}, nil, nil, err
	}

	langRules := lang.GetRules() // More than 300 rules

	var issues []Issue = []Issue{} // Default to empty, not nil

	for _, rule := range langRules {
		ruleIssues := rule.Analyze(ast, sourceCode, lang)
		issues = append(issues, ruleIssues...)
	}

	tree, ok := ast.(*sitter.Tree)
	if !ok {
		return nil, FileMetrics{}, nil, nil, errors.New("unexpected AST type")
	}

	metrics := lang.CollectMetrics(tree, sourceCode)

	return issues, metrics, tree, sourceCode, nil
}
