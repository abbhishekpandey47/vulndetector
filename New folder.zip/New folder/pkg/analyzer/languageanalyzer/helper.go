package languageanalyzer

import (
	"archive/zip"
	"bufio"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/scanner/constant"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	"github.com/sirupsen/logrus"
)

var extensionLanguageMap = map[string]string{
	// backend_api
	".java":  "Java",
	".jsp":   "Java",
	".py":    "Python",
	".js":    "JavaScript",
	".ts":    "TypeScript",
	".go":    "Go",
	".cs":    "C#",
	".php":   "PHP",
	".rb":    "Ruby",
	".kt":    "Kotlin",
	".scala": "Scala",
	".c":     "C",
	".cpp":   "C++",
	".h":     "C/C++ Header",
	".hpp":   "C++ Header",

	// ui_frontend
	".html": ".HTML",
	".htm":  ".HTML",
	".css":  "CSS",
	".jsx":  "JavaScript (React)",
	".tsx":  "TypeScript (React)",
	".scss": "SCSS",
	".sass": "SASS",
	".less": "LESS",
	".vue":  "Vue",

	// mobile
	".xml":        "XML",
	".gradle":     "Gradle",
	".swift":      "Swift",
	".plist":      "Property List",
	".xib":        "Interface Builder",
	".storyboard": "Storyboard",
	".dart":       "Dart",
	".yaml":       "YAML",

	// embedded
	".asm":     "Assembly",
	".s":       "Assembly",
	".S":       "Assembly",
	".vhd":     "VHDL",
	".vhdl":    "VHDL",
	".v":       "Verilog",
	".sv":      "SystemVerilog",
	"Makefile": "Makefile",
	".mk":      "Makefile",
	".hex":     "HEX",
	".bin":     "Binary",

	// scripting_config
	".yml":  "YAML",
	".json": "JSON",
	".ini":  "INI",
	".cfg":  "Config",
	".sh":   "Shell",
	".bash": "Shell",
	".zsh":  "Shell",
	".bat":  "Batch",
	".cmd":  "Batch",
	".ps1":  "PowerShell",

	// dotnet
	".vb":     "VB.NET",
	".vbproj": "VB.NET Project",
	".csproj": "C# Project",
	".sln":    "Solution",
	".config": "Config",
	".resx":   "Resource File",
	".aspx":   "ASP.NET",
	".ascx":   "ASP.NET",
	".ashx":   "ASP.NET",
	".asmx":   "ASP.NET",
	".axd":    "ASP.NET",
	".rdlc":   "Report Definition",
	".xaml":   "XAML",
}

var ignoredExtensions = map[string]bool{
	".git":  true,
	".rev":  true,
	".idx":  true,
	".pack": true,
}

// Helper function to check if a value is in the array (to prevent duplicates)
func contains(slice []string, value string) bool {
	for _, item := range slice {
		if item == value {
			return true
		}
	}
	return false
}

// Helper function to count the lines of a file
func countLines(filePath string) int {

	data, err := os.ReadFile(filePath)
	if err != nil {
		return 0
	}
	return len(strings.Split(string(data), "\n"))
}

func getJavaScriptVersionFromPackageJSON(filePath string) (string, error) {
	// Read the package.json file
	fileContent, err := os.ReadFile(filePath)
	if err != nil {
		return "", err
	}

	// Parse the JSON content
	var packageData models.PackageJSON
	err = json.Unmarshal(fileContent, &packageData)
	if err != nil {
		return "", err
	}

	// Check if the "node" version is defined in the "engines" field
	if nodeVersion, exists := packageData.Engines["node"]; exists {
		return nodeVersion, nil
	}

	// If no version is specified, return a message or error
	return "", fmt.Errorf("Node.js version not specified")
}

func getDotNetVersionFromCsproj(filePath string) (string, error) {
	// Read the content of the .csproj file
	data, err := os.ReadFile(filePath)
	if err != nil {
		return "", err
	}

	// Check if the file contains "TargetFramework" or "TargetFrameworkVersion"
	var csproj models.Csproj
	err = xml.Unmarshal(data, &csproj)
	if err != nil {
		return "", err
	}

	// If "TargetFramework" or "TargetFrameworks" is found, return the version
	if csproj.TargetFramework != "" {
		return csproj.TargetFramework, nil
	}

	// If "TargetFrameworkVersion" is found, return the version (for .NET Framework)
	if csproj.TargetFrameworkVersion != "" {
		return csproj.TargetFrameworkVersion, nil
	}

	return "", nil
}

// Function to get Go version
func getGoVersionFromMod(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		// Look for the line starting with "go "
		if strings.HasPrefix(line, "go ") {
			// Return the version after "go "
			return strings.TrimSpace(line[3:]), nil
		}
	}

	if err := scanner.Err(); err != nil {
		return "", err
	}

	return "", fmt.Errorf("Go version not found in %s", filePath)
}

func getJavaVersionFromPom(filePath string) (string, error) {
	// Open the pom.xml file
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	// Initialize the Project struct to unmarshal the XML content
	var project models.Project
	decoder := xml.NewDecoder(file)
	if err := decoder.Decode(&project); err != nil {
		return "", err
	}

	// If the java.version element is found, return its value
	if project.Properties.JavaVersion != "" {
		return project.Properties.JavaVersion, nil
	}

	return "", fmt.Errorf("<java.version> not found in %s", filePath)
}

func getTypeScriptVersionFromTsconfig(filePath string) (string, error) {
	// Get the directory of tsconfig.json to find the package.json file
	dir := filepath.Dir(filePath)

	// Look for package.json in the same directory or parent directories
	packageJsonPath := filepath.Join(dir, "package.json")
	if _, err := os.Stat(packageJsonPath); os.IsNotExist(err) {
		return "", fmt.Errorf("package.json not found in directory %s", dir)
	}

	// Read and parse the package.json file
	data, err := os.ReadFile(packageJsonPath)
	if err != nil {
		return "", fmt.Errorf("could not read package.json: %w", err)
	}

	// Create an instance of the PackageJson structure to store dependencies
	var packageJson models.PackageJson
	if err := json.Unmarshal(data, &packageJson); err != nil {
		return "", fmt.Errorf("could not parse package.json: %w", err)
	}

	// Check both dependencies and devDependencies for TypeScript
	if version, ok := packageJson.DevDependencies["typescript"]; ok {
		return cleanVersionString(version), nil
	}
	if version, ok := packageJson.Dependencies["typescript"]; ok {
		return cleanVersionString(version), nil
	}

	return "", fmt.Errorf("TypeScript not found in dependencies or devDependencies")
}

func cleanVersionString(version string) string {
	// Remove leading non-numeric characters like ~, ^, >=, etc.
	return strings.TrimLeft(version, "~^><= ")
}

func ZipResult(scanRequest models.ScanRequest, mode models.Mode) error {
	log := logger.GetLogger()

	tempPath, _ := utils.CreateTempDirectory()
	resultFile := "offline-messages.json"
	MetaDataResultFile := "metadata.json"

	// List of folders you want to zip
	codeHealthScanResultPath, _ := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "code-health")
	CSAScanResultPath, _ := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "cloud-adaptability")
	vulnResultScanResultPath, _ := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "opensource-safety-vulnerability")
	repoTreeResultPath, _ := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "code-tree-structure")
	techStackResultPath, _ := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "tech-stack")
	offlineMessagesJsonResultPath := filepath.Join(tempPath, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, resultFile)
	metadataJsonResultPath := filepath.Join(tempPath, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, MetaDataResultFile)

	folders := []string{
		codeHealthScanResultPath,
		CSAScanResultPath,
		vulnResultScanResultPath,
		repoTreeResultPath,
		techStackResultPath,
	}

	//fileTimeStamp := utils.GetfileNameCurrentTime()
	tempDir, _ := utils.CreateTempDirectory()
	zipFileResultPath := filepath.Join(tempDir, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID)
	// Create the code_analyser directory (if it doesn't exist)
	err := os.MkdirAll(zipFileResultPath, 0777) // 0700 means only the owner can access it
	if err != nil {
		log.WithFields(logrus.Fields{
			"repoPath": zipFileResultPath,
			"error":    err.Error(),
		}).Error("Failed to create zipFileResultPath directory")
		return fmt.Errorf("failed to create zipFileResultPath directory: %w", err)
	}
	//var fileName string
	finalResultFileName := fmt.Sprintf("%s/final-result.zip", zipFileResultPath)
	err = zipFolders(folders, finalResultFileName)
	if err != nil {
		fmt.Println("Error creating zip:", err)
	} else {
		fmt.Println("Zip created successfully for all result file: ", finalResultFileName)
	}

	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"fileName":    finalResultFileName,
		"scannerType": constant.ScannerTypeCompressed,
	}).Info("====InsertResultFileToKafka ====Final Result zip File Generated successfully. ==== API Request Payload == ")

	if mode.Mode == "offline" && err == nil {
		// The JSON files (actual files)
		otherFiles := []string{
			codeHealthScanResultPath,
			CSAScanResultPath,
			vulnResultScanResultPath,
			repoTreeResultPath,
			techStackResultPath,
			offlineMessagesJsonResultPath,
			metadataJsonResultPath,
		}

		// Outer zip file name and path
		fileName := fmt.Sprintf("%s_%s_%s_%s_result.zip",
			scanRequest.TenantID,
			scanRequest.AppID,
			scanRequest.ComponentID,
			scanRequest.ScanResultID)
		outerZipFileName := filepath.Join(tempDir, scanRequest.TenantID, scanRequest.AppID,
			"scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, fileName)

		err = createOuterZip(outerZipFileName, finalResultFileName, otherFiles)
		if err != nil {
			log.WithFields(logrus.Fields{
				"FinalZipFileName": outerZipFileName,
				"error":            err.Error(),
			}).Error("Failed to create Final zip file")
			return fmt.Errorf("failed to create Final zip file: %w", err)
		}
		log.Info("Final zip file created successfully: ", outerZipFileName)
	}

	if constant.APIEnable {
		utils.SendApiRequest(scanRequest, finalResultFileName, constant.ScannerTypeCompressed)
	}

	return nil
}

func zipFolders(folders []string, output string) error {
	zipFile, err := os.Create(output)
	if err != nil {
		return err
	}
	defer zipFile.Close()

	zipWriter := zip.NewWriter(zipFile)
	defer zipWriter.Close()

	for _, folder := range folders {
		err := filepath.Walk(folder, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return err
			}

			// Skip directories (but we still want to create empty ones)
			header, err := zip.FileInfoHeader(info)
			if err != nil {
				return err
			}

			relPath, err := filepath.Rel(filepath.Dir(folder), path)
			if err != nil {
				return err
			}

			header.Name = relPath
			if info.IsDir() {
				header.Name += "/"
			} else {
				header.Method = zip.Deflate
			}

			writer, err := zipWriter.CreateHeader(header)
			if err != nil {
				return err
			}

			// Only write file content if it's not a directory
			if !info.IsDir() {
				file, err := os.Open(path)
				if err != nil {
					return err
				}
				defer file.Close()

				_, err = io.Copy(writer, file)
				if err != nil {
					return err
				}
			}

			return nil
		})

		if err != nil {
			return err
		}
	}

	return nil
}

func createOuterZip(outerZipPath string, innerZipPath string, otherFiles []string) error {
	outFile, err := os.Create(outerZipPath)
	if err != nil {
		return err
	}
	defer outFile.Close()

	zipWriter := zip.NewWriter(outFile)
	defer zipWriter.Close()

	// Add inner zip file (your previously generated zip)
	err = addFileToZip(zipWriter, innerZipPath, filepath.Base(innerZipPath))
	if err != nil {
		return err
	}

	// Add the other files (7 files)
	for _, path := range otherFiles {
		baseName := filepath.Base(path)
		err := addFileToZip(zipWriter, path, baseName)
		if err != nil {
			return err
		}
	}
	return nil
}

// addFileToZip adds a file or directory (recursively) to the zip archive
func addFileToZip(zipWriter *zip.Writer, sourcePath string, baseInZip string) error {
	info, err := os.Stat(sourcePath)
	if err != nil {
		return err
	}

	if info.IsDir() {
		// Walk through the directory
		return filepath.Walk(sourcePath, func(path string, fileInfo os.FileInfo, walkErr error) error {
			if walkErr != nil {
				return walkErr
			}

			// Build zip entry name
			relPath, err := filepath.Rel(sourcePath, path)
			if err != nil {
				return err
			}

			zipEntryName := filepath.Join(baseInZip, relPath)
			zipEntryName = filepath.ToSlash(zipEntryName) // make zip path format

			if fileInfo.IsDir() {
				// Add folder entry (with trailing slash)
				if zipEntryName != "" {
					_, err = zipWriter.Create(zipEntryName + "/")
				}
				return err
			}

			// Add file
			return addSingleFileToZip(zipWriter, path, zipEntryName)
		})
	}

	// If it's a single file
	return addSingleFileToZip(zipWriter, sourcePath, baseInZip)
}

// addSingleFileToZip adds one file to the zip under given entry name
func addSingleFileToZip(zipWriter *zip.Writer, filePath, zipEntryName string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	writer, err := zipWriter.Create(zipEntryName)
	if err != nil {
		return err
	}

	_, err = io.Copy(writer, file)
	return err
}

// deleteExceptFile deletes all files and folders inside dirPath except exceptFileName
func DeleteExceptFile(dirPath, exceptFileName string) error {
	entries, err := os.ReadDir(dirPath)
	if err != nil {
		return err
	}

	for _, entry := range entries {
		name := entry.Name()
		if name == exceptFileName {
			continue // skip the file we want to keep
		}

		fullPath := filepath.Join(dirPath, name)
		err := os.RemoveAll(fullPath)
		if err != nil {
			return err
		}
	}
	return nil
}
