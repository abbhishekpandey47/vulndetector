package languageanalyzer

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path"
	"path/filepath"
	"strings"
	"time"

	"github.com/aquasecurity/trivy/pkg/db"
	"github.com/aquasecurity/trivy/pkg/fanal/artifact"
	"github.com/scanner/constant"
	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/models"
	"github.com/scanner/pkg/cloudSuitabilityAnalyzer"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	util "github.com/scanner/pkg/utils/cloudSuitabilityAnalyzer"
	"github.com/scanner/pkg/vuln_parser/language"

	"github.com/scanner/pkg/vuln_scanner/langpkg"
	"github.com/sirupsen/logrus"

	"github.com/scanner/pkg/analyzer/frameworkanalyzer"
	"github.com/scanner/pkg/analyzer/staticanalyzer/launcher"
	va "github.com/scanner/pkg/vuln_analyzer"
)

func identifyTechStack(path string, scanRequest models.ScanRequest, mode models.Mode) {
	// Get the logger Instance
	log := logger.GetLogger()

	results := types.Results{}

	// Log the start of the scanning process
	log.WithFields(logrus.Fields{"path": path}).Info("Starting to scan directory for tech stack files")

	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.TechStackIdentificationInProgress,
		"progress":    constant.ProgressValueFifteen,
	}).Info("====SendLogMessage ====API: Tech stack identification InProgress.==== payload===")
	log.Println("8th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.TechStackIdentificationInProgress, constant.ProgressValueFifteen)
	log.Println("8th API Request completed====", constant.TechStackIdentificationInProgress)

	// Use a map to avoid duplicates in tech stack and programming languages
	techStackMap := make(map[string]bool)
	programmingLanguagesMap := make(map[string]bool)
	programmingLanguagesVersionMap := make(map[string]string)
	//langMap := make(map[string]string)

	var totalLines int
	var totalFiles int
	fileExtensionCount := make(map[string]int)

	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.TechStackIdentificationCompleted,
		"progress":    constant.ProgressValueTwenty,
	}).Info("====SendLogMessage ====API: Completed tech stack identification.==== payload===")
	log.Println("9th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.TechStackIdentificationCompleted, constant.ProgressValueTwenty)
	log.Println("9th API Request completed====", constant.TechStackIdentificationCompleted)

	// Walk through the directory to identify tech stack files and programming languages
	err := filepath.Walk(path, func(filePath string, info os.FileInfo, err error) error {

		if err != nil {
			utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error walking through directory %v", err))
			utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error walking through directory %v", err), constant.ProgressValueTwenty)
			log.WithFields(logrus.Fields{
				"filePath": filePath,
				"error":    err.Error(),
			}).Error("Error walking through directory")
			return err
		}

		// Skip the entire .git directory (do not count files inside it)
		if info.IsDir() && info.Name() == ".git" {
			return filepath.SkipDir
		}

		// Skip all files inside the .git directory just in case
		if strings.Contains(filePath, string(filepath.Separator)+".git"+string(filepath.Separator)) {
			return nil
		}

		// Only process non-directories (don't count directories)
		if info.IsDir() {
			return nil
		}

		// Extract file extension
		ext := strings.ToLower(filepath.Ext(filePath))

		// Skip files with ignored extensions (like .sample)
		if ignoredExtensions[ext] {
			return nil
		}

		// Increment total files count (only for valid files)
		totalFiles++

		// Increment the file extension count
		if ext != "" {
			fileExtensionCount[ext]++
		} else {
			fileExtensionCount["no_extension"]++
		}

		// Check for known tech stack files and identify programming languages
		// Check for TypeScript-related files
		if strings.Contains(filePath, "tsconfig.json") {
			techStackMap["TypeScript"] = true
			programmingLanguagesMap["TypeScript"] = true
			// Try to get the version for TypeScript from tsconfig.json
			version, err := getTypeScriptVersionFromTsconfig(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap["TypeScript"] = version
			}
		}

		if strings.Contains(filePath, "package.json") {
			techStackMap["JavaScript"] = true
			programmingLanguagesMap["JavaScript"] = true
			// Try to get the version for Go
			version, _ := getJavaScriptVersionFromPackageJSON(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap["JavaScript"] = version
			}
		}
		if strings.Contains(filePath, "go.mod") {
			techStackMap["Go"] = true
			programmingLanguagesMap["Go"] = true
			// Try to get the version for Go
			version, _ := getGoVersionFromMod(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap["Go"] = version
			}

		}
		if strings.Contains(filePath, "pom.xml") {
			techStackMap["Java"] = true
			programmingLanguagesMap["Java"] = true
			// Try to get the Java version from pom.xml
			version, _ := getJavaVersionFromPom(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap["Java"] = version
			}

			analyzedResult, err := callVulnerabiltySacnner(langTypes.Pom, filePath, log, scanRequest)
			if err != nil {
				utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error in parsing java pom.xml for opensource-safety-vulnerability scanner %v", err))
				utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error in parsing java pom.xml for opensource-safety-vulnerability scanner %v", err), constant.ProgressValueTwenty)
				log.Error("Error in parsing java pom.xml", err)
			}

			if analyzedResult != nil {
				results = append(results, analyzedResult...)
			}

		}
		if strings.Contains(filePath, "gradle.lockfile") {
			techStackMap["Java"] = true
			programmingLanguagesMap["Java"] = true
			// Try to get the version for Java
			version, _ := getJavaVersionFromPom(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap["Java"] = version
			}

			analyzedResult, err := callVulnerabiltySacnner(langTypes.Gradle, filePath, log, scanRequest)
			if err != nil {
				utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error in parsing java gradle.lockfile for opensource-safety-vulnerability scanner %v", err))
				utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error in parsing java gradle.lockfile for opensource-safety-vulnerability scanner %v", err), constant.ProgressValueTwentyFive)
				log.Error("Error in parsing gradle.lockfile", err)
			}

			if analyzedResult != nil {
				results = append(results, analyzedResult...)
			}

		}
		if strings.Contains(filePath, "requirements.txt") {
			techStackMap["Python"] = true
			programmingLanguagesMap["Python"] = true
		}
		if strings.Contains(filePath, "Makefile") {
			techStackMap["C"] = true
			techStackMap["C++"] = true
			programmingLanguagesMap["C"] = true
			programmingLanguagesMap["C++"] = true
		}
		// Check for .NET-related files
		if strings.HasSuffix(filePath, ".deps.json") {
			techStackMap[".NET"] = true
			programmingLanguagesMap["C#"] = true

			// Get the .NET version from the .csproj
			version, _ := getDotNetVersionFromCsproj(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap["TypeScript"] = version
			}

			analyzedResult, err := callVulnerabiltySacnner(langTypes.DotNetCore, filePath, log, scanRequest)
			if err != nil {
				utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error in parsing .Net .deps.json for opensource-safety-vulnerability scanner %v", err))
				utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error in parsing .Net .deps.json for opensource-safety-vulnerability scanner %v", err), constant.ProgressValueTwentyFive)
				log.Error("Error in parsing", err)
			}
			if analyzedResult != nil {
				results = append(results, analyzedResult...)
			}
		}

		if strings.HasSuffix(filePath, ".props") {
			techStackMap[".NET"] = true
			programmingLanguagesMap[".NET"] = true

			// Get the .NET version from the .csproj
			version, _ := getDotNetVersionFromCsproj(filePath)
			if err != nil {
				log.Println("Error:", err)
			} else {
				programmingLanguagesVersionMap[".NET"] = version
			}
			analyzedResult, err := callVulnerabiltySacnner(langTypes.PackagesProps, filePath, log, scanRequest)
			if err != nil {
				utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error in parsing .Net .props for opensource-safety-vulnerability scanner %v", err))
				utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error in parsing .Net .props for opensource-safety-vulnerability scanner %v", err), constant.ProgressValueTwentyFive)
				log.Error("Error in parsing", err)
			}
			if analyzedResult != nil {
				results = append(results, analyzedResult...)
			}
		}

		// Check for programming language-specific files (in the absence of dependency files)
		for ext, lang := range extensionLanguageMap {
			if strings.HasSuffix(filePath, ext) {
				programmingLanguagesMap[lang] = true
				totalLines += countLines(filePath)
				break // Stop after first match
			}
		}

		return nil
	})

	// Handle errors from Walk
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error scanning the directory for Techstack identification %v", err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error scanning the directory for Techstack identification %v", err), constant.ProgressValueTwentyFive)
		log.WithFields(logrus.Fields{
			"path":  path,
			"error": err.Error(),
		}).Error("Error scanning the directory")
		return
	}

	// Log total files and file extension counts
	log.Info("Total File Count: ", totalFiles)
	log.Info("Total File By Extension Count:", fileExtensionCount)

	// Create a slice to hold the extension counts
	var extensionArray []models.ExtensionCount

	// Populate the extensionArray with the file extensions and their counts
	for ext, count := range fileExtensionCount {
		extensionArray = append(extensionArray, models.ExtensionCount{
			Extension: ext,
			Count:     count,
		})
	}

	// Combine both tech stack and programming languages into one final result
	finalTechStack := []string{}

	// Add entries from techStackMap to finalTechStack
	for tech := range techStackMap {
		finalTechStack = append(finalTechStack, tech)
	}

	// Add entries from programmingLanguagesMap to finalTechStack
	for language := range programmingLanguagesMap {
		// Ensure no duplicates by adding only if not already present
		if !contains(finalTechStack, language) {
			finalTechStack = append(finalTechStack, language)
		}
	}

	languageVersionStringArray := []string{}
	for lang, version := range programmingLanguagesVersionMap {
		entry := fmt.Sprintf("%s %s", lang, version)
		entry = strings.TrimSpace(entry) // This removes leading/trailing spaces
		languageVersionStringArray = append(languageVersionStringArray, entry)
	}

	if len(languageVersionStringArray) == 0 {
		for _, lang := range finalTechStack {
			languageVersionStringArray = append(languageVersionStringArray, strings.TrimSpace(lang))
		}
	}

	// Log the final result
	if len(finalTechStack) > 0 {
		log.WithFields(logrus.Fields{}).Info("Detected Programming Languages: ", finalTechStack)
		log.WithFields(logrus.Fields{}).Info("Detected Programming Languages Version: ", programmingLanguagesVersionMap)
		log.WithFields(logrus.Fields{"lines": totalLines}).Info("Total lines of code detected")
	} else {
		log.Info("No recognizable tech stack or programming languages found.")
	}

	frameworks, _ := frameworkanalyzer.AnalyzeFrameworks(path, programmingLanguagesMap)
	// Create Result for Vulnerability
	finalResult := makeVulnerabilityResult(finalTechStack, path, scanRequest, results)
	makeVulnerabilityReportJsonFile(finalResult, scanRequest)

	// Create Result for TechStack
	utils.GeneratTechStackResult(languageVersionStringArray, frameworks, totalLines, scanRequest, totalFiles, extensionArray)

	resultFilePath := cloudSuitabilityAnalyzer.RunCloudSuitabilityAnalyzer(scanRequest, path, finalTechStack)

	codeHealthResultFilePath, _ := launcher.StaicCheckProcess(path, scanRequest, finalTechStack)

	// Create Result for RepoTreeStructure
	utils.GenerateRepoTreeStructure(path, scanRequest, resultFilePath, codeHealthResultFilePath, finalTechStack)
	ZipResult(scanRequest, mode)
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.ScanStatusCompleted,
		"progress":    constant.ProgressValueCompleted,
	}).Info("====SendLogMessage ====API: All Scan Completed.==== payload===")
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusCompleted,
	}).Info("====Change Status ==== All Scan request Completed==== API Request Payload == ")
	log.Println("19th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.ScanStatusCompleted, constant.ProgressValueCompleted)
	utils.SendStatus(scanRequest, constant.ScanStatusCompleted)
	log.Println("19th API Request completed====", constant.ScanStatusCompleted)
	if mode.Mode == "offline" {
		// Delete everything except the outer zip
		tempDir, _ := utils.CreateTempDirectory()
		// Outer zip file name and path
		fileName := fmt.Sprintf("%s_%s_%s_%s_result.zip", scanRequest.TenantID, scanRequest.AppID, scanRequest.ComponentID, scanRequest.ScanResultID)
		outerZipFileName := filepath.Join(tempDir, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID, fileName)
		dirPath := filepath.Join(tempDir, scanRequest.TenantID, scanRequest.AppID, "scan_result", scanRequest.ComponentID, scanRequest.ScanResultID)
		outerZipBaseName := filepath.Base(outerZipFileName)

		if err := DeleteExceptFile(dirPath, outerZipBaseName); err != nil {
			log.WithFields(logrus.Fields{
				"directory": dirPath,
				"error":     err.Error(),
			}).Error("Failed to delete files except outer zip")
		}
	}
	log.Info("All Scan Completed Successfully")
}

// Function to scan a Git repository (or a local directory) for tech stack files
func ScanGitRepo(path string, scanRequest models.ScanRequest, mode models.Mode) {
	log := logger.GetLogger()
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.TechStackIdentificationInitiating,
		"progress":    constant.ProgressValueTwelve,
	}).Info("====SendLogMessage ====API: Initiating tech stack identification.==== payload===")
	log.Println("7th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.TechStackIdentificationInitiating, constant.ProgressValueTwelve)
	log.Println("7th API Request completed====", constant.TechStackIdentificationInitiating)

	identifyTechStack(path, scanRequest, mode)
}

func makeVulnerabilityResult(techstacks []string, filePath string, scanRequest models.ScanRequest, results types.Results) VulnResult {

	scanRequest.LaunchedOn = utils.GetCurrentTime()

	var techstack string

	scanPackage := 0
	if len(results) != 0 {
		scanPackage += len(results[0].Packages)
	}

	for _, tech := range techstacks {
		if strings.Contains(string(tech), "Java") {
			techstack = "Java"
		}
		if strings.Contains(string(tech), ".NET") {
			techstack = ".NET"
		}
	}

	// get hostname
	var hostName string
	b, err := os.ReadFile(filepath.Join(filePath, "etc", "hostname"))
	if err == nil && len(b) != 0 {
		hostName = strings.TrimSpace(string(b))
	}

	artifact := artifact.Reference{
		Name: hostName,
	}

	return VulnResult{
		ScanRequest: models.ScanRequest{
			RunID:        scanRequest.RunID,
			ScanResultID: scanRequest.ScanResultID,
			ScanID:       scanRequest.ScanID,
			ComponentID:  scanRequest.ComponentID,
			AppID:        scanRequest.AppID,
			TenantID:     scanRequest.TenantID,
			ScanProfile:  scanRequest.ScanProfile,
			LaunchedOn:   scanRequest.LaunchedOn,
		},
		TechStack: techstack,
		ScanType:  "Vulnerability",
		ScanResults: ScanResults{
			ScanPackage:   scanPackage,
			SchemaVersion: db.SchemaVersion,
			CreatedAt:     time.Now().Format(time.RFC3339),
			ArtifactName:  artifact.Name,
			ArtifactType:  string(types.TypeFilesystem),
			Metadata: Metadata{
				ImageConfig: ImageConfig{
					Architecture: "",
					Created:      time.Now(),
					OS:           "",
					RootFS: RootFS{
						Type:    "",
						DiffIDs: nil,
					},
					Config: nil,
				},
			},
			Results: results,
		},
	}
}

var fileTimeStamp = utils.GetfileNameCurrentTime()

func makeVulnerabilityReportJsonFile(finalResult VulnResult, scanRequest models.ScanRequest) {

	log := logger.GetLogger()

	// Unmarshal JSON back to types.Result
	var unmarshalledResult VulnResult

	// Marshal scanResults to JSON
	jsonOutput, err := json.MarshalIndent(finalResult, "", "  ")
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to marshal scan results to JSON for opensource-safety-vulnerability %v", err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to marshal scan results to JSON for opensource-safety-vulnerability %v", err), constant.ProgressValueFifty)
		log.WithFields(logrus.Fields{"error": err.Error()}).Error("Failed to marshal scan results to JSON")
		return
	}

	exportDir, err := utils.GetCodeAnalyzerScanResultsPath(scanRequest, "opensource-safety-vulnerability")
	if err != nil {
		fmt.Println("Error while creating temp file , err : ", err)
	} else {
		util.ExportDir = exportDir
	}

	// Write JSON output to a file under eport Dir
	err = os.WriteFile(filepath.Join(exportDir, "opensource-safety-vulnerability.json"), jsonOutput, 0777)
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to write scan results to result file for opensource-safety-vulnerability %v", err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to write scan results to result file for opensource-safety-vulnerability %v", err), constant.ProgressValueFifty)
		log.WithFields(logrus.Fields{"error": err.Error()}).Error("Failed to write scan results to file in exportDir")
		return
	}

	err = json.Unmarshal(jsonOutput, &unmarshalledResult)
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to unmarshal scan results to JSON for opensource-safety-vulnerability %v", err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to unmarshal scan results to JSON for opensource-safety-vulnerability %v", err), constant.ProgressValueFifty)
		log.WithFields(logrus.Fields{"error": err.Error()}).Error("Failed to unmarshal scan results from JSON")
		return
	}
	ResultFileName := filepath.Join(exportDir, "opensource-safety-vulnerability.json")
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"fileName":    ResultFileName,
		"scannerType": constant.ScannerTypeOpensourceSafetyVulnerability,
	}).Info("====InsertResultFileToKafka ==== Opensource Safety Vulnerability Result File Genreted successfully. ==== API Request Payload == ")

	utils.SendApiRequest(scanRequest, ResultFileName, constant.ScannerTypeOpensourceSafetyVulnerability)

	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.OSScanCompleted,
		"progress":    constant.ProgressValueFifty,
		"statusMsg":   constant.ScanStatusInProgress,
	}).Info("====SendLogMessage ====API: Opensource-safety-vulnerability Scan Completed.==== payload===")
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusInProgress,
	}).Info("====Change Status ==== Opensource-safety-vulnerability Scan request Completed==== API Request Payload == ")
	log.Println("12th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.OSScanCompleted, constant.ProgressValueFifty)
	utils.SendStatus(scanRequest, constant.ScanStatusInProgress)
	log.Println("12th API Request completed====", constant.OSScanCompleted)

	log.Info(fmt.Sprintf("Scan results successfully written to %s_%s and unmarshalled to types.Result"), scanRequest.RunID, "Vuln_Scan_Results.json")
}

func callVulnerabiltySacnner(langtype langTypes.LangType, filePath string, log *logrus.Logger, scanRequest models.ScanRequest) (types.Results, error) {

	var err error

	results := types.Results{}

	// When the directory is the same as the filePath, a file was given
	// instead of a directory, rewrite the file path and directory in this case.
	if filePath == "." {
		_, filePath = path.Split(filePath)
	}
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.OSScanInitiating,
		"progress":    constant.ProgressValueTwentyFive,
	}).Info("====SendLogMessage ====API:  Intiating Opensource-safety-vulnerability Scan.==== payload===")
	log.Println("10th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.OSScanInitiating, constant.ProgressValueTwentyFive)
	log.Println("10th API Request completed====", constant.OSScanInitiating)

	analyzeResult := va.NewAnalysisResult()

	analyzeResult, err = language.Analyze(langtype, filePath) //Common
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error analyzing the %s file %v", langtype, err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error analyzing the %s file %v", langtype, err), constant.ProgressValueTwentyFive)
		log.WithFields(logrus.Fields{"error": err.Error()}).Error("Error analyzing the %s file", langtype)
		return nil, err
	}

	blobInfo := types.BlobInfo{}

	if analyzeResult != nil {
		analyzeResult.Sort()

		blobInfo = types.BlobInfo{
			SchemaVersion:     types.BlobJSONSchemaVersion,
			OS:                analyzeResult.OS,
			Repository:        analyzeResult.Repository,
			PackageInfos:      analyzeResult.PackageInfos,
			Applications:      analyzeResult.Applications,
			Misconfigurations: analyzeResult.Misconfigurations,
			Secrets:           analyzeResult.Secrets,
			Licenses:          analyzeResult.Licenses,
			CustomResources:   analyzeResult.CustomResources,
		}
	}

	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.OSScanInProgress,
		"progress":    constant.ProgressValueForty,
		"statusMsg":   constant.ScanStatusInProgress,
	}).Info("====SendLogMessage ====API: Opensource-safety-vulnerability Scan InProgress.==== payload===")
	log.WithFields(logrus.Fields{
		"scanRequest":   scanRequest,
		"statusMassage": constant.ScanStatusInProgress,
	}).Info("====Change Status ==== Opensource-safety-vulnerability Scan request InProgress==== API Request Payload == ")
	log.Println("11th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.OSScanInProgress, constant.ProgressValueForty)
	utils.SendStatus(scanRequest, constant.ScanStatusInProgress)
	log.Println("11th API Request completed====", constant.OSScanInProgress)

	// Scan
	results, err = langpkg.Scan(context.Background(), langtype, blobInfo)
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to get scan results for OS safety-vulnerability : %v", err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to get scan results for OS safety-vulnerability : %v", err), constant.ProgressValueForty)
		log.Error("Failed to get scan results : ", err)
		return nil, err
	}

	return results, nil

}

type AnalysisOptions struct {
	Offline      bool
	FileChecksum bool
}

type VulnResult struct {
	ScanRequest models.ScanRequest `json:"scan_request"`
	TechStack   string             `json:"tech_stack"`
	ScanType    string             `json:"scan_type"`
	ScanResults ScanResults        `json:"scan_results"`
}

type ScanResults struct {
	ScanPackage   int           `json:"ScanPackage"`
	SchemaVersion int           `json:"SchemaVersion"`
	CreatedAt     string        `json:"CreatedAt"`
	ArtifactName  string        `json:"ArtifactName"`
	ArtifactType  string        `json:"ArtifactType"`
	Metadata      Metadata      `json:"Metadata"`
	Results       types.Results `json:"Results"` // Assuming Results is another nested object or array
}

type Metadata struct {
	ImageConfig ImageConfig `json:"ImageConfig"`
}

type ImageConfig struct {
	Architecture string      `json:"architecture"`
	Created      time.Time   `json:"created"`
	OS           string      `json:"os"`
	RootFS       RootFS      `json:"rootfs"`
	Config       interface{} `json:"config"` // Config can be any object, so using `interface{}`
}

type RootFS struct {
	Type    string   `json:"type"`
	DiffIDs []string `json:"diff_ids"` // Assuming `null` means a slice of strings or empty
}

type Results struct {
	// Define the structure of Results here.
	// For example, assuming it's an array of scan results, it can be structured as:
	ScanDetails []ScanDetail `json:"scan_details"`
}

type ScanDetail struct {
	// Example fields based on what data the scan result contains.
	ID          int    `json:"id"`
	Description string `json:"description"`
	Status      string `json:"status"`
}
