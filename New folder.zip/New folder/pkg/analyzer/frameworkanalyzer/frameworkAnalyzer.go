package frameworkanalyzer

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/scanner/pkg/logger"
	"github.com/sirupsen/logrus"
)

var knownFrameworks = map[string]bool{
	// JavaScript / TypeScript
	"react": true, "angular": true, "vue": true,
	"nuxt": true, "next": true, "svelte": true,
	"express": true, "nestjs": true,

	// Python
	"django": true, "flask": true, "fastapi": true,

	// Go
	"gin": true, "echo": true,

	// Java
	"spring": true,

	// PHP
	"laravel": true, "symfony": true,

	// .NET
	".net": true, "aspnetcore": true,
}

var frameworkAlias = map[string]string{
	"@angular/core":            "angular",
	"nuxt.js":                  "nuxt",
	"next.js":                  "next",
	"spring-boot":              "spring",
	"microsoft.aspnetcore.app": "aspnetcore",
}

func AnalyzeFrameworks(path string, programmingLanguages map[string]bool) (frameworks []string, err error) {
	log := logger.GetLogger()
	frameworksMap := make(map[string]string)

	err = filepath.Walk(path, func(filePath string, info os.FileInfo, err error) error {
		if err != nil {
			log.WithFields(logrus.Fields{"filePath": filePath, "error": err.Error()}).Error("Error walking through directory")
			return err
		}

		log.WithFields(logrus.Fields{"filePath": filePath}).Debug("Processing file")

		// --- JavaScript / TypeScript ---
		if programmingLanguages["JavaScript"] || programmingLanguages["TypeScript"] {
			if strings.HasSuffix(filePath, "package.json") {
				content, err := os.ReadFile(filePath)
				if err != nil {
					log.WithField("file", filePath).Error("Failed to read package.json")
					return nil
				}

				var data map[string]interface{}
				if json.Unmarshal(content, &data) == nil {
					deps := []string{"dependencies", "devDependencies"}
					for _, depType := range deps {
						if depMap, ok := data[depType].(map[string]interface{}); ok {
							for k, v := range depMap {
								normalized := normalizeFrameworkName(k)
								if knownFrameworks[normalized] {
									version := strings.TrimSpace(v.(string))
									addFramework(frameworksMap, strings.Title(normalized), version)
								}
							}
						}
					}
				}
			}
			if strings.Contains(filePath, "angular.json") {
				addFramework(frameworksMap, "Angular", "")
			}
			if strings.Contains(filePath, "nuxt.config.js") {
				addFramework(frameworksMap, "Nuxt", "")
			}
		}

		// --- Python ---
		if programmingLanguages["Python"] && strings.HasSuffix(filePath, "requirements.txt") {
			file, err := os.Open(filePath)
			if err != nil {
				log.WithField("file", filePath).Error("Failed to open requirements.txt")
				return nil
			}
			defer file.Close()

			scanner := bufio.NewScanner(file)
			for scanner.Scan() {
				line := strings.TrimSpace(scanner.Text())
				if strings.HasPrefix(line, "#") || line == "" {
					continue
				}
				lower := strings.ToLower(line)
				for name := range knownFrameworks {
					if strings.Contains(lower, name) {
						addFramework(frameworksMap, strings.Title(name), extractPythonVersion(line))
					}
				}
			}
		}

		// --- Go ---
		if programmingLanguages["Go"] && strings.HasSuffix(filePath, "go.mod") {
			file, err := os.Open(filePath)
			if err != nil {
				log.WithField("file", filePath).Error("Failed to open go.mod")
				return nil
			}
			defer file.Close()

			scanner := bufio.NewScanner(file)
			for scanner.Scan() {
				line := scanner.Text()
				if strings.Contains(line, "github.com/gin-gonic/gin") {
					addFramework(frameworksMap, "Gin", extractVersion(line))
				} else if strings.Contains(line, "github.com/labstack/echo") {
					addFramework(frameworksMap, "Echo", extractVersion(line))
				}
			}
		}

		// --- Java ---
		if programmingLanguages["Java"] && (strings.HasSuffix(filePath, "pom.xml") || strings.HasSuffix(filePath, "build.gradle")) {
			file, err := os.ReadFile(filePath)
			if err != nil {
				log.WithField("file", filePath).Error("Failed to read Java dependency file")
				return nil
			}
			content := string(file)
			if strings.Contains(content, "spring-boot") || strings.Contains(content, "springframework") {
				version := extractSpringVersion(content)
				addFramework(frameworksMap, "Spring", version)
			}
		}

		// --- PHP ---
		if programmingLanguages["PHP"] && strings.HasSuffix(filePath, "composer.json") {
			content, err := os.ReadFile(filePath)
			if err != nil {
				log.WithField("file", filePath).Error("Failed to read composer.json")
				return nil
			}

			var data map[string]interface{}
			if json.Unmarshal(content, &data) == nil {
				if requireMap, ok := data["require"].(map[string]interface{}); ok {
					for k, v := range requireMap {
						normalized := normalizeFrameworkName(k)
						if knownFrameworks[normalized] {
							version := strings.TrimSpace(v.(string))
							addFramework(frameworksMap, strings.Title(normalized), version)
						}
					}
				}
			}
		}

		// --- .NET ---
		if (programmingLanguages["C#"] || programmingLanguages[".NET"] || programmingLanguages["DotNet"]) && strings.HasSuffix(filePath, ".csproj") {
			content, err := os.ReadFile(filePath)
			if err != nil {
				log.WithField("file", filePath).Error("Failed to read .csproj")
				return nil
			}
			text := string(content)
			if strings.Contains(text, "Microsoft.AspNetCore") || strings.Contains(text, "<FrameworkReference Include=\"Microsoft.AspNetCore.App\"") {
				version := extractDotNetVersion(text)
				addFramework(frameworksMap, ".NET", version)
			}
		}

		return nil
	})

	if err != nil {
		log.WithFields(logrus.Fields{"path": path, "error": err.Error()}).Error("Error scanning the directory for frameworks")
		return
	}

	seen := map[string]bool{}
	for name, version := range frameworksMap {
		key := name + version
		if !seen[key] {
			if version != "" {
				frameworks = append(frameworks, name+" "+version)
			} else {
				frameworks = append(frameworks, name)
			}
			seen[key] = true
		}
	}

	if len(frameworks) > 0 {
		log.WithFields(logrus.Fields{}).Info("Detected Frameworks:", frameworks)
	} else {
		log.Info("No recognizable frameworks found.")
	}

	return frameworks, err
}

// Normalize package name and alias
func normalizeFrameworkName(name string) string {
	name = strings.ToLower(name)
	if strings.HasPrefix(name, "@") && strings.Contains(name, "/") {
		parts := strings.Split(name, "/")
		name = parts[1]
	} else if strings.Contains(name, "/") {
		parts := strings.Split(name, "/")
		name = parts[len(parts)-1]
	}
	if alias, ok := frameworkAlias[name]; ok {
		return alias
	}
	return name
}

func extractVersion(line string) string {
	parts := strings.Fields(line)
	if len(parts) >= 2 {
		return parts[1]
	}
	return ""
}

func extractSpringVersion(content string) string {
	re := regexp.MustCompile(`(?i)<version>([\d.]+)</version>`)
	match := re.FindStringSubmatch(content)
	if len(match) > 1 {
		return match[1]
	}
	return ""
}

func extractPythonVersion(line string) string {
	parts := strings.Split(line, "==")
	if len(parts) == 2 {
		return parts[1]
	}
	return ""
}

func extractDotNetVersion(content string) string {
	re := regexp.MustCompile(`(?i)<TargetFramework>(net[\w\d.]+)</TargetFramework>`)
	match := re.FindStringSubmatch(content)
	if len(match) > 1 {
		return match[1]
	}
	return ""
}

func addFramework(m map[string]string, name string, version string) {
	current, exists := m[name]
	if !exists || (current == "" && version != "") {
		m[name] = version
	}
}
