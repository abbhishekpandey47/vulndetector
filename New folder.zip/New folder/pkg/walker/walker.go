package walker

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/scanner/pkg/collector"
)

type RepoWalker struct {
	collector collector.FileInfoCollector
}

func NewWalker(c collector.FileInfoCollector) *RepoWalker {
	return &RepoWalker{collector: c}
}

func (w *RepoWalker) BuildStructure(root string) (map[string]interface{}, error) {
	result := make(map[string]interface{})

	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if path == root {
			return nil
		}

		relPath, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}

		parts := strings.Split(relPath, string(filepath.Separator))
		current := result

		for i, part := range parts {
			if i == len(parts)-1 {
				if !info.IsDir() {
					current[part] = w.collector.Collect(info, path)
				}
				break
			}

			if _, ok := current[part]; !ok {
				current[part] = make(map[string]interface{})
			}

			var valid bool
			current, valid = current[part].(map[string]interface{})
			if !valid {
				return fmt.Errorf("invalid structure at %s", part)
			}
		}

		return nil
	})

	return result, err
}
