package collector

import (
	"os"

	"github.com/scanner/models"
)

// DefaultCollector implements basic file information collection
type DefaultCollector struct{}

func NewDefaultCollector() *DefaultCollector {
	return &DefaultCollector{}
}

func (c *DefaultCollector) Collect(info os.FileInfo, path string) models.FileData {
	return models.FileData{
		Size:         getSize(info),
		Extension:    getExtension(info),
		LastModified: getLastModified(info),
	}
}
