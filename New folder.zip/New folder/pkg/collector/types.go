package collector

import (
	"os"

	"github.com/scanner/models"
)

// FileInfoCollector defines the interface for collecting file information
type FileInfoCollector interface {
	Collect(info os.FileInfo, path string) models.FileData
}
