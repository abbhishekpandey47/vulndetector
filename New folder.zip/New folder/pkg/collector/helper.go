package collector

import (
	"os"
	"path/filepath"
	"strings"
	"time"
)

func getSize(info os.FileInfo) int64 {
	return info.Size()
}

func getExtension(info os.FileInfo) string {
	name := info.Name()
	ext := filepath.Ext(name)

	if strings.HasPrefix(name, ".") && !strings.Contains(name[1:], ".") {
		return ""
	}
	return ext
}

func getLastModified(info os.FileInfo) string {
	return info.ModTime().UTC().Format(time.RFC3339)
}
