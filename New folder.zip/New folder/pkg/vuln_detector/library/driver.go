package library

import (
	"fmt"
	"strings"

	"github.com/samber/lo"
	"github.com/scanner/internals/db"
	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/vuln_detector/compare"
	"github.com/scanner/pkg/vuln_detector/compare/maven"
	"github.com/scanner/pkg/vuln_detector/vulnerability"
)

// NewDriver returns a driver according to the library type
func NewDriver(libType langTypes.LangType) (Driver, bool) {

	log := logger.GetLogger()

	var ecosystem types.Ecosystem
	var comparer compare.Comparer

	switch libType {
	// case langTypes.Bundler, langTypes.GemSpec:
	// 	ecosystem = types.RubyGems
	// 	// comparer = rubygems.Comparer{}
	// case langTypes.RustBinary, langTypes.Cargo:
	// 	ecosystem = types.Cargo
	// 	comparer = compare.GenericComparer{}
	// case langTypes.Composer, langTypes.ComposerVendor:
	// 	ecosystem = types.Composer
	// 	comparer = compare.GenericComparer{}
	// case langTypes.GoBinary, langTypes.GoModule:
	// 	ecosystem = types.Go
	// 	comparer = compare.GenericComparer{}
	case langTypes.Jar, langTypes.Pom, langTypes.Gradle, langTypes.Sbt:
		ecosystem = types.Maven
		comparer = maven.Comparer{}
		// log.Infof("driver.go - NewDriver %v, %v", ecosystem, comparer)
	// case langTypes.Npm, langTypes.Yarn, langTypes.Pnpm, langTypes.NodePkg, langTypes.JavaScript:
	// 	ecosystem = types.Npm
	// 	// comparer = npm.Comparer{}
	case langTypes.NuGet, langTypes.DotNetCore, langTypes.PackagesProps:
		ecosystem = types.NuGet
		comparer = compare.GenericComparer{}
	// case langTypes.Pipenv, langTypes.Poetry, langTypes.Pip, langTypes.PythonPkg, langTypes.Uv:
	// 	ecosystem = types.Pip
	// 	// comparer = pep440.Comparer{}
	// case langTypes.Pub:
	// 	ecosystem = types.Pub
	// 	comparer = compare.GenericComparer{}
	// case langTypes.Hex:
	// 	ecosystem = types.Erlang
	// 	comparer = compare.GenericComparer{}
	// case langTypes.Conan:
	// 	ecosystem = types.Conan
	// 	// Only semver can be used for version ranges
	// 	// https://docs.conan.io/en/latest/versioning/version_ranges.html
	// 	comparer = compare.GenericComparer{}
	// case langTypes.Swift:
	// 	// Swift uses semver
	// 	// https://www.swift.org/package-manager/#importing-dependencies
	// 	ecosystem = types.Swift
	// 	comparer = compare.GenericComparer{}
	// case langTypes.Cocoapods:
	// 	// CocoaPods uses RubyGems version specifiers
	// 	// https://guides.cocoapods.org/making/making-a-cocoapod.html#cocoapods-versioning-specifics
	// 	ecosystem = types.Cocoapods
	// 	// comparer = rubygems.Comparer{}
	// case langTypes.CondaPkg, langTypes.CondaEnv:
	// 	log.Warn("Conda package is supported for SBOM, not for vulnerability scanning")
	// 	return Driver{}, false
	// case langTypes.Bitnami:
	// 	ecosystem = types.Bitnami
	// 	// comparer = bitnami.Comparer{}
	// case langTypes.K8sUpstream:
	// 	ecosystem = types.Kubernetes
	// 	comparer = compare.GenericComparer{}
	// case langTypes.Julia:
	// 	log.Warn("Julia is supported for SBOM, not for vulnerability scanning")
	// 	return Driver{}, false
	default:
		log.Warn("The library type is not supported for vulnerability scanning", "type", libType)
		return Driver{}, false
	}
	return Driver{
		ecosystem: ecosystem,
		comparer:  comparer,
		dbc:       db.Config{},
	}, true
}

// Driver represents security advisories for each programming language
type Driver struct {
	ecosystem types.Ecosystem
	comparer  compare.Comparer
	dbc       db.Config
	// DB        *bbolt.DB
}

// Type returns the driver ecosystem
func (d *Driver) Type() string {
	return string(d.ecosystem)
}

// DetectVulnerabilities scans buckets with the prefix according to the ecosystem.
// If "ecosystem" is pip, it looks for buckets with "pip::" and gets security advisories from those buckets.
// It allows us to add a new data source with the ecosystem prefix (e.g. pip::new-data-source)
// and detect vulnerabilities without specifying a specific bucket name.
func (d *Driver) DetectVulnerabilities(pkgID, pkgName, pkgVer string) ([]types.DetectedVulnerability, error) {

	log := logger.GetLogger()

	// e.g. "pip::", "npm::"
	prefix := fmt.Sprintf("%s::", d.ecosystem)
	// log.Infof("driver.go - DetectVulnerabilities, prefix - %v, %s, %s ", d, prefix, pkgName)
	advisories, err := d.dbc.GetAdvisories(prefix, vulnerability.NormalizePkgName(d.ecosystem, pkgName))
	// TODO : Pass ecosystem
	// advisories, err := d.dbc.Operation.GetAdvisories(prefix, vulnerability.NormalizePkgName(d.ecosystem, pkgName))
	if err != nil {
		log.Errorf("failed to get %s advisories: %w", d.ecosystem, err)
		return nil, err
	}

	var vulns []types.DetectedVulnerability
	for _, adv := range advisories {

		if !d.comparer.IsVulnerable(pkgVer, adv) {
			continue
		}

		vuln := types.DetectedVulnerability{
			VulnerabilityID:  adv.VulnerabilityID,
			PkgID:            pkgID,
			PkgName:          pkgName,
			InstalledVersion: pkgVer,
			FixedVersion:     createFixedVersions(adv),
			DataSource:       adv.DataSource,
			Custom:           adv.Custom,
		}
		vulns = append(vulns, vuln)
	}

	return vulns, nil
}

func createFixedVersions(advisory types.Advisory) string {

	if len(advisory.PatchedVersions) != 0 {
		return joinFixedVersions(advisory.PatchedVersions)
	}

	var fixedVersions []string
	for _, version := range advisory.VulnerableVersions {
		for _, s := range strings.Split(version, ",") {
			s = strings.TrimSpace(s)
			if !strings.HasPrefix(s, "<=") && strings.HasPrefix(s, "<") {
				s = strings.TrimPrefix(s, "<")
				fixedVersions = append(fixedVersions, strings.TrimSpace(s))
			}
		}
	}
	return joinFixedVersions(fixedVersions)
}

func joinFixedVersions(fixedVersions []string) string {
	return strings.Join(lo.Uniq(fixedVersions), ", ")
}
