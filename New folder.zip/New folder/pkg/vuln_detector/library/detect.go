package library

import (
	"context"

	"golang.org/x/xerrors"

	"github.com/scanner/pkg/logger"

	"github.com/scanner/internals/db"
	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
)

var database db.DB

// Detect scans language-specific packages and returns vulnerabilities.
func Detect(ctx context.Context, libType langTypes.LangType, pkgs []types.Package) ([]types.DetectedVulnerability, error) {
	log := logger.GetLogger()

	driver, ok := NewDriver(libType)
	if !ok {
		return nil, nil
	}

	vulns, err := detect(ctx, driver, pkgs)
	if err != nil {
		log.Errorf("failed to scan %s vulnerabilities: %w", driver.Type(), err)
		return nil, err
	}

	return vulns, nil
}

func detect(ctx context.Context, driver Driver, pkgs []types.Package) ([]types.DetectedVulnerability, error) {
	log := logger.GetLogger()

	if !database.IsInitialized() {
		database = db.NewDB()
		log.Info("New Db : ", database)
	}

	var vulnerabilities []types.DetectedVulnerability
	for _, pkg := range pkgs {

		if pkg.Version == "" {
			log.Info("Skipping vulnerability scan as no version is detected for the package : name", pkg.Name)
			continue
		}
		vulns, err := driver.DetectVulnerabilities(pkg.ID, pkg.Name, pkg.Version)
		if err != nil {
			return nil, xerrors.Errorf("failed to detect %s vulnerabilities: %w", driver.Type(), err)
		}

		for i := range vulns {
			vulns[i].Layer = pkg.Layer
			vulns[i].PkgPath = pkg.FilePath
			vulns[i].PkgIdentifier = pkg.Identifier
		}
		vulnerabilities = append(vulnerabilities, vulns...)
	}

	return vulnerabilities, nil
}
