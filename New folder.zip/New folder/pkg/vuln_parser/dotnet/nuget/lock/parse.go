package lock

import (
	"github.com/samber/lo"
	"golang.org/x/xerrors"

	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/vuln_detector/dependency"

	"github.com/aquasecurity/trivy/pkg/log"
	parser_utils "github.com/scanner/pkg/vuln_parser/parser_utils"
	xio "github.com/scanner/pkg/vuln_x_utils/io"
	xjson "github.com/scanner/pkg/vuln_x_utils/json"
)

type LockFile struct {
	Version int                     `json:"version"`
	Targets map[string]Dependencies `json:"dependencies"`
}

type Dependencies map[string]Dependency

type Dependency struct {
	Type         string            `json:"type"`
	Resolved     string            `json:"resolved"`
	Dependencies map[string]string `json:"dependencies,omitempty"`
	xjson.Location
}

type Parser struct{}

func NewParser() *Parser {
	return &Parser{}
}

func (p *Parser) Parse(r xio.ReadSeekerAt) ([]types.Package, []types.Dependency, error) {

	log.Info("------- pkg/dependency/parser/nuget/lock/parse.go Parse -------")

	var lockFile LockFile
	if err := xjson.UnmarshalRead(r, &lockFile); err != nil {
		return nil, nil, xerrors.Errorf("failed to decode packages.lock.json: %w", err)
	}

	var pkgs []types.Package
	depsMap := make(map[string][]string)
	for _, targetContent := range lockFile.Targets {
		for packageName, packageContent := range targetContent {
			// If package type is "project", it is the actual project, and we skip it.
			if packageContent.Type == "Project" {
				continue
			}

			depId := packageID(packageName, packageContent.Resolved)

			pkg := types.Package{
				ID:           depId,
				Name:         packageName,
				Version:      packageContent.Resolved,
				Relationship: lo.Ternary(packageContent.Type == "Direct", types.RelationshipDirect, types.RelationshipIndirect),
				Locations:    []types.Location{types.Location(packageContent.Location)},
			}
			pkgs = append(pkgs, pkg)

			var dependsOn []string

			for depName := range packageContent.Dependencies {
				dependsOn = append(dependsOn, packageID(depName, targetContent[depName].Resolved))
			}

			if savedDependsOn, ok := depsMap[depId]; ok {
				dependsOn = lo.Uniq(append(dependsOn, savedDependsOn...))
			}

			if len(dependsOn) > 0 {
				depsMap[depId] = dependsOn
			}
		}
	}

	var deps []types.Dependency
	for depId, dependsOn := range depsMap {
		dep := types.Dependency{
			ID:        depId,
			DependsOn: dependsOn,
		}
		deps = append(deps, dep)
	}

	return parser_utils.UniquePackages(pkgs), deps, nil
}

func packageID(name, version string) string {
	return dependency.ID(langTypes.NuGet, name, version)
}
