package language

import (
	"io"
	"os"
	"path/filepath"

	"golang.org/x/xerrors"

	"github.com/aquasecurity/trivy/pkg/log"
	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/logger"
	analyzer "github.com/scanner/pkg/vuln_analyzer"
	"github.com/scanner/pkg/vuln_detector/digest"
	dndeps "github.com/scanner/pkg/vuln_parser/dotnet/core_deps"
	packagesprops "github.com/scanner/pkg/vuln_parser/dotnet/nuget/packagesprops"
	jp "github.com/scanner/pkg/vuln_parser/java"
	jgp "github.com/scanner/pkg/vuln_parser/java/gradle"
	"github.com/scanner/pkg/vuln_parser/language/licensing"
	xio "github.com/scanner/pkg/vuln_x_utils/io"
)

// Analyze returns an analysis result of the lock file
func Analyze(fileType langTypes.LangType, filePath string) (*analyzer.AnalysisResult, error) {

	log := logger.GetLogger()

	log.Infof("Analyzing the file of type %s and filepath is %s", fileType, filePath)

	r, err := os.Open(filePath)
	if err != nil {
		log.Errorf("failed to open file %s: %w", filePath, err)
		return nil, err
	}
	defer r.Close()

	app, err := ThisFileParser(fileType, filePath, r)
	if err != nil {
		log.Errorf("failed to parse %s: %w", filePath, err)
		return nil, err
	}

	if app == nil {
		return nil, nil
	}

	return &analyzer.AnalysisResult{Applications: []types.Application{*app}}, nil
}

// Parse returns a parsed result of the lock file
func ThisFileParser(fileType langTypes.LangType, filePath string, r io.Reader) (*types.Application, error) {
	log := logger.GetLogger()

	log.Info("thisFileParser")

	var err error

	rr, err := xio.NewReadSeekerAt(r)
	if err != nil {
		return nil, xerrors.Errorf("reader error: %w", err)
	}

	var parsedPkgs []types.Package
	var parsedDependencies []types.Dependency

	switch fileType {
	case "pom":
		log.Info("Parsing pom.xml")
		parsedPkgs, parsedDependencies, err = jp.Parse(rr, filepath.Clean(filePath))
	case "gradle":
		log.Info("Parsing gradle.lockfile")
		parsedPkgs, parsedDependencies, err = jgp.Parse(rr, filepath.Clean(filePath))
	case "dotnet-core": // *.deps.json
		log.Info("Parsing deps.json")
		parsedPkgs, parsedDependencies, err = dndeps.Parse(rr, filepath.Clean(filePath))
	case "packages-props":
		log.Info("Parsing nuget packages.props")
		parsedPkgs, parsedDependencies, err = packagesprops.Parse(rr, filepath.Clean(filePath))
	case "nuget":
		log.Info("Parsing nuget")
		parsedPkgs, parsedDependencies, err = dndeps.Parse(rr, filepath.Clean(filePath))
	default:
		return nil, xerrors.Errorf("unsupported file type: %s", fileType)
	}

	if err != nil {
		return nil, xerrors.Errorf("failed to parse %s: %w", filePath, err)
	}

	// The file path of each library should be empty in case of dependency list such as lock file
	// since they all will be the same path.
	return toApplication(fileType, filePath, "", nil, parsedPkgs, parsedDependencies), nil
}

func toApplication(fileType langTypes.LangType, filePath, libFilePath string, r xio.ReadSeekerAt, pkgs []types.Package, depGraph []types.Dependency) *types.Application {
	if len(pkgs) == 0 {
		return nil
	}

	// Calculate the file digest when one of `spdx` formats is selected
	d, err := calculateDigest(r)
	if err != nil {
		log.Warn("Unable to get checksum", log.FilePath(filePath), log.Err(err))
	}

	deps := make(map[string][]string)
	for _, dep := range depGraph {
		deps[dep.ID] = dep.DependsOn
	}

	for i, pkg := range pkgs {
		// This file path is populated for virtual file paths within archives, such as nested JAR files.
		if pkg.FilePath == "" {
			pkgs[i].FilePath = libFilePath
		}
		pkgs[i].DependsOn = deps[pkg.ID]
		pkgs[i].Digest = d
		pkgs[i].Indirect = isIndirect(pkg.Relationship) // For backward compatibility

		for j, license := range pkg.Licenses {
			pkgs[i].Licenses[j] = licensing.Normalize(license)
		}
	}

	return &types.Application{
		Type:     fileType,
		FilePath: filePath,
		Packages: pkgs,
	}
}

func calculateDigest(r xio.ReadSeekerAt) (digest.Digest, error) {
	if r == nil {
		return "", nil
	}
	// return reader to start after it has been read in analyzer
	if _, err := r.Seek(0, io.SeekStart); err != nil {
		return "", xerrors.Errorf("unable to seek: %w", err)
	}

	return digest.CalcSHA1(r)
}

func isIndirect(rel types.Relationship) bool {
	switch rel {
	case types.RelationshipIndirect:
		return true
	default:
		return false
	}
}
