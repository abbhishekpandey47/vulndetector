package java

import (
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"slices"
	"sort"
	"strings"

	"github.com/hashicorp/go-multierror"
	"github.com/samber/lo"
	"golang.org/x/net/html/charset"
	"golang.org/x/xerrors"

	"github.com/aquasecurity/trivy/pkg/dependency/parser/utils"
	"github.com/scanner/pkg/vuln_detector/dependency"

	"github.com/aquasecurity/trivy/pkg/set"
	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
	xio "github.com/scanner/pkg/vuln_x_utils/io"

	"github.com/scanner/pkg/logger"
)

const (
	centralURL = "https://repo.maven.apache.org/maven2/"
)

type options struct {
	offline             bool
	releaseRemoteRepos  []string
	snapshotRemoteRepos []string
}

type option func(*options)

func WithOffline(offline bool) option {
	return func(opts *options) {
		opts.offline = offline
	}
}

func WithReleaseRemoteRepos(repos []string) option {
	return func(opts *options) {
		opts.releaseRemoteRepos = repos
	}
}

func WithSnapshotRemoteRepos(repos []string) option {
	return func(opts *options) {
		opts.snapshotRemoteRepos = repos
	}
}

type Parser struct {
	rootPath            string
	cache               pomCache
	localRepository     string
	releaseRemoteRepos  []string
	snapshotRemoteRepos []string
	offline             bool
	servers             []Server
}

var parserStruct *Parser

func NewParser(filePath string, opts ...option) *Parser {
	o := &options{
		offline:            false,
		releaseRemoteRepos: []string{centralURL}, // Maven doesn't use central repository for snapshot dependencies
	}

	for _, opt := range opts {
		opt(o)
	}

	s := readSettings()
	localRepository := s.LocalRepository
	if localRepository == "" {
		homeDir, _ := os.UserHomeDir()
		localRepository = filepath.Join(homeDir, ".m2", "repository")
	}

	return &Parser{
		rootPath:            filepath.Clean(filePath),
		cache:               newPOMCache(),
		localRepository:     localRepository,
		releaseRemoteRepos:  o.releaseRemoteRepos,
		snapshotRemoteRepos: o.snapshotRemoteRepos,
		offline:             o.offline,
		servers:             s.Servers,
	}
}

func Parse(r xio.ReadSeekerAt, rootPath string) ([]types.Package, []types.Dependency, error) {

	log := logger.GetLogger()

	//	log.Info("parse.go - Parse")
	parserStruct = NewParser(rootPath, WithOffline(false), WithReleaseRemoteRepos([]string{centralURL}), WithSnapshotRemoteRepos([]string{}))

	content, err := parsePom(r, true)
	if err != nil {
		log.Errorf("failed to parse POM: %w", err)
		return nil, nil, err
	}

	// log.Info("Parsed POM")

	root := &pom{
		filePath: rootPath,
		content:  content,
	}

	// log.Infof("parse.go - Parse - root : %v", root)

	// Analyze root POM
	result, err := analyze(root, analysisOptions{})
	if err != nil {
		log.Errorf("analyze error (%s): %w", rootPath, err)
		return nil, nil, err
	}

	// Cache root POM
	parserStruct.cache.put(result.artifact, result)

	// log.Info("Result : %v", result)
	rootArt := root.artifact()
	rootArt.Relationship = types.RelationshipRoot

	return parseRoot(rootArt, set.New[string]())
}

// nolint: gocyclo
func parseRoot(root artifact, uniqModules set.Set[string]) ([]types.Package, []types.Dependency, error) {
	log := logger.GetLogger()

	// Prepare a queue for dependencies
	queue := newArtifactQueue()

	// Enqueue root POM
	root.Module = false
	queue.enqueue(root)

	var (
		pkgs              types.Packages
		deps              types.Dependencies
		rootDepManagement []pomDependency
		uniqArtifacts     = make(map[string]artifact)
		uniqDeps          = make(map[string][]string)
	)

	// Iterate direct and transitive dependencies
	for !queue.IsEmpty() {
		art := queue.dequeue()

		// Modules should be handled separately so that they can have independent dependencies.
		// It means multi-module allows for duplicate dependencies.
		if art.Module {
			if uniqModules.Contains(art.String()) {
				continue
			}
			uniqModules.Append(art.String())

			modulePkgs, moduleDeps, err := parseRoot(art, uniqModules)
			if err != nil {
				return nil, nil, err
			}

			pkgs = append(pkgs, modulePkgs...)
			if moduleDeps != nil {
				deps = append(deps, moduleDeps...)
			}
			continue
		}

		// For soft requirements, skip dependency resolution that has already been resolved.
		if uniqueArt, ok := uniqArtifacts[art.Name()]; ok {
			if !uniqueArt.Version.shouldOverride(art.Version) {
				continue
			}
			// mark artifact as Direct, if saved artifact is Direct
			// take a look `hard requirement for the specified version` test
			if uniqueArt.Relationship == types.RelationshipRoot ||
				uniqueArt.Relationship == types.RelationshipWorkspace ||
				uniqueArt.Relationship == types.RelationshipDirect {
				art.Relationship = uniqueArt.Relationship
			}
			// We don't need to overwrite dependency location for hard links
			if uniqueArt.Locations != nil {
				art.Locations = uniqueArt.Locations
			}
		}

		result, err := resolve(art, rootDepManagement)
		if err != nil {
			log.Errorf("resolve error (%s): %w", art, err)
			return nil, nil, err
		}

		if art.Relationship == types.RelationshipRoot || art.Relationship == types.RelationshipWorkspace {
			// Managed dependencies in the root POM affect transitive dependencies
			rootDepManagement = resolveDepManagement(result.properties, result.dependencyManagement)

			// mark its dependencies as "direct"
			result.dependencies = lo.Map(result.dependencies, func(dep artifact, _ int) artifact {
				dep.Relationship = types.RelationshipDirect
				return dep
			})
		}

		// Parse, cache, and enqueue modules.
		for _, relativePath := range result.modules {
			moduleArtifact, err := parseModule(result.filePath, relativePath)
			if err != nil {
				log.Error("Unable to parse the module", result.filePath, err)
				continue
			}

			queue.enqueue(moduleArtifact)
		}

		// Resolve transitive dependencies later
		queue.enqueue(result.dependencies...)

		// Offline mode may be missing some fields.
		if !art.IsEmpty() {
			// Override the version
			uniqArtifacts[art.Name()] = artifact{
				Version:      art.Version,
				Licenses:     result.artifact.Licenses,
				Relationship: art.Relationship,
				Locations:    art.Locations,
			}

			// save only dependency names
			// version will be determined later
			dependsOn := lo.Map(result.dependencies, func(a artifact, _ int) string {
				return a.Name()
			})
			uniqDeps[thisPackageID(art.Name(), art.Version.String())] = dependsOn
		}
	}

	// Convert to []types.Package and []types.Dependency
	for name, art := range uniqArtifacts {
		pkg := types.Package{
			ID:           thisPackageID(name, art.Version.String()),
			Name:         name,
			Version:      art.Version.String(),
			Licenses:     art.Licenses,
			Relationship: art.Relationship,
			Locations:    art.Locations,
		}
		pkgs = append(pkgs, pkg)

		// Convert dependency names into dependency IDs
		dependsOn := lo.FilterMap(uniqDeps[pkg.ID], func(dependOnName string, _ int) (string, bool) {
			ver := depVersion(dependOnName, uniqArtifacts)
			return thisPackageID(dependOnName, ver), ver != ""
		})

		// `mvn` shows modules separately from the root package and does not show module nesting.
		// So we can add all modules as dependencies of root package.
		if art.Relationship == types.RelationshipRoot {
			dependsOn = append(dependsOn, uniqModules.Items()...)
		}

		sort.Strings(dependsOn)
		if len(dependsOn) > 0 {
			deps = append(deps, types.Dependency{
				ID:        pkg.ID,
				DependsOn: dependsOn,
			})
		}
	}

	sort.Sort(pkgs)
	sort.Sort(deps)

	return pkgs, deps, nil
}

// depVersion finds dependency in uniqArtifacts and return its version
func depVersion(depName string, uniqArtifacts map[string]artifact) string {
	if art, ok := uniqArtifacts[depName]; ok {
		return art.Version.String()
	}
	return ""
}

func parseModule(currentPath, relativePath string) (artifact, error) {
	log := logger.GetLogger()

	// modulePath: "root/" + "module/" => "root/module"
	module, err := openRelativePom(currentPath, relativePath)
	if err != nil {
		log.Errorf("unable to open the relative path: %w", err)
		return artifact{}, err
	}

	result, err := analyze(module, analysisOptions{})
	if err != nil {
		log.Errorf("analyze error: %w", err)
		return artifact{}, err
	}

	moduleArtifact := module.artifact()
	moduleArtifact.Module = true
	moduleArtifact.Relationship = types.RelationshipWorkspace

	parserStruct.cache.put(moduleArtifact, result)

	return moduleArtifact, nil
}

func resolve(art artifact, rootDepManagement []pomDependency) (analysisResult, error) {
	log := logger.GetLogger()

	// If the artifact is found in cache, it is returned.
	if result := parserStruct.cache.get(art); result != nil {
		return *result, nil
	}

	// We can't resolve a dependency without a version.
	// So let's just keep this dependency.
	if art.Version.String() == "" {
		return analysisResult{
			artifact: art,
		}, nil
	}

	//log.Debug("Resolving...", "group_id", art.GroupID),"artifact_id", art.ArtifactID), "version", art.Version.String()))
	pomContent, err := tryRepository(art.GroupID, art.ArtifactID, art.Version.String())
	if err != nil {
		log.Error("Repository error", err)
	}
	result, err := analyze(pomContent, analysisOptions{
		exclusions:    art.Exclusions,
		depManagement: rootDepManagement,
	})
	if err != nil {
		log.Error("Analyze error", err)
		return analysisResult{}, err
	}

	parserStruct.cache.put(art, result)
	return result, nil
}

type analysisResult struct {
	filePath             string
	artifact             artifact
	dependencies         []artifact
	dependencyManagement []pomDependency // Keep the order of dependencies in 'dependencyManagement'
	properties           map[string]string
	modules              []string
}

type analysisOptions struct {
	exclusions    set.Set[string]
	depManagement []pomDependency // from the root POM
}

func analyze(pom *pom, opts analysisOptions) (analysisResult, error) {
	log := logger.GetLogger()
	// log.Info("parse.go - analyze")

	if pom.nil() {
		return analysisResult{}, nil
	}
	if opts.exclusions == nil {
		opts.exclusions = set.New[string]()
	}
	// Update remoteRepositories
	// pomReleaseRemoteRepos, pomSnapshotRemoteRepos := pom.repositories(parserStruct.servers)
	// parserStruct.releaseRemoteRepos = lo.Uniq(append(pomReleaseRemoteRepos, parserStruct.releaseRemoteRepos...))
	// parserStruct.snapshotRemoteRepos = lo.Uniq(append(pomSnapshotRemoteRepos, parserStruct.snapshotRemoteRepos...))

	// Resolve parent POM
	if err := resolveParent(pom); err != nil {
		log.Error("parent pom resolve error: ", err)
		return analysisResult{}, err
	}

	// Resolve dependencies
	props := pom.properties()
	depManagement := pom.content.DependencyManagement.Dependencies.Dependency
	deps := parseDependencies(pom.content.Dependencies.Dependency, props, depManagement, opts)
	deps = filterDependencies(deps, opts.exclusions)

	return analysisResult{
		filePath:             pom.filePath,
		artifact:             pom.artifact(),
		dependencies:         deps,
		dependencyManagement: depManagement,
		properties:           props,
		modules:              pom.content.Modules.Module,
	}, nil
}

// resolveParent resolves its parent POMs and inherits properties, dependencies, and dependencyManagement.
func resolveParent(pom *pom) error {
	log := logger.GetLogger()

	// log.Info("Parse.go - resolveParent")
	if pom.nil() {
		return nil
	}

	// Parse parent POM
	parent, err := parseParent(pom.filePath, pom.content.Parent)
	if err != nil {
		log.Error("parse parent error: ", err)
		return err
	}

	// Inherit values/properties from parent
	pom.inherit(parent)

	// Merge properties
	pom.content.Properties = mergeProperties(pom.content.Properties, parent.content.Properties)

	// Merge dependencyManagement with the following priority:
	// 1. Managed dependencies from this POM
	// 2. Managed dependencies from parent of this POM
	pom.content.DependencyManagement.Dependencies.Dependency = mergeDependencyManagements(
		pom.content.DependencyManagement.Dependencies.Dependency,
		parent.content.DependencyManagement.Dependencies.Dependency)

	// Merge dependencies
	pom.content.Dependencies.Dependency = mergeDependencies(
		pom.content.Dependencies.Dependency,
		parent.content.Dependencies.Dependency)

	return nil
}

func mergeDependencyManagements(depManagements ...[]pomDependency) []pomDependency {
	uniq := set.New[string]()
	var depManagement []pomDependency
	// The preceding argument takes precedence.
	for _, dm := range depManagements {
		for _, dep := range dm {
			if uniq.Contains(dep.Name()) {
				continue
			}
			depManagement = append(depManagement, dep)
			uniq.Append(dep.Name())
		}
	}
	return depManagement
}

func parseDependencies(deps []pomDependency, props map[string]string, depManagement []pomDependency,
	opts analysisOptions) []artifact {
	// Imported POMs often have no dependencies, so dependencyManagement resolution can be skipped.
	if len(deps) == 0 {
		return nil
	}

	// Resolve dependencyManagement
	depManagement = resolveDepManagement(props, depManagement)

	rootDepManagement := opts.depManagement
	var dependencies []artifact
	for _, d := range deps {
		// Resolve dependencies
		d = d.Resolve(props, depManagement, rootDepManagement)

		if (d.Scope != "" && d.Scope != "compile" && d.Scope != "runtime") || d.Optional {
			continue
		}

		dependencies = append(dependencies, d.ToArtifact(opts))
	}
	return dependencies
}

func resolveDepManagement(props map[string]string, depManagement []pomDependency) []pomDependency {
	var newDepManagement, imports []pomDependency
	for _, dep := range depManagement {
		// cf. https://howtodoinjava.com/maven/maven-dependency-scopes/#import
		if dep.Scope == "import" {
			imports = append(imports, dep)
		} else {
			// Evaluate variables
			newDepManagement = append(newDepManagement, dep.Resolve(props, nil, nil))
		}
	}

	// Managed dependencies with a scope of "import" should be processed after other managed dependencies.
	// cf. https://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html#importing-dependencies
	for _, imp := range imports {
		art := newArtifact(imp.GroupID, imp.ArtifactID, imp.Version, nil, props)
		result, err := resolve(art, nil)
		if err != nil {
			continue
		}

		// We need to recursively check all nested depManagements,
		// so that we don't miss dependencies on nested depManagements with `Import` scope.
		newProps := utils.MergeMaps(props, result.properties)
		result.dependencyManagement = resolveDepManagement(newProps, result.dependencyManagement)
		for k, dd := range result.dependencyManagement {
			// Evaluate variables and overwrite dependencyManagement
			result.dependencyManagement[k] = dd.Resolve(newProps, nil, nil)
		}
		newDepManagement = mergeDependencyManagements(newDepManagement, result.dependencyManagement)
	}
	return newDepManagement
}

func mergeProperties(child, parent properties) properties {
	return lo.Assign(parent, child)
}

func mergeDependencies(child, parent []pomDependency) []pomDependency {
	return lo.UniqBy(append(child, parent...), func(d pomDependency) string {
		return d.Name()
	})
}

func filterDependencies(artifacts []artifact, exclusions set.Set[string]) []artifact {
	return lo.Filter(artifacts, func(art artifact, _ int) bool {
		return !excludeDep(exclusions, art)
	})
}

func excludeDep(exclusions set.Set[string], art artifact) bool {
	if exclusions.Contains(art.Name()) {
		return true
	}
	// Maven can use "*" in GroupID and ArtifactID fields to exclude dependencies
	// https://maven.apache.org/pom.html#exclusions
	for exlusion := range exclusions.Iter() {
		// exclusion format - "<groupID>:<artifactID>"
		e := strings.Split(exlusion, ":")
		if (e[0] == art.GroupID || e[0] == "*") && (e[1] == art.ArtifactID || e[1] == "*") {
			return true
		}
	}
	return false
}

func parseParent(currentPath string, parent pomParent) (*pom, error) {
	log := logger.GetLogger()

	// log.Info("Parse.go - parseParent")

	// Pass nil properties so that variables in <parent> are not evaluated.
	target := newArtifact(parent.GroupId, parent.ArtifactId, parent.Version, nil, nil)
	// if version is property (e.g. ${revision}) - we still need to parse this pom
	if target.IsEmpty() && !isProperty(parent.Version) {
		return &pom{content: &pomXML{}}, nil
	}

	//logger := log.WithFields("artifact", target.String())
	// log.Debug("Start parent")
	defer log.Debug("Exit parent")

	parentPOM, err := retrieveParent(currentPath, parent.RelativePath, target)
	if err != nil {
		log.Error("Parent POM not found", err)
		return &pom{content: &pomXML{}}, nil
	}

	if err = resolveParent(parentPOM); err != nil {
		log.Error("parent pom resolve error: %w", err)
		return nil, err
	}

	return parentPOM, nil
}

func retrieveParent(currentPath, relativePath string, target artifact) (*pom, error) {
	// log := logger.GetLogger()

	// log.Info("Parse.go - retrieveParent")

	var errs error

	// Try relativePath
	if relativePath != "" {
		pom, err := tryRelativePath(target, currentPath, relativePath)
		if err != nil {
			errs = multierror.Append(errs, err)
		} else {
			return pom, nil
		}
	}

	// If not found, search the parent director
	pom, err := tryRelativePath(target, currentPath, "../pom.xml")
	if err != nil {
		errs = multierror.Append(errs, err)
	} else {
		return pom, nil
	}

	// If not found, search local/remote remoteRepositories
	pom, err = tryRepository(target.GroupID, target.ArtifactID, target.Version.String())
	if err != nil {
		errs = multierror.Append(errs, err)
	} else {
		return pom, nil
	}

	// Reaching here means the POM wasn't found
	return nil, errs
}

func tryRelativePath(parentArtifact artifact, currentPath, relativePath string) (*pom, error) {
	log := logger.GetLogger()

	// log.Info("Parse.go - tryRelativePath")

	parsedPOM, err := openRelativePom(currentPath, relativePath)
	if err != nil {
		return nil, err
	}

	// To avoid an infinite loop or parsing the wrong parent when using relatedPath or `../pom.xml`,
	// we need to compare GAV of `parentArtifact` (`parent` tag from base pom) and GAV of pom from `relativePath`.
	// See `compare ArtifactIDs for base and parent pom's` test for example.
	// But GroupID can be inherited from parent (`analyze` function is required to get the GroupID).
	// Version can contain a property (`analyze` function is required to get the GroupID).
	// So we can only match ArtifactID's.
	if parsedPOM.artifact().ArtifactID != parentArtifact.ArtifactID {
		return nil, xerrors.New("'parent.relativePath' points at wrong local POM")
	}
	if err := resolveParent(parsedPOM); err != nil {
		log.Error("parent pom resolve error: ", err)
		return nil, err
	}

	if !parentArtifact.Equal(parsedPOM.artifact()) {
		return nil, xerrors.New("'parent.relativePath' points at wrong local POM")
	}

	return parsedPOM, nil
}

func openRelativePom(currentPath, relativePath string) (*pom, error) {

	// e.g. child/pom.xml => child/
	dir := filepath.Dir(currentPath)

	// e.g. child + ../parent => parent/
	filePath := filepath.Join(dir, relativePath)

	isDir, err := isDirectory(filePath)
	if err != nil {
		return nil, err
	} else if isDir {
		// e.g. parent/ => parent/pom.xml
		filePath = filepath.Join(filePath, "pom.xml")
	}

	pom, err := openPom(filePath)
	if err != nil {
		// If the file is not found, return nil to avoid an error.
		return nil, err
	}
	return pom, nil
}

func openPom(filePath string) (*pom, error) {

	f, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	content, err := parsePom(f, false)
	if err != nil {
		return nil, err
	}
	return &pom{
		filePath: filePath,
		content:  content,
	}, nil
}
func tryRepository(groupID, artifactID, version string) (*pom, error) {
	log := logger.GetLogger()

	if version == "" {
		log.Infof("Version missing for %s:%s", groupID, artifactID)
		return nil, fmt.Errorf("version missing for %s:%s", groupID, artifactID)
	}

	// Generate a proper path to the pom.xml
	// e.g. com.fasterxml.jackson.core, jackson-annotations, 2.10.0
	//      => com/fasterxml/jackson/core/jackson-annotations/2.10.0/jackson-annotations-2.10.0.pom
	paths := strings.Split(groupID, ".")
	paths = append(paths, artifactID, version, fmt.Sprintf("%s-%s.pom", artifactID, version))

	// Search local remoteRepositories
	loaded, err := loadPOMFromLocalRepository(paths)
	if err == nil {
		return loaded, nil
	}

	// Search remote remoteRepositories
	loaded, err = fetchPOMFromRemoteRepositories(paths, isSnapshot(version))
	if err == nil {
		return loaded, nil
	}

	return nil, fmt.Errorf("%s:%s:%s was not found in local/remote repositories", groupID, artifactID, version)
}

func loadPOMFromLocalRepository(paths []string) (*pom, error) {
	paths = append([]string{parserStruct.localRepository}, paths...)
	localPath := filepath.Join(paths...)

	return openPom(localPath)
}

func fetchPOMFromRemoteRepositories(paths []string, snapshot bool) (*pom, error) {
	log := logger.GetLogger()

	// Do not try fetching pom.xml from remote repositories in offline mode
	if parserStruct.offline {
		log.Info("Fetching the remote pom.xml is skipped")
		return nil, xerrors.New("offline mode")
	}

	remoteRepos := parserStruct.releaseRemoteRepos
	// Maven uses only snapshot repos for snapshot artifacts
	if snapshot {
		remoteRepos = parserStruct.snapshotRemoteRepos
	}

	// try all remoteRepositories
	for _, repo := range remoteRepos {
		repoPaths := slices.Clone(paths) // Clone slice to avoid overwriting last element of `paths`
		if snapshot {
			pomFileName, err := fetchPomFileNameFromMavenMetadata(repo, repoPaths)
			if err != nil {
				log.Error("fetch maven-metadata.xml error: ", err)
				return nil, err
			}
			// Use file name from `maven-metadata.xml` if it exists
			if pomFileName != "" {
				repoPaths[len(repoPaths)-1] = pomFileName
			}
		}
		fetched, err := fetchPOMFromRemoteRepository(repo, repoPaths)
		if err != nil {
			log.Error("fetch repository error: %w", err)
			return nil, err
		} else if fetched == nil {
			continue
		}
		return fetched, nil
	}
	return nil, fmt.Errorf("the POM was not found in remote remoteRepositories")
}

func remoteRepoRequest(repo string, paths []string) (*http.Request, error) {
	log := logger.GetLogger()

	repoURL, err := url.Parse(repo)
	if err != nil {
		log.Error("unable to parse URL: ", err)
		return nil, err
	}

	paths = append([]string{repoURL.Path}, paths...)
	repoURL.Path = path.Join(paths...)

	req, err := http.NewRequest(http.MethodGet, repoURL.String(), http.NoBody)
	if err != nil {
		log.Error("unable to create HTTP request: ", err)
		return nil, err
	}
	if repoURL.User != nil {
		password, _ := repoURL.User.Password()
		req.SetBasicAuth(repoURL.User.Username(), password)
	}

	return req, nil
}

// fetchPomFileNameFromMavenMetadata fetches `maven-metadata.xml` file to detect file name of pom file.
func fetchPomFileNameFromMavenMetadata(repo string, paths []string) (string, error) {
	log := logger.GetLogger()

	// Overwrite pom file name to `maven-metadata.xml`
	mavenMetadataPaths := slices.Clone(paths[:len(paths)-1]) // Clone slice to avoid shadow overwriting last element of `paths`
	mavenMetadataPaths = append(mavenMetadataPaths, "maven-metadata.xml")

	req, err := remoteRepoRequest(repo, mavenMetadataPaths)
	if err != nil {
		log.Error("Unable to create request", "repo", repo, err)
		return "", nil
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Error("Failed to fetch", "url", req.URL.String(), err)
		return "", nil
	} else if resp.StatusCode != http.StatusOK {
		log.Info("Failed to fetch", "url", req.URL.String(), "statusCode", resp.StatusCode)
		return "", nil
	}
	defer resp.Body.Close()

	mavenMetadata, err := parseMavenMetadata(resp.Body)
	if err != nil {
		log.Errorf("failed to parse maven-metadata.xml file: %w", err)
		return "", err
	}

	var pomFileName string
	for _, sv := range mavenMetadata.Versioning.SnapshotVersions {
		if sv.Extension == "pom" {
			// mavenMetadataPaths[len(mavenMetadataPaths)-3] is always artifactID
			pomFileName = fmt.Sprintf("%s-%s.pom", mavenMetadataPaths[len(mavenMetadataPaths)-3], sv.Value)
		}
	}

	return pomFileName, nil
}

func fetchPOMFromRemoteRepository(repo string, paths []string) (*pom, error) {
	log := logger.GetLogger()

	req, err := remoteRepoRequest(repo, paths)
	if err != nil {
		log.Error("Unable to create request", "repo", repo, err)
		return nil, nil
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Error("Failed to fetch", "url", req.URL.String(), err)
		return nil, nil
	} else if resp.StatusCode != http.StatusOK {
		log.Error("Failed to fetch", "url", req.URL.String(), "statusCode", resp.StatusCode)
		return nil, nil
	}
	defer resp.Body.Close()

	content, err := parsePom(resp.Body, false)
	if err != nil {
		log.Errorf("failed to parse the remote POM: %w", err)
		return nil, err
	}

	return &pom{
		filePath: "", // from remote repositories
		content:  content,
	}, nil
}

func parsePom(r io.Reader, lineNumber bool) (*pomXML, error) {
	log := logger.GetLogger()

	parsed := &pomXML{}
	decoder := xml.NewDecoder(r)
	decoder.CharsetReader = charset.NewReaderLabel
	if err := decoder.Decode(parsed); err != nil {
		log.Errorf("xml decode error: %w", err)
		return nil, err
	}
	if !lineNumber {
		for i := range parsed.Dependencies.Dependency {
			parsed.Dependencies.Dependency[i].StartLine = 0
			parsed.Dependencies.Dependency[i].EndLine = 0
		}
	}
	return parsed, nil
}

func parseMavenMetadata(r io.Reader) (*Metadata, error) {
	log := logger.GetLogger()

	parsed := &Metadata{}
	decoder := xml.NewDecoder(r)
	decoder.CharsetReader = charset.NewReaderLabel
	if err := decoder.Decode(parsed); err != nil {
		log.Errorf("xml decode error: %w", err)
		return nil, err
	}
	return parsed, nil
}

func thisPackageID(name, version string) string {
	return dependency.ID(langTypes.Pom, name, version)
}

// cf. https://github.com/apache/maven/blob/259404701402230299fe05ee889ecdf1c9dae816/maven-artifact/src/main/java/org/apache/maven/artifact/DefaultArtifact.java#L482-L486
func isSnapshot(ver string) bool {
	return strings.HasSuffix(ver, "SNAPSHOT") || ver == "LATEST"
}
