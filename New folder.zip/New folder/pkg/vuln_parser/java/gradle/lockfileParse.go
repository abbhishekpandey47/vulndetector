package gradle

import (
	"bufio"
	"strings"

	"github.com/scanner/internals/db/langTypes"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/vuln_detector/dependency"
	parser_utils "github.com/scanner/pkg/vuln_parser/parser_utils"
	xio "github.com/scanner/pkg/vuln_x_utils/io"
)

func Parse(r xio.ReadSeekerAt, rootPath string) ([]types.Package, []types.Dependency, error) {
	var pkgs []types.Package
	scanner := bufio.NewScanner(r)
	var lineNum int
	for scanner.Scan() {
		lineNum++
		line := strings.TrimSpace(scanner.Text())
		if strings.HasPrefix(line, "#") { // skip comments
			continue
		}

		// dependency format: group:artifact:version=classPaths
		dep := strings.Split(line, ":")
		if len(dep) != 3 { // skip the last line with lists of empty configurations
			continue
		}

		name := strings.Join(dep[:2], ":")
		version := strings.Split(dep[2], "=")[0] // remove classPaths
		pkgs = append(pkgs, types.Package{
			ID:      dependency.ID(langTypes.Gradle, name, version),
			Name:    name,
			Version: version,
			Locations: []types.Location{
				{
					StartLine: lineNum,
					EndLine:   lineNum,
				},
			},
			Relationship: types.RelationshipUnknown,
		})

	}
	return parser_utils.UniquePackages(pkgs), nil, nil
}
