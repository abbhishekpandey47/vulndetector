package cloudSuitabilityAnalyzer

import (
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"

	//"log"
	"os"
	"runtime"
	"runtime/debug"

	//"runtime/pprof"
	"embed"

	"github.com/scanner/constant"
	db "github.com/scanner/internals/db/cloudSuitabilityAnalyzer"
	models "github.com/scanner/models"
	model "github.com/scanner/models/cloudSuitabilityAnalyzer"
	"github.com/scanner/pkg/cloudSuitabilityAnalyzer/search"
	"github.com/scanner/pkg/logger"
	util "github.com/scanner/pkg/utils"
	utils "github.com/scanner/pkg/utils/cloudSuitabilityAnalyzer"

	"github.com/pkg/profile"
	"github.com/sirupsen/logrus"
)

// to generate the Bootstrap.go file
//
//go:generate go run scripts/generate_bootstrap.go >&2
var (
	//go:embed resources/report-templates/*
	reportTemplates embed.FS
)

var (
	Version   string
	BuildDate string
	CommitSha string
	Path      string
)

func RunCloudSuitabilityAnalyzer(scanRrquest models.ScanRequest, path string, language []string) string{
	log := logger.GetLogger()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRrquest,
		"logMassage":  constant.CSAScanInitiating,
		"progress":    constant.ProgressValueFiftyfive,
	}).Info("====SendLogMessage ====API:  Intiating Cloud Adaptability Scan.==== payload===")
		log.Println("13th API Request Intiated====", constant.APIEnable)
		util.SendLogMessage(scanRrquest, constant.CSAScanInitiating, constant.ProgressValueFiftyfive)
		log.Println("13th API Request completed====", constant.CSAScanInitiating)
		
	adminMode := false

	debug.SetMaxThreads(100000)

	app := utils.App
	Path = path
	exportDir, err := util.GetCodeAnalyzerScanResultsPath(scanRrquest, "cloud-adaptability")
	tempDri, _ := util.CreateTempDirectory()
	//tempExportDri := filepath.Join(tempDri, scanRrquest.TenantID, scanRrquest.AppID, "scan_result", scanRrquest.ComponentID, scanRrquest.ScanID, scanRrquest.RunID, "TempFile")
	tempExportDri, err := CreateAndHideFolder(tempDri, scanRrquest.TenantID, scanRrquest.AppID, scanRrquest.ComponentID, scanRrquest.ScanResultID)
	if err != nil {
		log.Fatalf("Failed to create and hide folder: %v", err)
	} else {
		utils.ExportDir = tempExportDri
	}
	app.HelpFlag.Short('h')
	app.Version(Version)
	app.Author("VMware by Broadcom")

	var run = model.NewRun()
	run.Command = utils.ANALYZE_CMD
	run.Target = Path
	run.TenantID = scanRrquest.TenantID
	run.ScanID = scanRrquest.ScanID
	run.ComponentID = scanRrquest.ComponentID
	run.AppID = scanRrquest.AppID

	procsAndThreads()
	if *utils.Zap {
		var dbFile = *utils.DbDir + "/" + *utils.DBName + ".db"
		var err = os.Remove(dbFile)
		if err != nil {
			fmt.Println(err)
			os.Exit(1)
		}
	}

	run.DB = db.OpenDB(run)
	defer run.Cleanup()
	switch *utils.Profile {
	case "cpu":
		defer profile.Start().Stop()
	case "mem":
		defer profile.Start(profile.MemProfile).Stop()
	}

	repoMgr := db.NewRepositoriesManagerForRun(run)
	repoMgr.Rules.ImportRules()
	switch run.Command {

	case utils.ExportRulesCmd.FullCommand():
		repoMgr.Rules.ExportRules()
		os.Exit(0)
	case utils.ImportRulesCmd.FullCommand():
		repoMgr.Rules.ImportRules()
		os.Exit(0)
	case utils.DeleteRulesCmd.FullCommand():
		repoMgr.Rules.DeleteRule(*utils.DeleteRulesName)
		os.Exit(0)
	case utils.DeleteAllRulesCmd.FullCommand():
		repoMgr.Rules.DeleteAllRules()
		os.Exit(0)
	case utils.ValidateRuleCmd.FullCommand():
		repoMgr.Rules.ValidateRule(*utils.ValidateRuleName, run)
		os.Exit(0)
	case utils.ExportModelsCmd.FullCommand():
		repoMgr.Scoring.ExportModels()
		os.Exit(0)
	case utils.ImportModelsCmd.FullCommand():
		repoMgr.Scoring.ImportModels()
		os.Exit(0)
	case utils.DeleteModelsCmd.FullCommand():
		repoMgr.Scoring.DeleteModel(*utils.DeleteModelName)
		os.Exit(0)
	case utils.DeleteAllModelsCmd.FullCommand():
		repoMgr.Scoring.DeleteAllModels(true)
		os.Exit(0)
	case utils.ValidateModelCmd.FullCommand():
		repoMgr.Scoring.ValidateModel(*utils.ValidateModelName, run)
		os.Exit(0)
	case utils.ExportBinsCmd.FullCommand():
		repoMgr.Bins.ExportBins()
		os.Exit(0)
	case utils.ImportBinsCmd.FullCommand():
		rules, _ := repoMgr.Rules.GetRules()
		repoMgr.Bins.ImportBins(rules)
		os.Exit(0)
	case utils.DeleteBinsCmd.FullCommand():
		repoMgr.Bins.DeleteBin(*utils.DeleteBinName)
		os.Exit(0)
	case utils.DeleteAllBinsCmd.FullCommand():
		repoMgr.Bins.DeleteAllBins(true)
		os.Exit(0)
	case utils.GitCmd.FullCommand():
		run.SetPaths(*utils.GitPath)
		run.SetRequestedReports(utils.ReportsFlag, "1,2,3")
		run.ValidateRun()
		gitReportService := NewGitReportService(repoMgr.Run)
		gitReportService.RunGitReports(run)
	case utils.AnalyzeCmd.FullCommand():
		run.SetPaths(Path)
		run.SetRequestedReports(utils.ReportsFlag, "1,2,3,4,5")
		run.ValidateRun()
		reportService := NewReportSvc(repoMgr, reportTemplates)
		csaService := NewCsaSvc(repoMgr, reportService)
		csaService.PerformAnalysis(run)
	case utils.RecalculateCmd.FullCommand():
		run.SetPaths(Path)
		run.SetRequestedReports(utils.ReportsFlag, "1,2,3,4,5")
		run.ValidateRun()
		reportService := NewReportSvc(repoMgr, reportTemplates)
		csaService := NewCsaSvc(repoMgr, reportService)
		csaService.PerformRecalculate(run)
	case utils.NatLangCmd.FullCommand():
		run.SetPaths(*utils.NatLangPath)
		run.ValidateRun()
		naturalLanguageService := NewNaturalLanguageService(repoMgr.Run)
		naturalLanguageService.LangProcess(run)
	// case utils.CsaCmd.FullCommand():
	// 	adminMode = true
	// 	port := utils.CsaPort
	// 	routes.StartRouter(run.DB, true, *port)
	case utils.SearchCmd.FullCommand():
		adminMode = true
		repoMgr := db.NewRepositoriesManager(run.DB)
		for true {
			search.ExecuteCLISearch(repoMgr)
		}
	case utils.BuildInfoCmd.FullCommand():
		fmt.Println("****************************************************************************************")
		fmt.Println("*                             CSA BUILD DETAILS                                      *")
		fmt.Println("****************************************************************************************")
		fmt.Printf("\nVERSION:\t%s\n", Version)
		fmt.Printf("BUILD DATE:\t%s\n", BuildDate)
		fmt.Printf("COMMIT REF:\t%s\n", CommitSha)
		adminMode = true
	default:
		err := fmt.Errorf("[%s] is an unknown Cmd!\n", run.Command)
		app.FatalUsage("%s\n", err)
		os.Exit(1)
	}
	if !adminMode {
		run.CompletionMessage()
	}

	csvpath := filepath.Join(tempExportDri, "export.csv")
	resultFilePath, err:=util.ConvertCSVToJSON(csvpath, exportDir, scanRrquest, language)
    if err != nil {
		log.Fatalf("Failed to convert CSV file to Json: %v", err)
	}
	return resultFilePath

}

func procsAndThreads() {

	mp := runtime.NumCPU()
	mt := 10000

	if *utils.MaxProcs > 0 {
		runtime.GOMAXPROCS(*utils.MaxProcs)
		mp = *utils.MaxProcs
	}

	if *utils.MaxThreads > 0 {
		debug.SetMaxThreads(*utils.MaxThreads)
		mt = *utils.MaxThreads
	}

	if *utils.Efd {
		fmt.Println("Finding details will be removed")
	}

	if *utils.Verbose {
		fmt.Println("		 GO RUNTIME		")
		fmt.Println("-----------------------")
		fmt.Printf("MAX PROCS ==> %d\n", mp)
		fmt.Printf("MAX OS THREADS ==> %d\n\n\n", mt)
	}

	if *utils.Verbose {
		logrus.StandardLogger().Level = logrus.DebugLevel
	}

}

// CreateAndHideFolder creates a hidden folder named .TempFile cross-platform.
func CreateAndHideFolder(basePath, tenantID, appID, componentID, scanResultID string) (string, error) {
	// Use ".TempFile" to automatically hide on Unix-based systems
	hiddenFolder := filepath.Join(basePath, tenantID, appID, "scan_result", componentID,scanResultID, ".TempFile")

	// Create the directory structure
	err := os.MkdirAll(hiddenFolder, 0755)
	if err != nil {
		return "", err
	}

	// Platform-specific hiding
	if runtime.GOOS == "windows" {
		// Escape any trailing slashes for Windows attrib command
		safePath := strings.TrimRight(hiddenFolder, `\/`)
		cmd := exec.Command("attrib", "+h", safePath)
		if err := cmd.Run(); err != nil {
			return "", err
		}
	}

	return hiddenFolder, nil
}
