package cloudSuitabilityAnalyzer

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"

	db "github.com/scanner/internals/db/cloudSuitabilityAnalyzer"

	model "github.com/scanner/models/cloudSuitabilityAnalyzer"
	"github.com/scanner/pkg/cloudSuitabilityAnalyzer/search"
	utils "github.com/scanner/pkg/utils/cloudSuitabilityAnalyzer"
)

// Step 5: Application Analysis Function
func (csaService *CsaService) analyzeApp(run *model.Run, app *model.Application, output chan<- interface{}) (errors []error) {
	// Step 5.1: Start activity tracking for this specific application
	run.StartActivity(fmt.Sprintf("%s-analysis", app.Name))

	// Step 5.2: Create wait group for managing concurrent file analysis
	waitGroup := sync.WaitGroup{}

	// Step 5.3: Initialize progress spinners for visual feedback
	utils.InitializeSpinners(len(run.Applications))

	// Step 5.4: Calculate modulo count for progress reporting
	modCnt := utils.GetModCount(run.Files)

	// Step 5.5: Log mod count if verbose mode is enabled
	if *utils.Verbose {
		fmt.Printf("Got Mod Count [%d]\n", modCnt)
	}

	// Step 5.6: Concurrent file analysis loop
	for i := range app.Files {
		// Add file to wait group
		waitGroup.Add(1)

		// Step 5.7: Launch goroutine for each file
		go func(idx int) {
			defer waitGroup.Done()

			// Step 5.8: Verbose logging of file scanning
			if *utils.Verbose {
				utils.WriteLog(fmt.Sprintf("Analyzing - %s", app.Name), "Scanning Files...   Filename: %s\n", app.Files[idx].FQN)
			}

			// Step 5.9: Analyze individual file
			err := csaService.analyzeFile(run, app, app.Files[idx], csaService.saveChan)

			// Step 5.10: Error handling
			if err != nil {
				if *utils.FailFast {
					// Exit immediately if failfast is enabled
					utils.WriteLog("Analyzing...error!", "Error occurred during analysis! Details: %s", err.Error())
					csaService.stopRun(run)
					os.Exit(2)
				} else {
					// Collect error and continue
					errors = append(errors, err)
				}
			} else {
				// Step 5.11: Progress tracking and reporting
				run.FileAnalyzed()
				modResult := run.AnalyzedCnt % modCnt
				if modResult == 0 {
					utils.WriteLogWithToken("Analyzing!", fmt.Sprintf("%2.f%%", float64(run.AnalyzedCnt)/float64(run.Files)*100), "Filename: %s...done\n!", app.Files[idx].FQN)
				}
			}
		}(i)
	}

	// Step 5.12: Wait for all file analysis to complete
	waitGroup.Wait()

	// Step 5.13: Final progress reporting
	utils.WriteLogWithToken("Analyzing", fmt.Sprintf("%2.f%%", float64(run.AnalyzedCnt)/float64(run.Files)*100), "App: %s...done\n!", app.Name)

	// Step 5.14: Stop activity tracking
	if !*utils.Xtract {
		run.StopActivity(fmt.Sprintf("%s-analysis", app.Name), fmt.Sprintf("Analyzing - %s...done!", app.Name), true)
	} else {
		run.StopActivity(fmt.Sprintf("%s-analysis", app.Name), "", false)
	}

	return
}

// Analyzes a single file against all applicable rules and records findings
func (csaService *CsaService) analyzeFile(run *model.Run, app *model.Application, file *utils.FileInfo, output chan<- interface{}) error {

	// Slice to store rules that will be applied to this file
	var rulesForFile []model.Rule
	// Tracks names of rules used in analysis
	var rulesUsed []string

	// Counter for total findings in this file
	findings := 0
	// Flag indicating if file content was analyzed
	wasAnalyzed := false
	// Flag indicating if filename was analyzed
	fileNameAnalyzed := false
	// Flag indicating presence of content-based rules
	hasContentRules := false

	// Iterate through all rules in the application
	var index []int
	for i := range app.Rules {
		// Check if rule applies to this file type and name
		if app.Rules[i].Applies(file.GetCleanedExt(), file.Name) {
			// Add rule name to tracking list
			rulesUsed = append(rulesUsed, app.Rules[i].Name)
			index = append(index, i)
			// Log rule application in verbose mode
			if *utils.Verbose {
				utils.WriteLog("Analyzing", "Rule [%s] applies to file [%s|%s|%s]\n", app.Rules[i].Name, file.Name, file.Ext, file.FQN)
			}
			var findingCnt int
			// Handle line-by-line analysis rules
			if app.Rules[i].Target == model.LINE_TARGET {
				rulesForFile = append(rulesForFile, app.Rules[i])
				wasAnalyzed = true
				// Handle full content analysis rules
			} else if app.Rules[i].Target == model.CONTENTS_TARGET {
				rulesForFile = append(rulesForFile, app.Rules[i])
				hasContentRules = true
				wasAnalyzed = true
				// Handle filename pattern rules
			} else {
				findingCnt, app.Rules[i] = csaService.processPatterns(run, app, file, 0, filepath.Base(file.Name), app.Rules[i], output)
				findings += findingCnt
				fileNameAnalyzed = true
			}
		}
	}

	// Process file content with collected rules
	_, fileFindings, err := csaService.processFile(run, app, file, rulesForFile, hasContentRules, output)

	// Handle any processing errors
	if err != nil {
		return err
	}

	// Add content findings to total
	findings += fileFindings

	// Create summary if any analysis was performed
	if wasAnalyzed || fileNameAnalyzed {
		// Build message string
		var msg string
		var rulesUsedMsg strings.Builder

		// Create comma-separated list of used rules
		cnt := 0
		for _, rule := range rulesUsed {
			if cnt > 0 {
				rulesUsedMsg.WriteString(",")
			}
			rulesUsedMsg.WriteString(rule)
			cnt++
		}

		// Set appropriate message based on analysis type
		if wasAnalyzed {
			msg = fmt.Sprintf("File read and analyzed fully! [%d] findings were documented! Rules Used: %s", findings, rulesUsedMsg.String())
		} else {
			msg = fmt.Sprintf("Filename was analyzed! [%d] findings were documented! Rules Used: %s", findings, rulesUsedMsg.String())
		}

		// Create info finding record
		fileFinding := model.Finding{
			TenantID:    run.TenantID,
			ScanID:      run.ScanID,
			AppID:       run.AppID,
			ComponentID: run.ComponentID,
			RunID:       run.ID,
			Filename:    file.Name,
			Fqn:         file.FQN,
			Ext:         file.Ext,
			Category:    model.FILE_ANALYZED_CATEGORY,
			Pattern:     model.ANALYZED_FILE_PATTERN,
			Effort:      0,
			Readiness:   0,
			Criticality: "none",
			Ruleset:     app.Rules[0].Ruleset,
			Application: file.Dir}

		// Set finding details
		fileFinding.SetValue(msg)
		fileFinding.AddTag(model.INFO_FINDING)
		fileFinding.AddTag(model.FILE_FINDING)
		for i, _ := range index {
			fileFinding.Ruleset = fileFinding.Ruleset + app.Rules[i].Ruleset + ", "
			fileFinding.Title = fileFinding.Title + app.Rules[i].Title + ", "
			fileFinding.Description = fileFinding.Description + app.Rules[i].Description + ", "
			fileFinding.BlockerBooster = fileFinding.BlockerBooster + app.Rules[i].BlockerBooster + ", "
			fileFinding.MigrationImpact = fileFinding.MigrationImpact + app.Rules[i].MigrationImpact + ", "
			fileFinding.Remediation = fileFinding.Remediation + app.Rules[i].Remediation + ", "
		}
		// Send finding to output channel
		output <- fileFinding

		// Increment total findings counter
		run.AddFindings(1)
	}

	// Log completion in verbose mode
	if *utils.Verbose {
		utils.WriteLog("Analyzing", "************ FILE [%s] FINDINGS [%d] ***************\n", file.Name, findings)
	}

	return nil
}

func (csaService *CsaService) saveFindingToDb(id string, work <-chan interface{}, result chan<- interface{}, jointWorker chan<- interface{}, args []interface{}) {

	if len(args) < 1 {
		log.Fatalf("Invalid Arguments for %s!", id)
	}

	run := args[0].(*model.Run)
	run.StartActivity("saving")

	tx := db.StartGormTransaction()
	defer tx.Commit()

	for w := range work {
		target := w.(model.Finding)

		if db.SaveFindingTransacted(tx, &target) {
			csaService.findingsSaved++
			if *utils.TxtIndexingEnabled {
				jointWorker <- target
			}

			if csaService.analysisDone {
				modCnt := utils.GetModCount(run.Findings)
				if csaService.findingsSaved%modCnt == 0 {
					utils.WriteLogWithToken("Saving", fmt.Sprintf("%2.f%%", float64(csaService.findingsSaved)/float64(run.Findings)*100), "Finding: %d saved\n!", target.ID)
				}
			}
		} else {

			utils.TrackError("Saving", fmt.Errorf("error saving finding for file [%s]", target.Fqn))

			if *utils.FailFast {
				tx.Rollback()
				fmt.Println("Error saving finding during run! Fail Fast Enabled! Stopping Run!")
				utils.WriteLog("Saving...failed!", "Failed saving finding for file [%s]", target.Fqn)
				csaService.stopRun(run)
				os.Exit(2)
			}
		}

	}
	//We are done saving!
	result <- true
}

func (csaService *CsaService) addFindingToTextIndex(id string, work <-chan interface{}, result chan<- interface{}, jointWorker chan<- interface{}, args []interface{}) {

	if len(args) < 1 {
		log.Fatalf("Invalid Arguments for %s!", id)
	}

	run := args[0].(*model.Run)
	run.StartActivity("indexing")

	index := search.GetIndex(run)

	indexAvail := true

	if !index.Exists || index.Error != "" {
		fmt.Fprintf(os.Stderr, "[%s] - Error obtaining text index. Details: %s\n", id, index.Error)
		indexAvail = false
	}

	for w := range work {
		target := w.(model.Finding)
		//Add to text index
		if *utils.Verbose {
			fmt.Printf("[%s] - Indexing finding [%d]\n", id, target.ID)
		}

		if indexAvail {
			err := index.AddItemToIndex(fmt.Sprint(target.ID), target)
			if err != nil {
				utils.TrackError("Indexing", err)
			} else {
				csaService.findingsIndexed++
			}
		}
		if csaService.savingDone {
			modCnt := utils.GetModCount(run.Findings)
			if csaService.findingsIndexed%(modCnt) == 0 {
				utils.WriteLogWithToken("Indexing", fmt.Sprintf("%2.f%%", float64(csaService.findingsIndexed)/float64(run.Findings)*100), "Finding: %d indexed\n!", target.ID)
			}
		}
	}
	//We are done indexing!
	result <- true
}

