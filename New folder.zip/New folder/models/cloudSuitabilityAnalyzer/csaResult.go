package cloudSuitabilityAnalyzer
 
type CSAScanResults struct {
    TechStack   string      `json:"tech_stack"`
    ScanType    string      `json:"scan_type"`
    ScanResults struct {
        Results []CSAResult `json:"Results"` // Rename the field to match the JSON format
    } `json:"scan_results"`
}
 
type CSAResult struct {
    ID                string `json:"id"`
    CreatedAt         string `json:"created_at"`
    UpdatedAt         string `json:"updated_at"`
    RunID             string `json:"run_id"`
    Filename          string `json:"filename"`
    FQN               string `json:"fqn"`
    Ext               string `json:"ext"`
    Line              string `json:"line"`
    Rule              string `json:"rule"`
    Pattern           string `json:"pattern"`
    Value             string `json:"value"`
    Note              string `json:"note"`
    Advice            string `json:"advice"`
    Effort            string `json:"effort"`
    Category          string `json:"category"`
    Criticality       string `json:"criticality"`
    CloudNativeEffort string `json:"cloud_native_effort"`
    ContainerEffort   string `json:"container_effort"`
    Level             string `json:"level"`
    Readiness         string `json:"readiness"`
    Application       string `json:"application"`
    Result            string `json:"result"`
}