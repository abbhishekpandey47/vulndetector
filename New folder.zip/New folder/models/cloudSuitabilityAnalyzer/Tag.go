package cloudSuitabilityAnalyzer

import "time"

type Tag struct {
	ID        uint      `gorm:"primary_key" json:"-" yaml:"-"`
	CreatedAt time.Time `json:"-" yaml:"-"`
	UpdatedAt time.Time `json:"-" yaml:"-"`
	RuleID    uint      `sql:"type:bigint REFERENCES rules(id) ON DELETE CASCADE" json:"-"  yaml:"-"`
	Rule      Rule      `gorm:"foreignkey:RuleID" json:"-"  yaml:"-"`
	Value     string    `gorm:"type:text"`
}
