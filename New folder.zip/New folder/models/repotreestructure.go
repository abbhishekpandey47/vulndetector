package models

type RepoTreeWrapper struct {
	ScanRequest ScanRequest `json:"scan_request"`
	Data        interface{} `json:"data"` // The actual structure passed to the function
}

// FileData represents collected file information
type FileData struct {
	Size         int64  `json:"size"`
	Extension    string `json:"extension"`
	LastModified string `json:"last_modified"`
	// Add new fields here with appropriate json tags
}

// Result wraps the ScanRequest and tree structure
type Result struct {
	ScanRequest ScanRequest `json:"scan_request"`
	ScanType    string      `json:"scan_type"`
	TechStack   string      `json:"tech_stack"`
	Result      Node        `json:"Result"`
}

// Node represents a file or folder
// Node represents a file or folder in the repo tree
type Node struct {
	Name                   string                   `json:"name"`
	Type                   string                   `json:"type"`
	Children               []Node                   `json:"children,omitempty"`
	CloudSuitabilityResult []map[string]interface{} `json:"cloud_suitability_result,omitempty"`
	CodeHealthViolations   []interface{}            `json:"code_health_violations,omitempty"`
}

// RepoTreeFile wraps the actual Node tree under "Result"
type RepoTreeFile struct {
	ScanRequest map[string]interface{} `json:"scan_request"`
	ScanType    string                 `json:"scan_type"`
	TechStack   string                 `json:"tech_stack"`
	Result      Node                   `json:"Result"` // <- This is the actual root node
}
