package models

import "encoding/xml"

// Define a structure that represents the relevant part of the pom.xml
type Project struct {
	XMLName    xml.Name `xml:"project"`
	Properties struct {
		JavaVersion string `xml:"java.version"`
	} `xml:"properties"`
}

// Function to get Node.js version
type PackageJSON struct {
	Engines map[string]string `json:"engines"`
}

// Define structure for the .csproj file
type Csproj struct {
	XMLName                xml.Name `xml:"Project"`
	TargetFramework        string   `xml:"PropertyGroup>TargetFramework"`
	TargetFrameworks       string   `xml:"PropertyGroup>TargetFrameworks"`
	TargetFrameworkVersion string   `xml:"PropertyGroup>TargetFrameworkVersion"`
}

type PackageJson struct {
	Dependencies    map[string]string `json:"dependencies"`
	DevDependencies map[string]string `json:"devDependencies"`
}
