package models

// Define the structure to match the JSON format of the request body
type ActionPayload struct {
	ScanRequest ScanRequest `json:"scan_request"`
	ScanType    string      `json:"scan_type"`
	FilePath    string      `json:"file_path"`
}

type RequestBody struct {
	Action        string        `json:"action"`
	TenantId      string        `json:"tenant_id"`
	ActionPayload ActionPayload `json:"action_payload"`
}

//log Messages API
type LogMessage struct {
	Action        string           `json:"action"`
	TenantID      string           `json:"tenant_id"`
	ActionPayload LogActionPayload `json:"action_payload"`
}

type LogActionPayload struct {
	ScanRequest    ScanRequest `json:"scan_request"`
	LogMessage     string      `json:"log_message"`
	ProgressValues int         `json:"progress_values"`
}

type ChangeStatus struct {
	Action        string              `json:"action"`
	TenantID      string              `json:"tenant_id"`
	ActionPayload StatusActionPayload `json:"action_payload"`
}

type StatusActionPayload struct {
	ScanRequest ScanRequest `json:"scan_request"`
	Value       string      `json:"value"`
}
