package models

import "fmt"

type TechStack struct {
	ScanRequest          ScanRequest      `json:"scan_request"`
	ScanType             string           `json:"scan_type"`
	TechStack            Tech_stack       `json:"tech_stack"`
	Loc                  int              `json:"loc"`
	TotalFileCount       int              `json:"total_file_count"`
	FileCountByExtension []ExtensionCount `json:"file_count_by_extension"`
}

// Custom struct to represent the file extension and count
type ExtensionCount struct {
	Extension string `json:"extension"`
	Count     int    `json:"count"`
}

type Tech_stack struct {
	Language  []string `json:"language"`
	Framework []string `json:"framework"`
}

// This method is automatically used during JSON marshalling of ExtensionCount
func (ec ExtensionCount) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(`{"%s": %d}`, ec.Extension, ec.Count)), nil
}
