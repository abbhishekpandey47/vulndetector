package models

// RepoDetails represents the structure of the repository details
type RepoDetails struct {
	LogicalRepoName    string `json:"logical_repo_name"`
	RootURL            string `json:"root_url"`
	RepoType           string `json:"repo_type"`
	AuthType           string `json:"auth_type"`
	Username           string `json:"username"`
	Password           string `json:"password"`
	PasswordSecretKey  string `json:"password_secret_key"`
	AuthToken          string `json:"auth_token"`
	AuthTokenSecretKey string `json:"auth_token_secret_key"`
	ActualRepoName     string `json:"actual_repo_name"`
	SSHKeyPath         string `json:"SSH_key_path"`
}

// ScanRequest represents the structure of the scan request
type ScanRequest struct {
	RunID        string `json:"run_id"`
	ScanResultID string `json:"scan_result_id"`
	ScanID       string `json:"scan_id"`
	ComponentID  string `json:"component_id"`
	AppID        string `json:"app_id"`
	TenantID     string `json:"tenant_id"`
	ScanProfile  string `json:"scan_profile"`
	LaunchedOn   string `json:"launched_on"`
}

// Request represents the structure of the full request
type RequestType struct {
	RequestType string `json:"request_type"`
}

// Request represents the structure of the full request
type EnvType struct {
	EnvType string `json:"env_type"`
}

// Request represents the structure of the full request
type Mode struct {
	Mode string `json:"mode"`
}

type SourceCodeDetails struct {
	Path string `json:"path"`
}

type FullScanPayload struct {
	RequestType       RequestType       `json:"request_type"`
	EnvType           EnvType           `json:"env_type"`
	Mode              Mode              `json:"mode"`
	ScanRequest       ScanRequest       `json:"scan_request"`
	RepoDetails       RepoDetails       `json:"repo_details"`
	SourceCodeDetails SourceCodeDetails `json:"source_code_details"`
}
