package db

import (
	"bytes"
	"encoding/json"
	"path/filepath"
	"strings"

	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	"go.etcd.io/bbolt"
	bolt "go.etcd.io/bbolt"
	"golang.org/x/xerrors"
)

// Global configuration: list of OCI repositories to try (in priority order)
var Vuln_repositories = []string{
	"mirror.gcr.io/aquasec/trivy-db:2",
	"ghcr.io/aquasecurity/trivy-db:2",
}

// type CustomPut func(dbc Operation, tx *bolt.Tx, adv interface{}) error

const (
	DstDir           = "vuln_db_dir"        // Destination directory
	DBFilename       = "vuln.db"            // Renamed DB file
	MetadataFilename = "vuln_metadata.json" // Metadata file name
)

type DB struct {
	bolt *bbolt.DB
}

type Config struct{}

var db *bolt.DB

// NewDB opens the Bolt DB at the correct location.
func NewDB() DB {

	log := logger.GetLogger()

	appDBPath, err := utils.GetCodeAnalyzerVulnDBPath(DstDir)
	if err != nil {
		log.Error("Error in creating DB", err)
		return DB{}
	}

	dbPath := filepath.Join(appDBPath, DBFilename)

	bdb, err := OpenBoltDB(dbPath)
	if err != nil {
		log.Error("Error in Opening DB", err)
		return DB{}
	}
	db = bdb
	return DB{
		bolt: bdb,
	}
}

// Check if the DB is initialized
func (d *DB) IsInitialized() bool {
	if d.bolt == nil {
		return false
	}
	return true
}

// Close closes the underlying Bolt DB.
func (d *DB) Close() error {
	return d.bolt.Close()
}

func (d *DB) ListAllBuckets() ([]string, error) {
	return ListBuckets(d.bolt)
}

// func (d *DB) GetAdvisoriesForSource(source, pkgName string) ([]types.Advisory, error) {
// 	return LoadAdvisoriesForSource(d.bolt, source, pkgName)
// }

type Operation interface {
	BatchUpdate(fn func(*bolt.Tx) error) (err error)

	GetVulnerabilityDetail(cveID string) (detail map[types.SourceID]types.VulnerabilityDetail, err error)
	PutVulnerabilityDetail(tx *bolt.Tx, vulnerabilityID string, source types.SourceID, vulnerability types.VulnerabilityDetail) (err error)
	// DeleteVulnerabilityDetailBucket() (err error)

	ForEachAdvisory(sources []string, pkgName string) (value map[string]types.Value, err error)
	GetAdvisories(source string, pkgName string) (advisories []types.Advisory, err error)

	PutVulnerabilityID(tx *bolt.Tx, vulnerabilityID string) (err error)
	ForEachVulnerabilityID(fn func(tx *bolt.Tx, cveID string) error) (err error)

	PutVulnerability(tx *bolt.Tx, vulnerabilityID string, vulnerability types.Vulnerability) (err error)
	GetVulnerability(vulnerabilityID string) (vulnerability types.Vulnerability, err error)

	SaveAdvisoryDetails(tx *bolt.Tx, cveID string) (err error)
	PutAdvisoryDetail(tx *bolt.Tx, vulnerabilityID, pkgName string, nestedBktNames []string, advisory interface{}) (err error)
	// DeleteAdvisoryDetailBucket() error

	PutDataSource(tx *bolt.Tx, bktName string, source types.DataSource) (err error)

	// For Red Hat
	PutRedHatRepositories(tx *bolt.Tx, repository string, cpeIndices []int) (err error)
	PutRedHatNVRs(tx *bolt.Tx, nvr string, cpeIndices []int) (err error)
	PutRedHatCPEs(tx *bolt.Tx, cpeIndex int, cpe string) (err error)
	RedHatRepoToCPEs(repository string) (cpeIndices []int, err error)
	RedHatNVRToCPEs(nvr string) (cpeIndices []int, err error)
}

func Close() error {
	// Skip closing the database if the connection is not established.
	if db == nil {
		return nil
	}
	if err := db.Close(); err != nil {
		return xerrors.Errorf("failed to close DB: %w", err)
	}
	return nil
}

func (dbc DB) Connection() *bolt.DB {
	return db
}

func (dbc DB) BatchUpdate(fn func(tx *bolt.Tx) error) error {
	err := db.Batch(fn)
	if err != nil {
		return xerrors.Errorf("error in batch update: %w", err)
	}
	return nil
}

func (dbc Config) put(tx *bolt.Tx, bktNames []string, key string, value interface{}) error {
	if len(bktNames) == 0 {
		return xerrors.Errorf("empty bucket name")
	}

	bkt, err := tx.CreateBucketIfNotExists([]byte(bktNames[0]))
	if err != nil {
		return xerrors.Errorf("failed to create '%s' bucket: %w", bktNames[0], err)
	}

	for _, bktName := range bktNames[1:] {
		bkt, err = bkt.CreateBucketIfNotExists([]byte(bktName))
		if err != nil {
			return xerrors.Errorf("failed to create a bucket: %w", err)
		}
	}
	v, err := json.Marshal(value)
	if err != nil {
		return xerrors.Errorf("failed to unmarshal JSON: %w", err)
	}

	return bkt.Put([]byte(key), v)
}

func (dbc DB) get(bktNames []string, key string) (value []byte, err error) {
	err = db.View(func(tx *bolt.Tx) error {
		if len(bktNames) == 0 {
			return xerrors.Errorf("empty bucket name")
		}

		bkt := tx.Bucket([]byte(bktNames[0]))
		if bkt == nil {
			return nil
		}
		for _, bktName := range bktNames[1:] {
			bkt = bkt.Bucket([]byte(bktName))
			if bkt == nil {
				return nil
			}
		}
		dbValue := bkt.Get([]byte(key))

		// Copy the byte slice so it can be used outside of the current transaction
		value = make([]byte, len(dbValue))
		copy(value, dbValue)

		return nil
	})
	if err != nil {
		return nil, xerrors.Errorf("failed to get data from db: %w", err)
	}
	return value, nil
}

type Value struct {
	Source  types.DataSource
	Content []byte
}

func (dbc DB) deleteBucket(bucketName string) error {
	return db.Update(func(tx *bolt.Tx) error {
		if err := tx.DeleteBucket([]byte(bucketName)); err != nil {
			return xerrors.Errorf("failed to delete bucket: %w", err)
		}
		return nil
	})
}

func (dbc Config) forEach(bktNames []string) (map[string]Value, error) {

	log := logger.GetLogger()

	if len(bktNames) < 2 {
		return nil, xerrors.Errorf("bucket must be nested: %v", bktNames)
	}
	rootBucket, nestedBuckets := bktNames[0], bktNames[1:]

	values := map[string]Value{}
	err := db.View(func(tx *bolt.Tx) error {
		var rootBuckets []string

		if strings.Contains(rootBucket, "::") {
			// e.g. "pip::", "rubygems::"
			prefix := []byte(rootBucket)
			c := tx.Cursor()
			for k, _ := c.Seek(prefix); k != nil && bytes.HasPrefix(k, prefix); k, _ = c.Next() {
				rootBuckets = append(rootBuckets, string(k))
			}
		} else {
			// e.g. "GitHub Security Advisory Composer"
			rootBuckets = append(rootBuckets, rootBucket)
		}

		for _, r := range rootBuckets {
			root := tx.Bucket([]byte(r))
			if root == nil {
				continue
			}

			source, err := dbc.getDataSource(tx, tx, r)
			if err != nil {
				log.Errorf("Data source error: %s", err)
			}

			bkt := root
			for _, nestedBkt := range nestedBuckets {
				bkt = bkt.Bucket([]byte(nestedBkt))
				if bkt == nil {
					break
				}
			}
			if bkt == nil {
				continue
			}

			err = bkt.ForEach(func(k, v []byte) error {
				if len(v) == 0 {
					return nil
				}
				// Copy the byte slice so it can be used outside of the current transaction
				copiedContent := make([]byte, len(v))
				copy(copiedContent, v)

				values[string(k)] = Value{
					Source:  source,
					Content: copiedContent,
				}
				return nil
			})
			if err != nil {
				return xerrors.Errorf("db foreach error: %w", err)
			}
		}
		return nil
	})
	if err != nil {
		return nil, xerrors.Errorf("failed to get all key/value in the specified bucket: %w", err)
	}
	return values, nil
}
