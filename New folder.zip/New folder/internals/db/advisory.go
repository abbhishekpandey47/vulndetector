package db

import (
	"encoding/json"

	bolt "go.etcd.io/bbolt"
	"golang.org/x/xerrors"

	"github.com/scanner/internals/db/types"
)

func (dbc Config) PutAdvisory(tx *bolt.Tx, bktNames []string, key string, advisory interface{}) error {
	if err := dbc.put(tx, bktNames, key, advisory); err != nil {
		return xerrors.Errorf("failed to put advisory: %w", err)
	}
	return nil
}

func (dbc Config) ForEachAdvisory(sources []string, pkgName string) (map[string]Value, error) {
	return dbc.forEach(append(sources, pkgName))
}

func (dbc Config) GetAdvisories(source, pkgName string) ([]types.Advisory, error) {
	advisories, err := dbc.ForEachAdvisory([]string{source}, pkgName)
	if err != nil {
		return nil, xerrors.Errorf("advisory foreach error: %w", err)
	}
	if len(advisories) == 0 {
		return nil, nil
	}

	var results []types.Advisory
	for vulnID, v := range advisories {
		var advisory types.Advisory
		if err = json.Unmarshal(v.Content, &advisory); err != nil {
			return nil, xerrors.Errorf("failed to unmarshal advisory JSON: %w", err)
		}

		advisory.VulnerabilityID = vulnID
		if v.Source != (types.DataSource{}) {
			advisory.DataSource = &types.DataSource{
				ID:   v.Source.ID,
				Name: v.Source.Name,
				URL:  v.Source.URL,
			}
		}

		results = append(results, advisory)
	}
	return results, nil
}

const (
	vulnerabilityBucket = "vulnerability"
)

func (dbc Config) PutVulnerability(tx *bolt.Tx, cveID string, vuln types.Vulnerability) error {
	if err := dbc.put(tx, []string{vulnerabilityBucket}, cveID, vuln); err != nil {
		return xerrors.Errorf("failed to put severity: %w", err)
	}
	return nil
}

func (dbc Config) GetVulnerability(cveID string) (vuln types.Vulnerability, err error) {
	err = db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(vulnerabilityBucket))
		value := bucket.Get([]byte(cveID))
		if value == nil {
			return xerrors.Errorf("no vulnerability details for %s", cveID)
		}
		if err = json.Unmarshal(value, &vuln); err != nil {
			return xerrors.Errorf("failed to unmarshal JSON: %w", err)
		}
		return nil
	})
	if err != nil {
		return types.Vulnerability{}, xerrors.Errorf("failed to get the vulnerability %q: %w", cveID, err)
	}
	return vuln, nil
}
