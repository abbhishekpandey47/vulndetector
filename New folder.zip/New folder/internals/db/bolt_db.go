package db

import (
	"encoding/json"
	"fmt"

	"github.com/samber/oops"
	"github.com/scanner/internals/db/types"
	"github.com/scanner/pkg/logger"
	bolt "go.etcd.io/bbolt"
)

const (
	dataSourceBucket = "data-source"
	advisoriesBucket = "vulnerability"
)

// OpenBoltDB opens a Bolt DB at the given path.
func OpenBoltDB(path string) (*bolt.DB, error) {
	db, err := bolt.Open(path, 0644, nil)
	if err != nil {
		err := fmt.Errorf("failed to open bolt db: %w", err)
		return nil, err
	}
	return db, nil
}

// ListBuckets returns a slice of all top-level bucket names in the Bolt DB.
func ListBuckets(bdb *bolt.DB) ([]string, error) {
	log := logger.GetLogger()
	var buckets []string
	err := bdb.View(func(tx *bolt.Tx) error {
		return tx.ForEach(func(name []byte, b *bolt.Bucket) error {
			buckets = append(buckets, string(name))
			return nil
		})
	})
	if err != nil {
		log.Error("failed to list buckets: %w", err)
		return nil, err
	}
	return buckets, nil
}

/*func (dbc DB) LoadAdvisoriesForSource(bdb *bolt.DB, source, pkgName string) ([]types.Advisory, error) {
	eb := oops.With("source", source).With("package_name", pkgName)
	advisories, err := ForEachAdvisory(bdb, []string{source}, pkgName)
	if err != nil {
		return nil, eb.Wrapf(err, "advisory foreach error")
	}
	if len(advisories) == 0 {
		return nil, nil
	}

	var results []types.Advisory
	for vulnID, v := range advisories {
		var advisory types.Advisory
		if err = json.Unmarshal(v.Content, &advisory); err != nil {
			return nil, eb.With("vuln_id", vulnID).Wrapf(err, "json unmarshal error")
		}

		advisory.VulnerabilityID = vulnID
		if v.Source != (types.DataSource{}) {
			advisory.DataSource = &types.DataSource{
				ID:   v.Source.ID,
				Name: v.Source.Name,
				URL:  v.Source.URL,
			}
		}

		results = append(results, advisory)
	}
	return results, nil
}
*/

/******* Helper Functions ********/
func (dbc Config) getDataSource(bdb *bolt.Tx, tx *bolt.Tx, bktName string) (types.DataSource, error) {
	eb := oops.With("root_bucket", dataSourceBucket).With("bucket_name", bktName)
	bucket := tx.Bucket([]byte(dataSourceBucket))
	if bucket == nil {
		return types.DataSource{}, nil
	}

	b := bucket.Get([]byte(bktName))
	if b == nil {
		return types.DataSource{}, nil
	}

	var source types.DataSource
	if err := json.Unmarshal(b, &source); err != nil {
		return types.DataSource{}, eb.Wrapf(err, "json unmarshal error")
	}

	return source, nil
}
