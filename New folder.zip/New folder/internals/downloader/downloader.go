package downloader

import (
	"archive/tar"
	"archive/zip"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/nwaples/rardecode"
	"github.com/scanner/constant"
	"github.com/scanner/models"
	languageanalyzer "github.com/scanner/pkg/analyzer/languageanalyzer"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/utils"
	"github.com/sirupsen/logrus"
)

// CloneRepo initializes the repository cloning process using cmd.Exec() instead of go-git.
func CloneRepo(url, dirName string, repoDetails models.RepoDetails, scanRequest models.ScanRequest, mode models.Mode) error {
	log := logger.GetLogger()

	// Validate supported repository providers
	if !isSupportedRepoURL(url) {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("unsupported repository URL. We support only 5 repositories: Github, GitLab, BitBucket, Azure repos, AWS repos %v", url))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("unsupported repository URL. We support only 5 repositories: Github, GitLab, BitBucket, Azure repos, AWS repos %v", url), constant.ProgressValueFour)
		return fmt.Errorf("unsupported repository URL. We support only 5 repositories: Github, GitLab, BitBucket, Azure repos, AWS repos")
	}

	//3rd API call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.RepoReadingInProgress,
		"progress":    constant.ProgressValueFour,
	}).Info("====SendLogMessage ====API: Reading repo in progress.==== payload===")
	log.Println("3rd API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.RepoReadingInProgress, constant.ProgressValueFour)
	log.Println("3rd API Request completed====", constant.RepoReadingInProgress)

	// Get the authentication method based on repoDetails
	authMethod, err := getAuthMethod(repoDetails)
	if err != nil {
		return fmt.Errorf("authentication error: %v", err)
	}
	//4th API call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.RepoReadingInProgress,
		"progress":    constant.ProgressValueSix,
	}).Info("====SendLogMessage ====API: Reading repo in progress.==== payload===")
	log.Println("4th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.RepoReadingInProgress, constant.ProgressValueSix)
	log.Println("4th API Request completed====", constant.RepoReadingInProgress)

	// Clone URL should include the token for authentication in the URL
	repoURL := buildGitCloneURL(repoDetails, authMethod)
	// Logging the start of the cloning process
	log.WithFields(logrus.Fields{
		"url": url,
		"dir": dirName,
	}).Info("Starting to clone repository")

	// Ensure the target directory exists, if not, create it
	if err := os.MkdirAll(dirName, os.ModePerm); err != nil {
		log.WithFields(logrus.Fields{
			"url":   url,
			"dir":   dirName,
			"error": err.Error(),
		}).Error("Failed to create directory")
		return fmt.Errorf("failed to create directory: %v", err)
	}
	//5th API call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.RepoReadingInProgress,
		"progress":    constant.ProgressValueEight,
	}).Info("====SendLogMessage ====API: Reading repo in progress.==== payload===")
	log.Println("5th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.RepoReadingInProgress, constant.ProgressValueEight)
	log.Println("5th API Request completed====", constant.RepoReadingInProgress)

	var cmd *exec.Cmd
	if repoDetails.AuthType == "pat" && repoDetails.RepoType == "bitbucket" || repoDetails.AuthType == "oauth" && repoDetails.RepoType == "bitbucket" {
		cleanedRootURL := strings.TrimPrefix(url, "https://")
		url := "https://x-token-auth:" + repoDetails.AuthToken + "@" + cleanedRootURL
		cmd = exec.Command("git", "clone", url, dirName)
	} else {
		// Execute the git clone command via exec
		log.Info("Cloning repository from:", repoDetails.RootURL)
		cmd = exec.Command("git", "clone", repoURL, dirName)

		// If SSH authentication is used, configure GIT_SSH_COMMAND
		if repoDetails.AuthType == "ssh" {
			sshCommand := fmt.Sprintf("ssh -i %s -o StrictHostKeyChecking=no", repoDetails.SSHKeyPath)
			cmd.Env = append(os.Environ(), fmt.Sprintf("GIT_SSH_COMMAND=%s", sshCommand))
		}
	}
	// Capture the output and error
	output, err := cmd.CombinedOutput()
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Failed to access the repository at '%s'. Please check that the URL is correct and that access permissions are properly set : %v", repoURL, err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Failed to access the repository at '%s'. Please check that the URL is correct and that access permissions are properly set : %v", repoURL, err), constant.ProgressValueEight)
		log.WithFields(logrus.Fields{
			"error": err.Error(),
		}).Error("Failed to clone repository")
		log.Error("Git clone output: ", string(output))
		return fmt.Errorf("Failed to access the repository at '%s'. Please check that the URL is correct and that access permissions are properly set.", repoURL, err)
	}

	// Success
	log.WithFields(logrus.Fields{
		"url": url,
		"dir": dirName,
	}).Info("Repository cloned successfully")
	//6th API call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.RepoReadingCompleted,
		"progress":    constant.ProgressValueTen,
	}).Info("====SendLogMessage ====API: Reading repo completed.==== payload===")
	log.Println("6th API Request Intiated====", constant.APIEnable)
	utils.SendLogMessage(scanRequest, constant.RepoReadingCompleted, constant.ProgressValueTen)
	log.Println("6th API Request completed====", constant.RepoReadingCompleted)

	// Analyzing the repository for tech stack
	log.Info("Analyzing repository for tech stack")
	languageanalyzer.ScanGitRepo(dirName, scanRequest, mode)
	log.Info("Repository analysis complete")

	return nil
}

func isSupportedRepoURL(url string) bool {
	supportedDomains := []string{
		"github.com",
		"gitlab.com",
		"bitbucket.org",
		"dev.azure.com",
		"git-codecommit", // AWS CodeCommit (will match e.g. git-codecommit.us-east-1.amazonaws.com)
	}

	for _, domain := range supportedDomains {
		if strings.Contains(url, domain) {
			return true
		}
	}
	return false
}

// getAuthMethod handles the authentication based on the provided RepoDetails.
func getAuthMethod(repoDetails models.RepoDetails) (string, error) {
	switch repoDetails.AuthType {
	case "pat": // Personal Access Token
		return repoDetails.AuthToken, nil
	case "oauth":
		return repoDetails.AuthToken, nil
	case "bitbucket_app_password":
		if repoDetails.Username == "" || repoDetails.Password == "" {
			return "", fmt.Errorf("username and app password are required for Bitbucket AppPassword auth")
		}
		// Return combined credentials
		return fmt.Sprintf("%s:%s", repoDetails.Username, repoDetails.Password), nil
	case "ssh":
		if repoDetails.SSHKeyPath == "" {
			return "", fmt.Errorf("SSH key path is required for 'ssh' auth type")
		}
		return "ssh", nil
	case "aws_iam":
		// IAM authentication is done via the AWS credential chain; no token needed here
		return "", nil
	case "":
		return "", nil // No authentication
	default:
		return "", fmt.Errorf("unsupported authentication type: %s", repoDetails.AuthType)
	}
}

// buildGitCloneURL constructs the URL for git clone, embedding the token for authentication.
func buildGitCloneURL(repoDetails models.RepoDetails, authToken string) string {

	switch repoDetails.AuthType {
	case "ssh":
		return repoDetails.RootURL // e.g., git@bitbucket.org:user/repo.git

	case "bitbucket_app_password":
		// Bitbucket HTTPS clone: https://username:appPassword@bitbucket.org/user/repo.git
		return fmt.Sprintf("https://%s@%s", authToken, strings.TrimPrefix(repoDetails.RootURL, "https://"))

	case "aws_iam":
		// AWS CodeCommit uses the credential helper, so no token should be embedded
		// Ensure the URL is in the format: https://git-codecommit.<region>.amazonaws.com/v1/repos/your-repo
		return repoDetails.RootURL

	case "pat": // GitLab Personal Access Token
		if authToken != "" {
			// Use 'oauth2' as username per GitLab's recommendation
			return fmt.Sprintf("https://oauth2:%s@%s", authToken, strings.TrimPrefix(repoDetails.RootURL, "https://"))
		}
		return repoDetails.RootURL

	default:
		if authToken != "" {
			// Generic token-based HTTPS (e.g., GitHub)
			return fmt.Sprintf("https://%s@%s", authToken, strings.TrimPrefix(repoDetails.RootURL, "https://"))
		}
		return repoDetails.RootURL
	}
}

// ExtractArchive extracts the downloaded archive file into the target directory (same directory as the archive file).
func ExtractArchive(archivePath string, scanRequest models.ScanRequest, mode models.Mode) error {
	log := logger.GetLogger()
	// Get the directory of the archive file
	cacheDir, _ := utils.CreateTempDirectory()
	sourceCodePath := filepath.Join(cacheDir, scanRequest.TenantID, scanRequest.AppID, "sourceCode", scanRequest.ComponentID, scanRequest.ScanID, scanRequest.RunID)

	//extractDir := filepath.Dir(archivePath)
	extractDir := sourceCodePath
	log.Info("Extract dri Path: ", extractDir)

	// Open the archive file
	fileExt := strings.ToLower(filepath.Ext(archivePath))

	// Check if the file is blank (empty)
	fileInfo, err := os.Stat(archivePath)
	if err != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Unable to access the archive file. Please make sure the file exists and that you have the necessary permissions to access it : %s", err))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Unable to access the archive file. Please make sure the file exists and that you have the necessary permissions to access it : %s", err), constant.ProgressValueFour)
		return fmt.Errorf("Unable to access the archive file. Please make sure the file exists and that you have the necessary permissions to access it: %w", err)
	}
	if fileInfo.Size() <= 1024 {
		err := fmt.Errorf("The uploaded archive '%s' is empty. Please upload a valid file with content.", filepath.Base(archivePath))
		utils.ReportErrorToAPI(scanRequest, err.Error())
		utils.ReportErrorToSendLogAPI(scanRequest, err.Error(), constant.ProgressValueFour)
		return err
	}
	//Third API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueFour,
	}).Info("====SendLogMessage ====API: Repo reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueFour)

	switch fileExt {
	case ".zip":
		if err := extractZip(archivePath, extractDir, scanRequest); err != nil {
			utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("failed to extract Zip file: %s", err))
			utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("failed to extract Zip file: %s", err), constant.ProgressValueFour)

			return err
		}
	case ".tar":
		if err := extractTar(archivePath, extractDir, scanRequest); err != nil {
			utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("failed to extract Tar file: %s", err))
			utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("failed to extract Tar file: %s", err), constant.ProgressValueFour)
			return err
		}
	case ".rar":
		if err := extractRar(archivePath, extractDir, scanRequest); err != nil {
			utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("failed to extract Rar file: %s", err))
			utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("failed to extract Rar file: %s", err), constant.ProgressValueFour)
			return err
		}
	default:
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("The uploaded file format is not supported. Please upload a ZIP, TAR, or RAR archive : %s", fileExt))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("The uploaded file format is not supported. Please upload a ZIP, TAR, or RAR archive : %s", fileExt), constant.ProgressValueFour)
		return fmt.Errorf("The uploaded file format is not supported. Please upload a ZIP, TAR, or RAR archive : %s", fileExt)
	}
	//Sixth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingCompleted,
		"progress":    constant.ProgressValueTen,
	}).Info("====SendLogMessage ====API: File reading Completed.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingCompleted, constant.ProgressValueTen)

	baseName := strings.TrimSuffix(filepath.Base(archivePath), filepath.Ext(archivePath))
	extractDir = filepath.Join(extractDir, baseName)
	languageanalyzer.ScanGitRepo(extractDir, scanRequest, mode)

	return nil
}

func extractZip(zipPath, extractDir string, scanRequest models.ScanRequest) error {
	log := logger.GetLogger()

	// Open the zip file
	zipReader, err := zip.OpenReader(zipPath)
	if err != nil {
		return fmt.Errorf("failed to open zip file: %w", err)
	}
	defer zipReader.Close()
	//Fourth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueSix,
	}).Info("====SendLogMessage ====API: File reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueSix)

	// Loop through each file in the zip archive
	for _, file := range zipReader.File {
		// Construct the full file path in the destination directory
		filePath := filepath.Join(extractDir, file.Name)

		// Check if it's a directory or file
		if file.FileInfo().IsDir() {
			// Create the directory
			err := os.MkdirAll(filePath, file.Mode())
			if err != nil {
				return fmt.Errorf("failed to create directory %s: %w", filePath, err)
			}
		} else {
			// Create the file
			err := func() error {
				outFile, err := os.Create(filePath)
				if err != nil {
					return fmt.Errorf("failed to create file %s: %w", filePath, err)
				}
				defer outFile.Close()

				// Open the zip file content
				inFile, err := file.Open()
				if err != nil {
					return fmt.Errorf("failed to open file in zip: %w", err)
				}
				defer inFile.Close()

				// Copy the content to the destination file
				_, err = io.Copy(outFile, inFile)
				if err != nil {
					return fmt.Errorf("failed to copy file content: %w", err)
				}
				return nil
			}() // Immediately call the function
			if err != nil {
				return err
			}
		}
	}

	//Fifth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueEight,
	}).Info("====SendLogMessage ====API: File reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueEight)

	return nil
}

func extractTar(tarPath, extractDir string, scanRequest models.ScanRequest) error {
	log := logger.GetLogger()
	// Open the tar file
	tarFile, err := os.Open(tarPath)
	if err != nil {
		return fmt.Errorf("failed to open tar file: %w", err)
	}
	defer tarFile.Close()
	//Fourth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueSix,
	}).Info("====SendLogMessage ====API: File reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueSix)

	// Create a new tar reader
	tarReader := tar.NewReader(tarFile)

	// Loop through each file in the tar archive
	for {
		header, err := tarReader.Next()
		if err == io.EOF {
			break // End of archive
		}
		if err != nil {
			return fmt.Errorf("failed to read tar header: %w", err)
		}

		// Construct the full file path in the destination directory
		filePath := filepath.Join(extractDir, header.Name)

		// Check if it's a directory or file
		if header.Typeflag == tar.TypeDir {
			// Create the directory
			err := os.MkdirAll(filePath, os.FileMode(header.Mode))
			if err != nil {
				return fmt.Errorf("failed to create directory %s: %w", filePath, err)
			}
		} else if header.Typeflag == tar.TypeReg {
			// Create the file
			err := func() error {
				outFile, err := os.Create(filePath)
				if err != nil {
					return fmt.Errorf("failed to create file %s: %w", filePath, err)
				}
				defer outFile.Close()

				// Copy the content to the destination file
				_, err = io.Copy(outFile, tarReader)
				if err != nil {
					return fmt.Errorf("failed to copy file content: %w", err)
				}
				return nil
			}()
			if err != nil {
				return err
			}
		}
	}
	//Fifth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueEight,
	}).Info("====SendLogMessage ====API: File reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueEight)

	return nil
}

func extractRar(rarPath, extractDir string, scanRequest models.ScanRequest) error {
	log := logger.GetLogger()
	// Open the rar file
	file, err := os.Open(rarPath)
	if err != nil {
		return fmt.Errorf("failed to open rar file: %w", err)
	}
	defer file.Close()
	//Fourth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueSix,
	}).Info("====SendLogMessage ====API: File reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueSix)
	// Initialize the RAR reader
	rarReader, err := rardecode.NewReader(file, "")
	if err != nil {
		return fmt.Errorf("failed to create rar reader: %w", err)
	}

	// Loop through each file in the RAR archive
	for {
		// Read the next file in the archive
		header, err := rarReader.Next()
		if err == io.EOF {
			break // End of archive
		}
		if err != nil {
			return fmt.Errorf("failed to read rar file: %w", err)
		}

		// Construct the full file path in the destination directory
		filePath := filepath.Join(extractDir, header.Name)

		// Check if it's a directory or file
		if header.IsDir {
			// Create the directory (make sure all parent directories are created)
			err := os.MkdirAll(filePath, os.FileMode(header.Mode()))
			if err != nil {
				return fmt.Errorf("failed to create directory %s: %w", filePath, err)
			}
		} else if !header.IsDir {
			// Ensure the directory exists before creating the file
			dir := filepath.Dir(filePath)
			err := os.MkdirAll(dir, 0755)
			if err != nil {
				return fmt.Errorf("failed to create directory for file %s: %w", filePath, err)
			}

			// Create the file
			err = func() error {
				outFile, err := os.Create(filePath)
				if err != nil {
					return fmt.Errorf("failed to create file %s: %w", filePath, err)
				}
				defer outFile.Close()

				// Copy the content to the destination file
				_, err = io.Copy(outFile, rarReader)
				if err != nil {
					return fmt.Errorf("failed to copy file content: %w", err)
				}
				return nil
			}()
			if err != nil {
				return err
			}
		}
	}
	//Fifth API Call
	scanRequest.LaunchedOn = utils.GetCurrentTime()
	log.WithFields(logrus.Fields{
		"scanRequest": scanRequest,
		"logMassage":  constant.FileReadingInProgress,
		"progress":    constant.ProgressValueEight,
	}).Info("====SendLogMessage ====API: File reading Inprogress.==== payload===")
	utils.SendLogMessage(scanRequest, constant.FileReadingInProgress, constant.ProgressValueEight)

	return nil
}
