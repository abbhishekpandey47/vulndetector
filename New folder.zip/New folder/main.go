package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"path/filepath"

	"github.com/scanner/constant"
	"github.com/scanner/internals/db"
	"github.com/scanner/models"
	"github.com/scanner/pkg/logger"
	"github.com/scanner/pkg/uploader"
	"github.com/scanner/pkg/utils"
	"github.com/sirupsen/logrus"
)

func main() {

	ctx := context.Background()
	//Get temp dir to store log file
	tempPath, _ := utils.CreateTempDirectory()
	logFileName := filepath.Join(tempPath, constant.Log, constant.LogFileName)

	// Initialize the logger with the log file path
	err := logger.Init(logFileName)
	if err != nil {
		// Handle error during logger initialization
		log.Printf("Error during creating logger: %v\n", err)
		return
	}
	fmt.Println("Using log file:", logFileName)
	// Ensure that the logger has been initialized properly
	log := logger.GetLogger()
	if log == nil {
		// Check if the logger is nil
		log.Println("Logger not initialized properly.")
		return
	}

	logger.SetLogLevel("info")

	localIP := utils.GetLocalIP()
	containerIP, _ := utils.GetContainerIP()
	// Get the logger instance
	log.Println("Local IP: ", localIP)
	log.Println("Container IP: ", containerIP)

	var requestTypeStr, repoDetailsStr, scanRequestStr, sourceCodePathStr, envTypeStr, modeStr string

	flag.StringVar(&requestTypeStr, "request_type", "", "JSON string representing the request type")
	flag.StringVar(&repoDetailsStr, "repo_details", "", "JSON string representing the repository details")
	flag.StringVar(&scanRequestStr, "scan_request", "", "JSON string representing the scan request")
	flag.StringVar(&sourceCodePathStr, "sourcecode_path", "", "JSON string representing the repository details")
	flag.StringVar(&envTypeStr, "env_type", "", "JSON string representing the env type")
	flag.StringVar(&modeStr, "mode", "", "JSON string representing the mode")

	// Parse the flags
	flag.Parse()

	// Use the ParseJSONInput function from utils to parse and combine the JSON input
	requestType, repoDetails, scanRequest, fileSystemDetails, envType, mode, err := utils.ParseJSONInput(requestTypeStr, repoDetailsStr, scanRequestStr, sourceCodePathStr, envTypeStr, modeStr)
	if err != nil {
		log.Fatalf("Error parsing JSON input: %v", err)
	}
	if envType.EnvType == "" {
		log.Infof("System environment is empty . API URL: %s", constant.DevMsgAPI)
		constant.APIURL = constant.DevMsgAPI
	}
	if envType.EnvType == "dev" {
		log.Infof("System environment is 'dev'. API URL: %s", constant.DevMsgAPI)
		constant.APIURL = constant.DevMsgAPI
	}
	if envType.EnvType == "qa" {
		log.Infof("System environment is 'qa'. API URL: %s", constant.QaMsgAPI)
		constant.APIURL = constant.QaMsgAPI
	}
	if mode.Mode == "offline" {
		log.Infof("System Mode is 'offline'")
		constant.APIEnable = false
		utils.WriteFullScanPayloadToFile(scanRequest, requestType, envType, mode, repoDetails, fileSystemDetails)
		log.Info("Operating in Offline mode API disabled.")
	}
	if mode.Mode == "" {
		log.Infof("System Mode is not given running in 'online' mode")
		constant.APIEnable = true
		log.Info("Operating in online mode API enabled.")
	}
	if mode.Mode == "online" {
		log.Infof("System Mode is 'online'")
		constant.APIEnable = true
		log.Info("Operating in online mode API enabled.")

	}
	// Vuln DB Init
	vuln_db_init(ctx, mode)
	uploaderErr := uploader.UploadRequest(requestType, repoDetails, scanRequest, fileSystemDetails, mode)
	if uploaderErr != nil {
		utils.ReportErrorToAPI(scanRequest, fmt.Sprintf("Error during upload request: %v", uploaderErr))
		utils.ReportErrorToSendLogAPI(scanRequest, fmt.Sprintf("Error during upload request: %v", uploaderErr), 0)
		// Log the error with relevant fields
		log.WithFields(logrus.Fields{
			"TenantID": scanRequest.TenantID,
			"RunID":    scanRequest.RunID,
		}).Error("Error during upload request: " + uploaderErr.Error())
	}
}

func vuln_db_init(ctx context.Context, mode models.Mode) {

	log := logger.GetLogger()
	dbdir, err := utils.GetCodeAnalyzerVulnDBPath(db.DstDir)
	if err != nil {
		log.Error("Error in creating DB directory : ", err)
	}

	log.Info("Vuln DB directory created in path : ", dbdir)
	if mode.Mode == "online" || mode.Mode == ""{
		// Ensure the vulnerability DB is downloaded & up-to-date.
		if err := db.UpdateDBIfNeeded(ctx, dbdir, db.Vuln_repositories); err != nil {
			log.Fatalf("Error updating DB: %v", err)
		}
		log.Infof("DB is ready at %s", filepath.Join(db.DstDir, db.DBFilename))

		// Open the Bolt DB using the correct path.
		database := db.NewDB()
		defer database.Close()
	}
}
